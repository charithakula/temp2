<#
.SYNOPSIS
  One-command demo start. Brings up Postgres + backend + frontend in Docker with
  demo mode on and a seeded demo user. Requires Docker Desktop.

.EXAMPLE
  ./scripts/start-demo.ps1
#>
$ErrorActionPreference = "Stop"

Write-Host "Starting APIM Developer Portal (demo mode)..." -ForegroundColor Cyan
docker compose up --build -d

Write-Host ""
Write-Host "App is starting. Once ready:" -ForegroundColor Green
Write-Host "  Frontend : http://localhost:3000"
Write-Host "  API docs : http://localhost:8000/docs"
Write-Host ""
Write-Host "Demo user : demo.developer@example.com (no password / sign-in needed)"
Write-Host ""
Write-Host "Follow logs with:  docker compose logs -f" -ForegroundColor DarkGray
Write-Host "Stop with:         docker compose down" -ForegroundColor DarkGray
