<#
.SYNOPSIS
  Deploys the APIM Developer Portal product + subscription Bicep to a resource group.

.EXAMPLE
  ./deploy.ps1 -ResourceGroup "rg-apim" -Location "centralindia"
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [string]$Location = "centralindia",

    [string]$ParamFile = "$PSScriptRoot/../infra/main.bicepparam"
)

$ErrorActionPreference = "Stop"

Write-Host "Validating deployment..." -ForegroundColor Cyan
az deployment group validate `
    --resource-group $ResourceGroup `
    --parameters $ParamFile

Write-Host "Deploying..." -ForegroundColor Cyan
az deployment group create `
    --resource-group $ResourceGroup `
    --name "apim-devportal-subscription" `
    --parameters $ParamFile

Write-Host "Done." -ForegroundColor Green
