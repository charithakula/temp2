using './main.bicep'

// ---- REQUIRED: set these to your environment ----
param apimName = '<your-apim-service-name>'

// ---- OPTIONAL: link an existing API to the product ----
param apiName = '' // e.g. 'my-api'

// ---- Product (shows in Developer Portal) ----
param productId = 'developer-portal-app'
param productDisplayName = 'Developer Portal App'
param productDescription = 'Product for the developer portal application subscription.'
param subscriptionRequired = true
param approvalRequired = true
param subscriptionsLimit = 1

// ---- Subscription ----
param subscriptionId = 'app-subscription'
param subscriptionDisplayName = 'App Subscription'
