// ----------------------------------------------------------------------------
// APIM Developer Portal — App Subscription scaffold
// Creates: a Product, links an API to it, and creates a Subscription scoped
// to that Product. The Product is published so it appears in the Developer
// Portal where app developers can subscribe and get their subscription keys.
// ----------------------------------------------------------------------------

@description('Name of the EXISTING API Management service.')
param apimName string

@description('Name (id) of the EXISTING API to add to the product. Leave empty to skip linking an API.')
param apiName string = ''

@description('Product id (no spaces). Used as the resource name.')
param productId string = 'developer-portal-app'

@description('Product display name shown in the Developer Portal.')
param productDisplayName string = 'Developer Portal App'

@description('Product description shown in the Developer Portal.')
param productDescription string = 'Product for the developer portal application subscription.'

@description('Require approval before subscriptions become active.')
param subscriptionRequired bool = true

@description('If true, an admin must approve each subscription request.')
param approvalRequired bool = true

@description('Max number of simultaneous subscriptions a user can have. 0 = unlimited.')
param subscriptionsLimit int = 1

@description('Subscription id (no spaces).')
param subscriptionId string = 'app-subscription'

@description('Subscription display name.')
param subscriptionDisplayName string = 'App Subscription'

// Reference the existing APIM instance
resource apim 'Microsoft.ApiManagement/service@2023-05-01-preview' existing = {
  name: apimName
}

// Product — this is what shows up in the Developer Portal
resource product 'Microsoft.ApiManagement/service/products@2023-05-01-preview' = {
  parent: apim
  name: productId
  properties: {
    displayName: productDisplayName
    description: productDescription
    subscriptionRequired: subscriptionRequired
    approvalRequired: subscriptionRequired ? approvalRequired : null
    subscriptionsLimit: subscriptionRequired ? subscriptionsLimit : null
    state: 'published' // published = visible in Developer Portal
  }
}

// Link the existing API to the product (only if apiName provided)
resource productApi 'Microsoft.ApiManagement/service/products/apis@2023-05-01-preview' = if (!empty(apiName)) {
  parent: product
  name: apiName
}

// Subscription scoped to the product
resource subscription 'Microsoft.ApiManagement/service/subscriptions@2023-05-01-preview' = {
  parent: apim
  name: subscriptionId
  properties: {
    displayName: subscriptionDisplayName
    scope: product.id
    state: 'active'
  }
}

output productResourceId string = product.id
output subscriptionResourceId string = subscription.id
output developerPortalUrl string = apim.properties.developerPortalUrl
