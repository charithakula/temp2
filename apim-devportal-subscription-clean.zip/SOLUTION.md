# Solution Design — APIM Developer Portal Application

A custom developer portal for Azure API Management where app developers log in with
**Microsoft Entra ID**, browse products/APIs, subscribe, and see their **subscription
history**, **end-of-subscription dates**, and receive **renewal notifications**.

> Status: **DRAFT for review.** No application code generated yet — only the Bicep
> infra from the earlier step exists. Approve this design and I'll scaffold the full
> skeleton.

---

## 1. High-level architecture

```
                         ┌────────────────────────────┐
                         │     Microsoft Entra ID      │
                         │  (OIDC / OAuth2 login)      │
                         └─────────────▲──────────────┘
                                       │ tokens
        ┌──────────────────┐  JWT      │           ┌──────────────────────────┐
        │   Next.js +      │◀──────────┴──────────▶│        FastAPI           │
        │   Tailwind CSS   │   REST (Bearer JWT)   │  (Python backend)        │
        │  (frontend SPA)  │──────────────────────▶│                          │
        └──────────────────┘                       │  ├─ Auth (verify JWT)    │
                                                    │  ├─ Subscriptions API    │
                                                    │  ├─ History API          │
                                                    │  ├─ Notifications API     │
                                                    │  └─ Scheduler (APScheduler)│
                                                    └───────┬──────────┬───────┘
                                                            │          │
                                          ┌─────────────────▼──┐   ┌───▼─────────────┐
                                          │   PostgreSQL        │   │  Azure APIM     │
                                          │  (history, expiry,  │   │  Management API │
                                          │   renewals, notifs) │   │ (products/subs) │
                                          └─────────────────────┘   └─────────────────┘
                                                            │
                                                  ┌─────────▼──────────┐
                                                  │  Email (ACS/SMTP)  │
                                                  └────────────────────┘
```

**Why APIM + own DB:** APIM stores products and subscriptions but has **no concept of
subscription expiry, renewal, or history**. So we treat APIM as the source of truth for
*what exists*, and our PostgreSQL DB as the source of truth for *lifecycle* (start/end
dates, renewals, audit history, notification state).

---

## 2. Components

### Frontend — Next.js (App Router) + Tailwind CSS
- **Auth**: `@azure/msal-browser` + `@azure/msal-react` (or NextAuth.js with the
  Azure AD provider). Acquires an access token for the FastAPI backend.
- **Pages**:
  - `/login` — Entra ID sign-in.
  - `/` (dashboard) — at-a-glance: active subscriptions, days-to-expiry badges, alerts.
  - `/products` — browse published APIM products, request a subscription.
  - `/subscriptions` — my subscriptions, status, primary/secondary keys (masked), expiry.
  - `/subscriptions/[id]/history` — timeline of events (created, renewed, expired, revoked).
  - `/notifications` — in-app notification list (bell icon + unread count in header).
- **Calls** FastAPI with the bearer token; never talks to APIM directly.

### Backend — FastAPI
- **Auth dependency**: validates the Entra ID JWT (issuer, audience, signature via JWKS).
- **APIM client**: thin wrapper over the APIM REST management API (uses a service
  principal / managed identity) to list products, create/get/revoke subscriptions.
- **Routers**:
  - `auth` — `/me` (current user profile from token).
  - `products` — `GET /products` (proxied from APIM).
  - `subscriptions` — `GET/POST /subscriptions`, `POST /subscriptions/{id}/renew`,
    `DELETE /subscriptions/{id}` (revoke). Writes lifecycle rows to DB.
  - `history` — `GET /subscriptions/{id}/history`.
  - `notifications` — `GET /notifications`, `POST /notifications/{id}/read`.
- **Scheduler** (APScheduler): daily job scans subscriptions, finds those expiring within
  N days (e.g. 30/7/1), creates in-app notifications + sends emails, and records that the
  reminder was sent (so it isn't sent twice).

### Database — PostgreSQL (SQLAlchemy + Alembic)
Proposed tables:

| Table | Key columns |
|-------|-------------|
| `users` | `id`, `entra_oid` (unique), `email`, `display_name`, `created_at` |
| `subscriptions` | `id`, `user_id`, `apim_subscription_id`, `product_id`, `status`, `start_date`, `end_date`, `auto_renew`, `created_at` |
| `subscription_history` | `id`, `subscription_id`, `event_type` (created/renewed/expired/revoked), `detail`, `event_at` |
| `notifications` | `id`, `user_id`, `subscription_id`, `type` (renewal_reminder/expired/…), `channel` (in_app/email), `message`, `is_read`, `sent_at` |

### Notifications
- **In-app**: rows in `notifications`; frontend polls `/notifications` (or websocket later).
- **Email**: Azure Communication Services (or SMTP fallback) sends renewal reminders.
- **Scheduled**: APScheduler daily scan → reminders at 30 / 7 / 1 days before `end_date`.

---

## 3. Subscription lifecycle

```
request → (APIM creates subscription) → DB row status=active, start/end dates set
   → [scheduler] T-30/7/1 days → in-app + email reminder, history: "reminder_sent"
   → renew → end_date extended, history: "renewed"
   → end_date passes (no renew) → status=expired, history: "expired", APIM sub disabled
   → revoke → APIM sub deleted, status=revoked, history: "revoked"
```

---

## 4. Proposed repository layout

```
apim-devportal-subscription/
├─ infra/                     # (exists) Bicep: APIM product + subscription
│  ├─ main.bicep
│  └─ main.bicepparam
├─ backend/                   # FastAPI
│  ├─ app/
│  │  ├─ main.py              # app + router registration + scheduler startup
│  │  ├─ config.py            # settings (env)
│  │  ├─ auth/                # Entra ID JWT validation
│  │  ├─ apim/                # APIM management API client
│  │  ├─ db/                  # SQLAlchemy engine, session, base
│  │  ├─ models/             # ORM models (users, subscriptions, history, notifications)
│  │  ├─ schemas/            # Pydantic request/response models
│  │  ├─ routers/            # auth, products, subscriptions, history, notifications
│  │  ├─ services/           # business logic (lifecycle, notifications)
│  │  └─ scheduler/          # APScheduler jobs (expiry scan)
│  ├─ alembic/                # migrations
│  ├─ requirements.txt
│  ├─ .env.example
│  └─ Dockerfile
├─ frontend/                  # Next.js + Tailwind
│  ├─ app/                    # App Router pages (login, dashboard, products, subscriptions, history, notifications)
│  ├─ components/             # UI components (cards, tables, notification bell)
│  ├─ lib/                    # api client, msal config
│  ├─ package.json
│  ├─ tailwind.config.ts
│  ├─ .env.local.example
│  └─ Dockerfile
├─ docker-compose.yml         # postgres + backend + frontend for local dev
├─ SOLUTION.md                # this file
└─ README.md
```

---

## 5. Auth flow (Entra ID)

1. User clicks sign-in → redirected to Entra ID, authenticates.
2. Frontend (MSAL) receives an **access token** scoped to the backend API
   (`api://<backend-app-id>/access_as_user`).
3. Frontend calls FastAPI with `Authorization: Bearer <token>`.
4. FastAPI validates the token against Entra's JWKS (issuer + audience), extracts the
   user's `oid`/email, upserts the `users` row, and authorizes the request.

Requires **two Entra app registrations**: one for the frontend (SPA) and one for the
backend API (exposes a scope), or a single app with both platforms configured.

---

## 6. Configuration (env vars)

**Backend** (`backend/.env.example`):
```
DATABASE_URL=postgresql+psycopg://user:pass@localhost:5432/devportal
ENTRA_TENANT_ID=...
ENTRA_API_CLIENT_ID=...          # backend app id (audience)
APIM_SERVICE_NAME=...
APIM_RESOURCE_GROUP=...
AZURE_SUBSCRIPTION_ID=...
APIM_AUTH=managed_identity|sp    # how the backend authenticates to APIM
ACS_CONNECTION_STRING=...        # email (or SMTP_* vars)
REMINDER_DAYS=30,7,1
```

**Frontend** (`frontend/.env.local.example`):
```
NEXT_PUBLIC_ENTRA_TENANT_ID=...
NEXT_PUBLIC_ENTRA_CLIENT_ID=...  # frontend SPA app id
NEXT_PUBLIC_API_SCOPE=api://<backend-app-id>/access_as_user
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

---

## 7. Open questions / assumptions

1. **Auth library**: MSAL React vs NextAuth.js — I'll default to **MSAL** (most direct for
   Entra + calling a protected API) unless you prefer NextAuth.
2. **APIM auth from backend**: Managed Identity (recommended for Azure-hosted) vs service
   principal (easier locally). I'll support both via config, default to service principal
   for local dev.
3. **Email provider**: Azure Communication Services vs plain SMTP — I'll wire ACS with an
   SMTP fallback interface.
4. **Subscription expiry**: APIM itself won't auto-disable expired subs; the scheduler will
   disable them in APIM when `end_date` passes. OK?
5. **Renewal**: manual (user clicks renew) for v1; `auto_renew` flag stored for later.

---

## 8. Next step

If this design looks right, I'll generate the **full working skeleton**:
- FastAPI app with auth, models, routers, APIM client, scheduler, Alembic init.
- Next.js app with MSAL auth, the listed pages, Tailwind, and an API client.
- `docker-compose.yml` for one-command local dev (Postgres + backend + frontend).

Tell me which of the open questions above to change, or say "go" to scaffold as drafted.
```
