"use client";

import {
  AppWindow,
  Plus,
  Trash2,
  Loader2,
  Boxes,
  X,
  KeyRound,
} from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { FlowDiagram } from "@/components/FlowDiagram";
import { StatusBadge } from "@/components/StatusBadge";
import { api, App, Subscription } from "@/lib/api";
import { formatDate } from "@/lib/utils";

export default function AppsPage() {
  return (
    <Shell>
      <Apps />
    </Shell>
  );
}

function Apps() {
  const [apps, setApps] = useState<App[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function load() {
    api.apps().then(setApps).catch(() => setApps([]));
  }
  useEffect(load, []);

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Applications</h1>
          <p className="mt-1 text-sm text-slate-400">
            Register apps that own your API subscriptions.
          </p>
        </div>
        <button onClick={() => setCreating(true)} className="btn-primary shrink-0">
          <Plus className="h-4 w-4" /> New app
        </button>
      </div>

      <FlowDiagram />

      {error && (
        <div className="rounded-xl border border-rose-400/30 bg-rose-400/10 px-4 py-3 text-sm text-rose-200">
          {error}
        </div>
      )}

      {apps === null ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {[0, 1].map((i) => (
            <div key={i} className="glass h-40 animate-pulse" />
          ))}
        </div>
      ) : apps.length === 0 ? (
        <div className="glass grid place-items-center py-16 text-center">
          <AppWindow className="h-10 w-10 text-slate-400" />
          <p className="mt-3 font-medium">No applications yet</p>
          <p className="text-sm text-slate-400">
            Create an app, then subscribe it to products from the catalog.
          </p>
          <button onClick={() => setCreating(true)} className="btn-primary mt-5">
            <Plus className="h-4 w-4" /> Create your first app
          </button>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {apps.map((a) => (
            <AppCard key={a.id} app={a} onChanged={load} onError={setError} />
          ))}
        </div>
      )}

      {creating && (
        <CreateAppModal
          onClose={() => setCreating(false)}
          onCreated={() => {
            setCreating(false);
            load();
          }}
          onError={setError}
        />
      )}
    </div>
  );
}

function AppCard({
  app,
  onChanged,
  onError,
}: {
  app: App;
  onChanged: () => void;
  onError: (m: string) => void;
}) {
  const [subs, setSubs] = useState<Subscription[] | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.appSubscriptions(app.id).then(setSubs).catch(() => setSubs([]));
  }, [app.id]);

  async function remove() {
    if (!confirm(`Delete app "${app.name}"?`)) return;
    setBusy(true);
    try {
      await api.deleteApp(app.id);
      onChanged();
    } catch (e: any) {
      onError(String(e.message ?? e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="glass glass-hover flex flex-col p-5 animate-fade-in">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600">
            <AppWindow className="h-5 w-5 text-white" />
          </span>
          <div>
            <h3 className="font-semibold">{app.name}</h3>
            <p className="text-xs text-slate-400">Created {formatDate(app.created_at)}</p>
          </div>
        </div>
        <button
          onClick={remove}
          disabled={busy}
          className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-400/10 hover:text-rose-300"
          title="Delete app"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
        </button>
      </div>

      {app.description && <p className="mt-3 text-sm text-slate-400">{app.description}</p>}

      <div className="mt-4 border-t border-white/10 pt-4">
        <p className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-400">
          <KeyRound className="h-3.5 w-3.5" /> Subscriptions
        </p>
        {subs === null ? (
          <div className="h-8 animate-pulse rounded-lg bg-white/5" />
        ) : subs.length === 0 ? (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-400">None yet.</p>
            <Link href="/products" className="text-sm text-brand-300 hover:text-brand-200">
              Browse products
            </Link>
          </div>
        ) : (
          <ul className="space-y-2">
            {subs.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-2 text-sm">
                <span className="flex items-center gap-2">
                  <Boxes className="h-4 w-4 text-slate-400" />
                  {s.product_name}
                </span>
                <StatusBadge status={s.status} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function CreateAppModal({
  onClose,
  onCreated,
  onError,
}: {
  onClose: () => void;
  onCreated: () => void;
  onError: (m: string) => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await api.createApp(name.trim(), description.trim());
      onCreated();
    } catch (e: any) {
      onError(String(e.message ?? e));
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <form
        onClick={(e) => e.stopPropagation()}
        onSubmit={submit}
        className="glass w-full max-w-md animate-fade-in p-6"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">New application</h2>
          <button type="button" onClick={onClose} className="rounded-lg p-1 hover:bg-white/10">
            <X className="h-5 w-5" />
          </button>
        </div>

        <label className="block text-sm font-medium">Name</label>
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Weather Bot"
          className="mt-1 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400/50"
        />

        <label className="mt-4 block text-sm font-medium">Description (optional)</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          placeholder="What does this app do?"
          className="mt-1 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400/50"
        />

        <div className="mt-6 flex justify-end gap-2">
          <button type="button" onClick={onClose} className="btn-ghost">
            Cancel
          </button>
          <button type="submit" disabled={busy || !name.trim()} className="btn-primary">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Create app
          </button>
        </div>
      </form>
    </div>
  );
}
