"use client";

import { MsalProvider } from "@azure/msal-react";
import { ReactNode, useEffect, useState } from "react";
import { getMsal, DEMO_MODE } from "@/lib/msal";
import { ThemeProvider } from "@/lib/theme";

export function Providers({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const msal = getMsal();

  useEffect(() => {
    // In demo mode MSAL is never used; render children directly.
    if (DEMO_MODE) {
      setReady(true);
      return;
    }
    msal.initialize().then(() => {
      const accounts = msal.getAllAccounts();
      if (accounts.length && !msal.getActiveAccount()) {
        msal.setActiveAccount(accounts[0]);
      }
      setReady(true);
    });
  }, [msal]);

  if (!ready) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-brand-400" />
      </div>
    );
  }

  // In demo mode, MsalProvider is still fine to mount (MSAL is just never called),
  // which keeps the useMsal() hooks in Shell working without branching.
  return (
    <ThemeProvider>
      <MsalProvider instance={msal}>{children}</MsalProvider>
    </ThemeProvider>
  );
}
