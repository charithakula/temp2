"use client";

import { KeyRound, ShieldCheck, Clock, AlertTriangle, ArrowRight } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { StatCard } from "@/components/StatCard";
import { StatusBadge, ExpiryBadge } from "@/components/StatusBadge";
import { api, Subscription } from "@/lib/api";
import { daysRemaining, formatDate } from "@/lib/utils";

export default function DashboardPage() {
  return (
    <Shell>
      <Dashboard />
    </Shell>
  );
}

function Dashboard() {
  const [subs, setSubs] = useState<Subscription[] | null>(null);

  useEffect(() => {
    api.subscriptions().then(setSubs).catch(() => setSubs([]));
  }, []);

  const active = subs?.filter((s) => s.status === "active") ?? [];
  const expiringSoon = active.filter((s) => daysRemaining(s.end_date) <= 30);
  const expired = subs?.filter((s) => s.status === "expired") ?? [];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
        <p className="mt-1 text-sm text-slate-400">
          An overview of your API subscriptions and upcoming renewals.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Active subscriptions" value={active.length} icon={KeyRound} />
        <StatCard
          label="Expiring in 30 days"
          value={expiringSoon.length}
          icon={Clock}
          accent="from-amber-400 to-orange-500"
        />
        <StatCard
          label="Expired"
          value={expired.length}
          icon={AlertTriangle}
          accent="from-rose-400 to-rose-600"
        />
        <StatCard
          label="Total"
          value={subs?.length ?? 0}
          icon={ShieldCheck}
          accent="from-emerald-400 to-teal-500"
        />
      </div>

      <div className="glass animate-fade-in p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Renewals to watch</h2>
          <Link href="/subscriptions" className="text-sm text-brand-300 hover:text-brand-200">
            View all
          </Link>
        </div>

        {subs === null ? (
          <SkeletonRows />
        ) : expiringSoon.length === 0 ? (
          <EmptyState />
        ) : (
          <ul className="divide-y divide-white/5">
            {expiringSoon
              .sort((a, b) => daysRemaining(a.end_date) - daysRemaining(b.end_date))
              .map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{s.product_name}</p>
                    <p className="text-xs text-slate-400">Expires {formatDate(s.end_date)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <ExpiryBadge days={daysRemaining(s.end_date)} />
                    <StatusBadge status={s.status} />
                  </div>
                </li>
              ))}
          </ul>
        )}
      </div>

      <Link
        href="/products"
        className="glass glass-hover flex items-center justify-between p-6 animate-fade-in"
      >
        <div>
          <p className="font-medium">Browse the API catalog</p>
          <p className="text-sm text-slate-400">Discover products and subscribe in a click.</p>
        </div>
        <ArrowRight className="h-5 w-5 text-brand-300" />
      </Link>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="grid place-items-center py-10 text-center">
      <ShieldCheck className="h-10 w-10 text-emerald-400" />
      <p className="mt-3 font-medium">Nothing expiring soon</p>
      <p className="text-sm text-slate-400">All your active subscriptions are in good shape.</p>
    </div>
  );
}

function SkeletonRows() {
  return (
    <div className="space-y-3">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-12 animate-pulse rounded-xl bg-white/5" />
      ))}
    </div>
  );
}
