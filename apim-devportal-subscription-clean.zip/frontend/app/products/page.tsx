"use client";

import { Boxes, Check, Loader2, ShieldCheck, Clock, AppWindow, Plus } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { FlowDiagram } from "@/components/FlowDiagram";
import { api, Product, App } from "@/lib/api";

export default function ProductsPage() {
  return (
    <Shell>
      <Products />
    </Shell>
  );
}

type Result = "active" | "pending";

function Products() {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [apps, setApps] = useState<App[]>([]);
  const [appId, setAppId] = useState<number | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [done, setDone] = useState<Record<string, Result>>({});
  const [error, setError] = useState<string | null>(null);

  function loadApps() {
    api
      .apps()
      .then((a) => {
        setApps(a);
        // Default the picker to the first app if none chosen yet.
        setAppId((cur) => cur ?? (a[0]?.id ?? null));
      })
      .catch(() => setApps([]));
  }

  useEffect(() => {
    api.products().then(setProducts).catch((e) => {
      setProducts([]);
      setError(String(e.message ?? e));
    });
    loadApps();
  }, []);

  async function subscribe(p: Product) {
    setBusy(p.id);
    setError(null);
    let autoRenew = false;
    try {
      autoRenew = !!JSON.parse(localStorage.getItem("devportal:prefs") ?? "{}").autoRenewDefault;
    } catch {
      /* ignore */
    }
    try {
      const sub = await api.subscribe(p.id, { app_id: appId, auto_renew: autoRenew });
      setDone((prev) => ({ ...prev, [p.id]: sub.status === "pending" ? "pending" : "active" }));
    } catch (e: any) {
      setError(String(e.message ?? e));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">API Catalog</h1>
        <p className="mt-1 text-sm text-slate-400">
          Published products from API Management. Subscribe an app to get your keys.
        </p>
      </div>

      <FlowDiagram />

      {/* App picker */}
      <div className="glass flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600">
            <AppWindow className="h-4 w-4 text-white" />
          </span>
          <div>
            <p className="text-sm font-medium">Subscribe as application</p>
            <p className="text-xs text-slate-400">
              New subscriptions will belong to the selected app.
            </p>
          </div>
        </div>
        {apps.length === 0 ? (
          <Link href="/apps" className="btn-primary">
            <Plus className="h-4 w-4" /> Create your first app
          </Link>
        ) : (
          <select
            value={appId ?? ""}
            onChange={(e) => setAppId(Number(e.target.value))}
            className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400/50"
          >
            {apps.map((a) => (
              <option key={a.id} value={a.id} className="bg-slate-800 text-white">
                {a.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {error && (
        <div className="rounded-xl border border-rose-400/30 bg-rose-400/10 px-4 py-3 text-sm text-rose-200">
          {error}
        </div>
      )}

      {products === null ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass h-44 animate-pulse" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="glass grid place-items-center py-16 text-center">
          <Boxes className="h-10 w-10 text-slate-400" />
          <p className="mt-3 font-medium">No published products</p>
          <p className="text-sm text-slate-400">
            Publish a product in APIM and it will appear here.
          </p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => {
            const result = done[p.id];
            const noApps = apps.length === 0;
            return (
              <div key={p.id} className="glass glass-hover flex flex-col p-5 animate-fade-in">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600">
                  <Boxes className="h-5 w-5 text-white" />
                </div>
                <h3 className="mt-4 font-semibold">{p.name}</h3>
                <p className="mt-1 line-clamp-3 flex-1 text-sm text-slate-400">
                  {p.description || "No description provided."}
                </p>
                {p.approval_required ? (
                  <span className="chip mt-3 w-fit bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/30">
                    <ShieldCheck className="h-3.5 w-3.5" /> Approval required
                  </span>
                ) : (
                  <span className="chip mt-3 w-fit bg-emerald-400/15 text-emerald-300 ring-1 ring-emerald-400/30">
                    <Check className="h-3.5 w-3.5" /> Instant access
                  </span>
                )}
                <button
                  onClick={() => subscribe(p)}
                  disabled={busy === p.id || !!result || noApps}
                  title={noApps ? "Create an app first" : undefined}
                  className={result ? "btn-ghost mt-4" : "btn-primary mt-4"}
                >
                  {busy === p.id ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
                    </>
                  ) : result === "pending" ? (
                    <>
                      <Clock className="h-4 w-4" /> Pending approval
                    </>
                  ) : result === "active" ? (
                    <>
                      <Check className="h-4 w-4" /> Subscribed
                    </>
                  ) : p.approval_required ? (
                    "Request access"
                  ) : (
                    "Subscribe"
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
