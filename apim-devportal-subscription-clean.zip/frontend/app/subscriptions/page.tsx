"use client";

import { KeyRound, RefreshCw, Trash2, History, Loader2 } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { KeysPanel } from "@/components/KeysPanel";
import { StatusBadge, ExpiryBadge } from "@/components/StatusBadge";
import { api, Subscription } from "@/lib/api";
import { daysRemaining, formatDate } from "@/lib/utils";

export default function SubscriptionsPage() {
  return (
    <Shell>
      <Subscriptions />
    </Shell>
  );
}

function Subscriptions() {
  const [subs, setSubs] = useState<Subscription[] | null>(null);
  const [busy, setBusy] = useState<number | null>(null);

  function load() {
    api.subscriptions().then(setSubs).catch(() => setSubs([]));
  }
  useEffect(load, []);

  async function renew(id: number) {
    setBusy(id);
    try {
      await api.renew(id);
      load();
    } finally {
      setBusy(null);
    }
  }

  async function revoke(id: number) {
    if (!confirm("Revoke this subscription? This deletes it in API Management.")) return;
    setBusy(id);
    try {
      await api.revoke(id);
      load();
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">My Subscriptions</h1>
        <p className="mt-1 text-sm text-slate-400">
          Manage your API subscriptions, renew before expiry, or revoke.
        </p>
      </div>

      {subs === null ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass h-24 animate-pulse" />
          ))}
        </div>
      ) : subs.length === 0 ? (
        <div className="glass grid place-items-center py-16 text-center">
          <KeyRound className="h-10 w-10 text-slate-400" />
          <p className="mt-3 font-medium">No subscriptions yet</p>
          <p className="text-sm text-slate-400">Subscribe to a product to get started.</p>
          <Link href="/products" className="btn-primary mt-5">
            Browse products
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {subs.map((s) => {
            const days = daysRemaining(s.end_date);
            return (
              <div key={s.id} className="glass glass-hover p-5 animate-fade-in">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="min-w-0">
                  <div className="flex items-center gap-3">
                    <h3 className="truncate text-lg font-semibold">{s.product_name}</h3>
                    <StatusBadge status={s.status} />
                  </div>
                  {s.app_name && (
                    <p className="mt-1 text-xs text-slate-400">
                      App: <span className="text-slate-200">{s.app_name}</span>
                    </p>
                  )}
                  <p className="mt-1 font-mono text-xs text-slate-400">
                    {s.apim_subscription_id || "— awaiting approval —"}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span>Start {formatDate(s.start_date)}</span>
                    <span>•</span>
                    <span>End {formatDate(s.end_date)}</span>
                    {s.status === "active" && <ExpiryBadge days={days} />}
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-2">
                  <Link
                    href={`/subscriptions/${s.id}/history`}
                    className="btn-ghost"
                    title="History"
                  >
                    <History className="h-4 w-4" /> History
                  </Link>
                  {(s.status === "active" || s.status === "expired") && (
                    <button
                      onClick={() => renew(s.id)}
                      disabled={busy === s.id}
                      className="btn-primary"
                    >
                      {busy === s.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <RefreshCw className="h-4 w-4" />
                      )}
                      Renew
                    </button>
                  )}
                  {s.status !== "revoked" && (
                    <button
                      onClick={() => revoke(s.id)}
                      disabled={busy === s.id}
                      className="btn-ghost text-rose-300 hover:bg-rose-400/10"
                      title={s.status === "pending" ? "Cancel request" : "Revoke"}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                </div>

                {s.status === "active" && <KeysPanel subId={s.id} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
