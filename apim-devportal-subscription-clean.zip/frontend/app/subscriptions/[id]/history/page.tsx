"use client";

import {
  ArrowLeft,
  PlusCircle,
  Bell,
  RefreshCw,
  XCircle,
  Ban,
  Clock,
} from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { api, HistoryItem } from "@/lib/api";
import { formatDate } from "@/lib/utils";

const ICONS: Record<string, any> = {
  created: PlusCircle,
  reminder_sent: Bell,
  renewed: RefreshCw,
  expired: XCircle,
  revoked: Ban,
};

const TONE: Record<string, string> = {
  created: "from-emerald-400 to-teal-500",
  reminder_sent: "from-amber-400 to-orange-500",
  renewed: "from-brand-400 to-brand-600",
  expired: "from-rose-400 to-rose-600",
  revoked: "from-slate-400 to-slate-600",
};

export default function HistoryPage() {
  return (
    <Shell>
      <HistoryView />
    </Shell>
  );
}

function HistoryView() {
  const params = useParams();
  const id = Number(params.id);
  const [items, setItems] = useState<HistoryItem[] | null>(null);

  useEffect(() => {
    api.history(id).then(setItems).catch(() => setItems([]));
  }, [id]);

  return (
    <div className="space-y-8">
      <div>
        <Link
          href="/subscriptions"
          className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" /> Back to subscriptions
        </Link>
        <h1 className="mt-3 text-2xl font-semibold tracking-tight">Subscription History</h1>
        <p className="mt-1 text-sm text-slate-400">
          A full timeline of lifecycle events for this subscription.
        </p>
      </div>

      <div className="glass p-6">
        {items === null ? (
          <div className="space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-xl bg-white/5" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="grid place-items-center py-10 text-center">
            <Clock className="h-10 w-10 text-slate-400" />
            <p className="mt-3 font-medium">No history yet</p>
          </div>
        ) : (
          <ol className="relative space-y-6 border-l border-white/10 pl-6">
            {items.map((it) => {
              const Icon = ICONS[it.event_type] ?? Clock;
              const tone = TONE[it.event_type] ?? "from-slate-400 to-slate-600";
              return (
                <li key={it.id} className="animate-fade-in">
                  <span
                    className={`absolute -left-[13px] grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br ${tone} ring-4 ring-[#0b1020]`}
                  >
                    <Icon className="h-3.5 w-3.5 text-white" />
                  </span>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium capitalize">
                      {it.event_type.replace("_", " ")}
                    </p>
                    <time className="text-xs text-slate-400">{formatDate(it.event_at)}</time>
                  </div>
                  {it.detail && <p className="mt-1 text-sm text-slate-400">{it.detail}</p>}
                </li>
              );
            })}
          </ol>
        )}
      </div>
    </div>
  );
}
