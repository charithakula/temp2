"use client";

import { Moon, Sun, Monitor, Check, Mail, Bell, RefreshCw, Palette } from "lucide-react";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { api, Me } from "@/lib/api";
import { useTheme, Theme, Background } from "@/lib/theme";
import { cn } from "@/lib/utils";

const PREFS_KEY = "devportal:prefs";

type Prefs = {
  autoRenewDefault: boolean;
  emailReminders: boolean;
  inAppReminders: boolean;
};

const DEFAULT_PREFS: Prefs = {
  autoRenewDefault: false,
  emailReminders: true,
  inAppReminders: true,
};

export default function SettingsPage() {
  return (
    <Shell>
      <Settings />
    </Shell>
  );
}

function Settings() {
  const { theme, background, setTheme, setBackground } = useTheme();
  const [me, setMe] = useState<Me | null>(null);
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api.me().then(setMe).catch(() => setMe(null));
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      if (raw) setPrefs({ ...DEFAULT_PREFS, ...JSON.parse(raw) });
    } catch {
      /* ignore */
    }
  }, []);

  function update(patch: Partial<Prefs>) {
    const next = { ...prefs, ...patch };
    setPrefs(next);
    localStorage.setItem(PREFS_KEY, JSON.stringify(next));
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-slate-400">
          Personalize the portal&apos;s appearance and your notification preferences.
        </p>
      </div>

      {/* Profile */}
      <section className="glass p-6">
        <h2 className="text-lg font-semibold">Profile</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Name" value={me?.display_name || "—"} />
          <Field label="Email" value={me?.email || "—"} />
          <Field label="Role" value={me?.is_admin ? "Administrator" : "Developer"} />
        </div>
      </section>

      {/* Appearance */}
      <section className="glass p-6">
        <div className="flex items-center gap-2">
          <Palette className="h-5 w-5 text-brand-300" />
          <h2 className="text-lg font-semibold">Appearance</h2>
        </div>

        <p className="mt-4 mb-2 text-sm font-medium">Theme</p>
        <div className="grid gap-3 sm:grid-cols-3">
          <ThemeChoice current={theme} value="light" icon={Sun} label="Light" onSelect={setTheme} />
          <ThemeChoice current={theme} value="dark" icon={Moon} label="Dark" onSelect={setTheme} />
          <ThemeChoice
            current={theme}
            value="system"
            icon={Monitor}
            label="System"
            onSelect={setTheme}
          />
        </div>

        <p className="mt-6 mb-2 text-sm font-medium">Background</p>
        <div className="grid gap-3 sm:grid-cols-3">
          <BgChoice current={background} value="aurora" label="Aurora" onSelect={setBackground} />
          <BgChoice current={background} value="mesh" label="Mesh" onSelect={setBackground} />
          <BgChoice current={background} value="plain" label="Plain" onSelect={setBackground} />
        </div>
      </section>

      {/* Preferences */}
      <section className="glass p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Subscription &amp; notifications</h2>
          {saved && (
            <span className="chip bg-emerald-400/15 text-emerald-300 ring-1 ring-emerald-400/30">
              <Check className="h-3 w-3" /> Saved
            </span>
          )}
        </div>
        <div className="mt-4 space-y-1">
          <Toggle
            icon={RefreshCw}
            label="Auto-renew new subscriptions by default"
            desc="New subscriptions you create will renew automatically before expiry."
            checked={prefs.autoRenewDefault}
            onChange={(v) => update({ autoRenewDefault: v })}
          />
          <Toggle
            icon={Bell}
            label="In-app renewal reminders"
            desc="Show reminders in the notification bell as subscriptions approach expiry."
            checked={prefs.inAppReminders}
            onChange={(v) => update({ inAppReminders: v })}
          />
          <Toggle
            icon={Mail}
            label="Email renewal reminders"
            desc="Receive an email at 30, 7, and 1 day before a subscription expires."
            checked={prefs.emailReminders}
            onChange={(v) => update({ emailReminders: v })}
          />
        </div>
        <p className="mt-4 text-xs text-slate-500">
          Preferences are stored in this browser. Reminder schedules are also enforced
          server-side by the daily scheduler.
        </p>
      </section>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="mt-0.5 truncate font-medium">{value}</p>
    </div>
  );
}

function ThemeChoice({
  current,
  value,
  icon: Icon,
  label,
  onSelect,
}: {
  current: Theme;
  value: Theme;
  icon: typeof Sun;
  label: string;
  onSelect: (t: Theme) => void;
}) {
  const active = current === value;
  return (
    <button
      onClick={() => onSelect(value)}
      className={cn(
        "flex items-center justify-between rounded-xl border px-4 py-3 text-sm font-medium transition",
        active
          ? "border-transparent bg-gradient-to-r from-brand-500 to-brand-600 text-white shadow-lg shadow-brand-500/20"
          : "border-white/10 bg-white/5 text-slate-200 hover:bg-white/10",
      )}
    >
      <span className="flex items-center gap-2">
        <Icon className="h-4 w-4" /> {label}
      </span>
      {active && <Check className="h-4 w-4 text-white" />}
    </button>
  );
}

const BG_SWATCH: Record<Background, string> = {
  aurora: "from-indigo-500/60 to-sky-400/50",
  mesh: "from-fuchsia-500/50 via-indigo-500/50 to-sky-400/50",
  plain: "from-slate-600/60 to-slate-800/60",
};

function BgChoice({
  current,
  value,
  label,
  onSelect,
}: {
  current: Background;
  value: Background;
  label: string;
  onSelect: (b: Background) => void;
}) {
  const active = current === value;
  return (
    <button
      onClick={() => onSelect(value)}
      className={cn(
        "rounded-xl border-2 p-1 text-left transition",
        active
          ? "border-brand-500 ring-2 ring-brand-500/25"
          : "border-white/10 hover:border-white/25",
      )}
    >
      <div className={cn("h-14 w-full rounded-lg bg-gradient-to-br", BG_SWATCH[value])} />
      <div className="flex items-center justify-between px-2 py-1.5 text-sm font-medium">
        {label}
        {active && <Check className="h-4 w-4 text-brand-500" />}
      </div>
    </button>
  );
}

function Toggle({
  icon: Icon,
  label,
  desc,
  checked,
  onChange,
}: {
  icon: typeof Bell;
  label: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-start justify-between gap-4 rounded-xl px-2 py-3 transition hover:bg-white/5">
      <span className="flex gap-3">
        <Icon className="mt-0.5 h-5 w-5 shrink-0 text-brand-300" />
        <span>
          <span className="block text-sm font-medium">{label}</span>
          <span className="block text-xs text-slate-400">{desc}</span>
        </span>
      </span>
      <span
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "mt-1 inline-flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition",
          checked ? "bg-brand-500" : "bg-white/15",
        )}
      >
        <span
          className={cn(
            "h-5 w-5 transform rounded-full bg-white transition",
            checked ? "translate-x-5" : "translate-x-0",
          )}
        />
      </span>
    </label>
  );
}
