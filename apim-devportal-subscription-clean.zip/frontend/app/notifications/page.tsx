"use client";

import { Bell, BellOff, Check, CheckCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { api, Notification } from "@/lib/api";
import { formatDate } from "@/lib/utils";

export default function NotificationsPage() {
  return (
    <Shell>
      <Notifications />
    </Shell>
  );
}

function Notifications() {
  const [items, setItems] = useState<Notification[] | null>(null);

  function load() {
    api.notifications().then(setItems).catch(() => setItems([]));
  }
  useEffect(load, []);

  async function markRead(id: number) {
    await api.markRead(id);
    setItems((prev) => prev?.map((n) => (n.id === id ? { ...n, is_read: true } : n)) ?? null);
  }

  async function markAllRead() {
    await api.markAllRead();
    setItems((prev) => prev?.map((n) => ({ ...n, is_read: true })) ?? null);
  }

  const unread = items?.filter((n) => !n.is_read).length ?? 0;

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Notifications</h1>
          <p className="mt-1 text-sm text-slate-400">
            Renewal reminders and subscription updates.
          </p>
        </div>
        {unread > 0 && (
          <button onClick={markAllRead} className="btn-ghost shrink-0">
            <CheckCheck className="h-4 w-4" /> Mark all read
          </button>
        )}
      </div>

      <div className="glass p-2">
        {items === null ? (
          <div className="space-y-2 p-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-16 animate-pulse rounded-xl bg-white/5" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="grid place-items-center py-16 text-center">
            <BellOff className="h-10 w-10 text-slate-400" />
            <p className="mt-3 font-medium">No notifications</p>
          </div>
        ) : (
          <ul className="divide-y divide-white/5">
            {items.map((n) => (
              <li
                key={n.id}
                className={`flex items-start gap-4 rounded-xl px-4 py-4 ${
                  n.is_read ? "opacity-60" : "bg-white/5"
                }`}
              >
                <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600">
                  <Bell className="h-4 w-4 text-white" />
                </div>
                <div className="flex-1">
                  <p>{n.message}</p>
                  <p className="mt-1 text-xs text-slate-400">{formatDate(n.sent_at)}</p>
                </div>
                {!n.is_read && (
                  <button onClick={() => markRead(n.id)} className="btn-ghost">
                    <Check className="h-4 w-4" /> Mark read
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
