"use client";

import {
  Users,
  KeyRound,
  ShieldCheck,
  AlertTriangle,
  Ban,
  Clock,
  Loader2,
  Lock,
  Check,
  X,
  Inbox,
  AppWindow,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { StatCard } from "@/components/StatCard";
import { StatusBadge } from "@/components/StatusBadge";
import { api, AdminStats, Subscription } from "@/lib/api";
import { formatDate } from "@/lib/utils";

export default function AdminPage() {
  return (
    <Shell>
      <Admin />
    </Shell>
  );
}

function Admin() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [subs, setSubs] = useState<Subscription[] | null>(null);
  const [pending, setPending] = useState<Subscription[] | null>(null);
  const [forbidden, setForbidden] = useState(false);
  const [busy, setBusy] = useState<number | null>(null);

  function load() {
    Promise.all([api.adminStats(), api.adminSubscriptions(), api.adminPending()])
      .then(([s, list, pend]) => {
        setStats(s);
        setSubs(list);
        setPending(pend);
      })
      .catch((e) => {
        if (String(e.message ?? e).startsWith("403")) setForbidden(true);
        setSubs([]);
        setPending([]);
      });
  }
  useEffect(load, []);

  async function approve(id: number) {
    setBusy(id);
    try {
      await api.adminApprove(id);
      load();
    } finally {
      setBusy(null);
    }
  }

  async function reject(id: number) {
    const reason = prompt("Reason for rejection (optional):") ?? "";
    setBusy(id);
    try {
      await api.adminReject(id, reason);
      load();
    } finally {
      setBusy(null);
    }
  }

  async function expire(id: number) {
    setBusy(id);
    try {
      await api.adminExpire(id);
      load();
    } finally {
      setBusy(null);
    }
  }

  async function revoke(id: number) {
    if (!confirm("Revoke this subscription for the user? This deletes it in API Management.")) return;
    setBusy(id);
    try {
      await api.adminRevoke(id);
      load();
    } finally {
      setBusy(null);
    }
  }

  if (forbidden) {
    return (
      <div className="glass grid place-items-center py-20 text-center">
        <Lock className="h-10 w-10 text-rose-300" />
        <p className="mt-3 text-lg font-semibold">Admin access required</p>
        <p className="text-sm text-slate-400">
          Your account doesn&apos;t have administrator privileges.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Admin console</h1>
        <p className="mt-1 text-sm text-slate-400">
          Manage every developer&apos;s subscriptions across the portal.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Pending approval"
          value={stats?.pending ?? "—"}
          icon={Clock}
          accent="from-amber-400 to-orange-500"
        />
        <StatCard
          label="Active"
          value={stats?.active ?? "—"}
          icon={KeyRound}
          accent="from-emerald-400 to-teal-500"
        />
        <StatCard
          label="Expired"
          value={stats?.expired ?? "—"}
          icon={AlertTriangle}
          accent="from-rose-400 to-rose-600"
        />
        <StatCard label="Users" value={stats?.users ?? "—"} icon={Users} />
      </div>

      {/* Approval queue */}
      <div className="glass overflow-hidden">
        <div className="flex items-center gap-2 border-b border-white/10 px-6 py-4">
          <Inbox className="h-5 w-5 text-amber-300" />
          <h2 className="text-lg font-semibold">Approval queue</h2>
          {pending && pending.length > 0 && (
            <span className="chip bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/30">
              {pending.length} waiting
            </span>
          )}
        </div>

        {pending === null ? (
          <div className="space-y-2 p-4">
            {[0, 1].map((i) => (
              <div key={i} className="h-16 animate-pulse rounded-xl bg-white/5" />
            ))}
          </div>
        ) : pending.length === 0 ? (
          <div className="grid place-items-center py-10 text-center">
            <Check className="h-8 w-8 text-emerald-400" />
            <p className="mt-2 text-sm font-medium">No pending requests</p>
            <p className="text-xs text-slate-400">All subscription requests have been handled.</p>
          </div>
        ) : (
          <ul className="divide-y divide-white/5">
            {pending.map((s) => (
              <li
                key={s.id}
                className="flex flex-col gap-3 px-6 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="font-medium">{s.product_name}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
                    <span>{s.user_email}</span>
                    {s.app_name && (
                      <span className="flex items-center gap-1">
                        <AppWindow className="h-3 w-3" /> {s.app_name}
                      </span>
                    )}
                    <span>Requested {formatDate(s.start_date)}</span>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <button
                    onClick={() => approve(s.id)}
                    disabled={busy === s.id}
                    className="btn-primary"
                  >
                    {busy === s.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Check className="h-4 w-4" />
                    )}
                    Approve
                  </button>
                  <button
                    onClick={() => reject(s.id)}
                    disabled={busy === s.id}
                    className="btn-ghost text-rose-300 hover:bg-rose-400/10"
                  >
                    <X className="h-4 w-4" /> Reject
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="glass overflow-hidden">
        <div className="flex items-center gap-2 border-b border-white/10 px-6 py-4">
          <ShieldCheck className="h-5 w-5 text-brand-300" />
          <h2 className="text-lg font-semibold">All subscriptions</h2>
        </div>

        {subs === null ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-14 animate-pulse rounded-xl bg-white/5" />
            ))}
          </div>
        ) : subs.length === 0 ? (
          <p className="px-6 py-10 text-center text-sm text-slate-400">No subscriptions yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wide text-slate-400">
                <tr className="border-b border-white/10">
                  <th className="px-6 py-3 font-medium">User</th>
                  <th className="px-6 py-3 font-medium">App</th>
                  <th className="px-6 py-3 font-medium">Product</th>
                  <th className="px-6 py-3 font-medium">Status</th>
                  <th className="px-6 py-3 font-medium">Expires</th>
                  <th className="px-6 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {subs.map((s) => (
                  <tr key={s.id} className="border-b border-white/5 last:border-0">
                    <td className="px-6 py-3">
                      <span className="font-medium">{s.user_email ?? "—"}</span>
                    </td>
                    <td className="px-6 py-3 text-slate-300">{s.app_name ?? "—"}</td>
                    <td className="px-6 py-3">
                      <span className="font-medium">{s.product_name}</span>
                      <span className="block font-mono text-xs text-slate-400">
                        {s.apim_subscription_id || "—"}
                      </span>
                    </td>
                    <td className="px-6 py-3">
                      <StatusBadge status={s.status} />
                    </td>
                    <td className="px-6 py-3 text-slate-300">{formatDate(s.end_date)}</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center justify-end gap-2">
                        {s.status === "active" && (
                          <button
                            onClick={() => expire(s.id)}
                            disabled={busy === s.id}
                            className="btn-ghost text-amber-300 hover:bg-amber-400/10"
                            title="Force-expire"
                          >
                            {busy === s.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Clock className="h-4 w-4" />
                            )}
                            Expire
                          </button>
                        )}
                        {s.status !== "revoked" && (
                          <button
                            onClick={() => revoke(s.id)}
                            disabled={busy === s.id}
                            className="btn-ghost text-rose-300 hover:bg-rose-400/10"
                            title="Revoke"
                          >
                            <Ban className="h-4 w-4" />
                            Revoke
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
