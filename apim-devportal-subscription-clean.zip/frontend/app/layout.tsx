import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "API Developer Portal",
  description: "Subscribe to APIs, track subscriptions, and manage renewals.",
};

// Runs before first paint to set the theme, avoiding a flash of the wrong colors.
const themeInit = `
(function () {
  try {
    var t = localStorage.getItem('devportal:theme') || 'dark';
    var b = localStorage.getItem('devportal:bg') || 'aurora';
    var dark = t === 'dark' || (t === 'system' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.documentElement.dataset.bg = b;
  } catch (e) {
    document.documentElement.dataset.theme = 'dark';
    document.documentElement.dataset.bg = 'aurora';
  }
})();
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" data-bg="aurora">
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
