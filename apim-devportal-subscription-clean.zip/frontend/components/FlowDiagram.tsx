"use client";

import { AppWindow, Boxes, ShieldCheck, CheckCircle2, ArrowRight, Zap } from "lucide-react";

type Step = {
  icon: typeof AppWindow;
  title: string;
  desc: string;
  accent: string;
};

const STEPS: Step[] = [
  {
    icon: AppWindow,
    title: "1. Create an App",
    desc: "Register a named application that will own your subscriptions.",
    accent: "from-brand-400 to-brand-600",
  },
  {
    icon: Boxes,
    title: "2. Subscribe to a product",
    desc: "Pick an API product from the catalog and subscribe your app to it.",
    accent: "from-sky-400 to-cyan-500",
  },
  {
    icon: ShieldCheck,
    title: "3. Admin approval",
    desc: "Approval-required products are created in APIM as 'submitted'; an admin approves (→ active) or rejects (→ cancelled).",
    accent: "from-amber-400 to-orange-500",
  },
  {
    icon: CheckCircle2,
    title: "4. Active + keys",
    desc: "Once active, APIM issues primary/secondary keys you use to call the API. Open products skip approval.",
    accent: "from-emerald-400 to-teal-500",
  },
];

/**
 * A horizontal (desktop) / vertical (mobile) flow showing the
 * App → Subscribe → Approval → Active lifecycle.
 */
export function FlowDiagram({ compact = false }: { compact?: boolean }) {
  return (
    <div className="glass animate-fade-in p-6">
      <div className="mb-5 flex items-center gap-2">
        <Zap className="h-5 w-5 text-brand-300" />
        <h2 className="text-lg font-semibold">How subscriptions work</h2>
      </div>

      <div className="flex flex-col gap-3 lg:flex-row lg:items-stretch">
        {STEPS.map((s, i) => (
          <div key={s.title} className="flex flex-1 items-stretch gap-3 lg:flex-col lg:gap-0">
            <div className="flex flex-1 flex-col rounded-xl border border-white/10 bg-white/5 p-4">
              <div
                className={`grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${s.accent}`}
              >
                <s.icon className="h-5 w-5 text-white" />
              </div>
              <p className="mt-3 text-sm font-semibold">{s.title}</p>
              {!compact && <p className="mt-1 text-xs text-slate-400">{s.desc}</p>}
            </div>

            {/* Connector arrow between steps */}
            {i < STEPS.length - 1 && (
              <div className="flex shrink-0 items-center justify-center lg:py-2">
                <ArrowRight className="h-5 w-5 rotate-90 text-slate-400 lg:rotate-0" />
              </div>
            )}
          </div>
        ))}
      </div>

      <p className="mt-4 text-xs text-slate-500">
        Open products (no approval required) skip step 3 and activate instantly.
      </p>
    </div>
  );
}
