import { cn } from "@/lib/utils";

const STYLES: Record<string, string> = {
  active: "bg-emerald-400/15 text-emerald-300 ring-1 ring-emerald-400/30",
  pending: "bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/30",
  expired: "bg-rose-400/15 text-rose-300 ring-1 ring-rose-400/30",
  revoked: "bg-slate-400/15 text-slate-300 ring-1 ring-slate-400/30",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn("chip capitalize", STYLES[status] ?? STYLES.revoked)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </span>
  );
}

export function ExpiryBadge({ days }: { days: number }) {
  const tone =
    days < 0
      ? "bg-rose-400/15 text-rose-300 ring-1 ring-rose-400/30"
      : days <= 7
        ? "bg-amber-400/15 text-amber-300 ring-1 ring-amber-400/30"
        : "bg-brand-400/15 text-brand-100 ring-1 ring-brand-400/30";
  const label = days < 0 ? "Expired" : days === 0 ? "Expires today" : `${days} days left`;
  return <span className={cn("chip", tone)}>{label}</span>;
}
