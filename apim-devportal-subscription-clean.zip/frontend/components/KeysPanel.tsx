"use client";

import { Eye, EyeOff, Copy, Check, RefreshCw, Loader2, KeyRound } from "lucide-react";
import { useState } from "react";
import { api, SubscriptionKeys } from "@/lib/api";

/**
 * Shows the APIM-generated primary/secondary keys for an active subscription.
 * Masked by default; reveal fetches the real keys, copy and regenerate act on them.
 */
export function KeysPanel({ subId }: { subId: number }) {
  const [keys, setKeys] = useState<SubscriptionKeys | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<"primary" | "secondary" | null>(null);
  const [copied, setCopied] = useState<"primary" | "secondary" | null>(null);

  async function toggle() {
    if (revealed) {
      setRevealed(false);
      return;
    }
    setLoading(true);
    try {
      setKeys(await api.keys(subId, true));
      setRevealed(true);
    } finally {
      setLoading(false);
    }
  }

  async function copy(which: "primary" | "secondary") {
    const val = which === "primary" ? keys?.primary_key : keys?.secondary_key;
    if (!val) return;
    await navigator.clipboard.writeText(val);
    setCopied(which);
    setTimeout(() => setCopied(null), 1500);
  }

  async function regenerate(which: "primary" | "secondary") {
    if (!confirm(`Regenerate the ${which} key? The old key stops working immediately.`)) return;
    setBusy(which);
    try {
      const next = await api.regenerateKey(subId, which);
      setKeys(next);
      setRevealed(true);
    } finally {
      setBusy(null);
    }
  }

  const display = (which: "primary" | "secondary") => {
    if (!revealed) return "••••••••••••••••••••••••";
    return (which === "primary" ? keys?.primary_key : keys?.secondary_key) ?? "—";
  };

  return (
    <div className="mt-4 rounded-xl border border-white/10 bg-white/5 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-400">
          <KeyRound className="h-3.5 w-3.5" /> Subscription keys
        </p>
        <button
          onClick={toggle}
          disabled={loading}
          className="flex items-center gap-1.5 text-xs text-brand-300 transition hover:text-brand-200"
        >
          {loading ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : revealed ? (
            <EyeOff className="h-3.5 w-3.5" />
          ) : (
            <Eye className="h-3.5 w-3.5" />
          )}
          {revealed ? "Hide" : "Reveal"}
        </button>
      </div>

      {(["primary", "secondary"] as const).map((which) => (
        <div key={which} className="mb-2 flex items-center gap-2 last:mb-0">
          <span className="w-20 shrink-0 text-xs capitalize text-slate-400">{which}</span>
          <code className="min-w-0 flex-1 truncate rounded-lg bg-black/20 px-2 py-1.5 font-mono text-xs">
            {display(which)}
          </code>
          <button
            onClick={() => copy(which)}
            disabled={!revealed}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white disabled:opacity-40"
            title="Copy"
          >
            {copied === which ? (
              <Check className="h-4 w-4 text-emerald-400" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </button>
          <button
            onClick={() => regenerate(which)}
            disabled={busy === which}
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-amber-400/10 hover:text-amber-300"
            title="Regenerate"
          >
            {busy === which ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </button>
        </div>
      ))}
    </div>
  );
}
