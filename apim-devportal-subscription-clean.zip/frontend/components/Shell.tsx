"use client";

import { useMsal } from "@azure/msal-react";
import {
  LayoutDashboard,
  Boxes,
  KeyRound,
  LogOut,
  Cloud,
  Bell,
  Settings,
  ShieldCheck,
  ChevronDown,
  AppWindow,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode, useEffect, useRef, useState } from "react";
import { loginRequest, DEMO_MODE } from "@/lib/msal";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";
import { NotificationBell } from "./NotificationBell";

const DEMO_USER = { name: "Demo Developer", username: "demo.developer@example.com" };

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/products", label: "Products", icon: Boxes },
  { href: "/apps", label: "Applications", icon: AppWindow },
  { href: "/subscriptions", label: "Subscriptions", icon: KeyRound },
  { href: "/notifications", label: "Notifications", icon: Bell },
  { href: "/settings", label: "Settings", icon: Settings },
];

const ADMIN_NAV = { href: "/admin", label: "Admin", icon: ShieldCheck };

export function Shell({ children }: { children: ReactNode }) {
  const { instance, accounts } = useMsal();
  const pathname = usePathname();
  const [signedIn, setSignedIn] = useState(DEMO_MODE);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setSignedIn(DEMO_MODE || accounts.length > 0);
  }, [accounts]);

  // Discover admin status from the backend so the Admin nav item appears.
  useEffect(() => {
    if (!signedIn) return;
    api
      .me()
      .then((me) => setIsAdmin(!!me.is_admin))
      .catch(() => setIsAdmin(false));
  }, [signedIn]);

  if (!signedIn) {
    return <Login onLogin={() => instance.loginRedirect(loginRequest)} />;
  }

  const account = DEMO_MODE ? DEMO_USER : accounts[0];
  const signOut = () => (DEMO_MODE ? undefined : instance.logoutRedirect());
  const nav = isAdmin ? [...NAV, ADMIN_NAV] : NAV;

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="glass sticky top-0 hidden h-screen w-64 shrink-0 flex-col rounded-none p-4 lg:flex">
        <div className="mb-8 flex items-center gap-2 px-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600">
            <Cloud className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">API Portal</p>
            <p className="text-xs text-slate-400">Developer</p>
          </div>
        </div>

        <nav className="space-y-1">
          {nav.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || (href !== "/" && pathname.startsWith(href));
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                  active
                    ? "nav-active bg-gradient-to-r from-brand-500 to-brand-600 text-white shadow-lg shadow-brand-500/20"
                    : "text-slate-300 hover:bg-white/5 hover:text-white",
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto space-y-3">
          {DEMO_MODE && (
            <p className="rounded-xl bg-amber-400/10 px-3 py-2 text-xs text-amber-300 ring-1 ring-amber-400/20">
              Demo mode — no sign-in required
            </p>
          )}
          {!DEMO_MODE && (
            <button
              onClick={signOut}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 transition hover:bg-white/5 hover:text-white"
            >
              <LogOut className="h-4 w-4" />
              Sign out
            </button>
          )}
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="glass sticky top-0 z-10 flex items-center justify-between rounded-none px-6 py-4">
          <div className="lg:hidden text-sm font-semibold">API Portal</div>
          <div className="hidden lg:block text-sm text-slate-400">
            Welcome back,{" "}
            <span className="text-slate-100">{account?.name ?? account?.username}</span>
          </div>
          <div className="flex items-center gap-3">
            <NotificationBell />
            <AccountMenu
              name={account?.name ?? account?.username ?? "User"}
              email={account?.username ?? ""}
              isAdmin={isAdmin}
              onSignOut={signOut}
            />
          </div>
        </header>

        <main className="mx-auto w-full max-w-6xl flex-1 px-6 py-8">{children}</main>
      </div>
    </div>
  );
}

function AccountMenu({
  name,
  email,
  isAdmin,
  onSignOut,
}: {
  name: string;
  email: string;
  isAdmin: boolean;
  onSignOut: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 py-1 pl-1 pr-2 transition hover:bg-white/10"
        aria-label="Account menu"
      >
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 text-sm font-semibold text-white">
          {name.charAt(0).toUpperCase()}
        </span>
        <ChevronDown className="h-4 w-4 text-slate-400" />
      </button>

      {open && (
        <div className="glass absolute right-0 z-20 mt-2 w-64 animate-fade-in overflow-hidden p-0">
          <div className="border-b border-white/10 px-4 py-3">
            <p className="truncate text-sm font-semibold">{name}</p>
            {email && <p className="truncate text-xs text-slate-400">{email}</p>}
            {isAdmin && (
              <span className="chip mt-2 bg-brand-400/15 text-brand-100 ring-1 ring-brand-400/30">
                <ShieldCheck className="h-3 w-3" /> Admin
              </span>
            )}
          </div>
          <div className="p-1">
            <Link
              href="/settings"
              onClick={() => setOpen(false)}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-200 transition hover:bg-white/10"
            >
              <Settings className="h-4 w-4" /> Settings
            </Link>
            {isAdmin && (
              <Link
                href="/admin"
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-200 transition hover:bg-white/10"
              >
                <ShieldCheck className="h-4 w-4" /> Admin console
              </Link>
            )}
            <button
              onClick={onSignOut}
              disabled={DEMO_MODE}
              title={DEMO_MODE ? "Sign-out is disabled in demo mode" : "Sign out"}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-rose-300 transition hover:bg-rose-400/10 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <LogOut className="h-4 w-4" /> {DEMO_MODE ? "Sign out (demo)" : "Sign out"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Login({ onLogin }: { onLogin: () => void }) {
  return (
    <div className="grid min-h-screen place-items-center px-6">
      <div className="glass w-full max-w-md animate-fade-in p-8 text-center">
        <div className="mx-auto mb-6 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600">
          <Cloud className="h-7 w-7 text-white" />
        </div>
        <h1 className="text-2xl font-semibold">API Developer Portal</h1>
        <p className="mt-2 text-sm text-slate-400">
          Subscribe to APIs, track your subscriptions, and stay ahead of renewals.
        </p>
        <button onClick={onLogin} className="btn-primary mt-8 w-full">
          Sign in with Microsoft
        </button>
        <p className="mt-4 text-xs text-slate-500">Secured by Microsoft Entra ID</p>
      </div>
    </div>
  );
}
