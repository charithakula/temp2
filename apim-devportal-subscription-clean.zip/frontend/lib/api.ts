"use client";

import { getMsal, apiScope, DEMO_MODE } from "./msal";

const BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";

export type Product = {
  id: string;
  name: string;
  description: string;
  approval_required: boolean;
};

export type Subscription = {
  id: number;
  apim_subscription_id: string;
  product_id: string;
  product_name: string;
  status: "pending" | "active" | "expired" | "revoked";
  start_date: string;
  end_date: string;
  auto_renew: boolean;
  app_id?: number | null;
  app_name?: string | null;
  user_email?: string | null;
};

export type App = {
  id: number;
  name: string;
  description: string;
  created_at: string;
  subscription_count: number;
};

export type SubscriptionKeys = {
  primary_key: string | null;
  secondary_key: string | null;
  masked: boolean;
};

export type Me = {
  id: number;
  email: string;
  display_name: string;
  is_admin: boolean;
};

export type AdminUser = {
  id: number;
  email: string;
  display_name: string;
  is_admin: boolean;
  subscriptions: Subscription[];
};

export type AdminStats = {
  users: number;
  subscriptions: number;
  pending: number;
  active: number;
  expired: number;
  revoked: number;
};

export type HistoryItem = {
  id: number;
  event_type: string;
  detail: string;
  event_at: string;
};

export type Notification = {
  id: number;
  type: string;
  channel: string;
  message: string;
  is_read: boolean;
  sent_at: string;
};

async function token(): Promise<string> {
  const msal = getMsal();
  const account = msal.getActiveAccount() ?? msal.getAllAccounts()[0];
  if (!account) throw new Error("Not signed in");
  const res = await msal.acquireTokenSilent({ scopes: [apiScope], account });
  return res.accessToken;
}

async function call<T>(path: string, init: RequestInit = {}): Promise<T> {
  const authHeaders: Record<string, string> = DEMO_MODE
    ? {}
    : { Authorization: `Bearer ${await token()}` };
  const res = await fetch(`${BASE}/api${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders,
      ...(init.headers ?? {}),
    },
  });
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
}

export const api = {
  me: () => call<Me>("/me"),
  products: () => call<Product[]>("/products"),
  subscriptions: () => call<Subscription[]>("/subscriptions"),
  subscribe: (
    product_id: string,
    opts: { app_id?: number | null; term_days?: number; auto_renew?: boolean } = {},
  ) =>
    call<Subscription>("/subscriptions", {
      method: "POST",
      body: JSON.stringify({
        product_id,
        app_id: opts.app_id ?? null,
        term_days: opts.term_days ?? 365,
        auto_renew: opts.auto_renew ?? false,
      }),
    }),
  // Applications
  apps: () => call<App[]>("/apps"),
  createApp: (name: string, description = "") =>
    call<App>("/apps", { method: "POST", body: JSON.stringify({ name, description }) }),
  appSubscriptions: (id: number) => call<Subscription[]>(`/apps/${id}/subscriptions`),
  deleteApp: (id: number) => call<void>(`/apps/${id}`, { method: "DELETE" }),
  renew: (id: number, term_days = 365) =>
    call<Subscription>(`/subscriptions/${id}/renew?term_days=${term_days}`, { method: "POST" }),
  revoke: (id: number) => call<void>(`/subscriptions/${id}`, { method: "DELETE" }),
  history: (id: number) => call<HistoryItem[]>(`/subscriptions/${id}/history`),
  keys: (id: number, reveal = false) =>
    call<SubscriptionKeys>(`/subscriptions/${id}/keys${reveal ? "?reveal=true" : ""}`),
  regenerateKey: (id: number, which: "primary" | "secondary") =>
    call<SubscriptionKeys>(`/subscriptions/${id}/keys/${which}/regenerate`, { method: "POST" }),
  notifications: () => call<Notification[]>("/notifications"),
  markRead: (id: number) => call<void>(`/notifications/${id}/read`, { method: "POST" }),
  markAllRead: () => call<void>("/notifications/read-all", { method: "POST" }),
  // Admin
  adminStats: () => call<AdminStats>("/admin/stats"),
  adminUsers: () => call<AdminUser[]>("/admin/users"),
  adminSubscriptions: () => call<Subscription[]>("/admin/subscriptions"),
  adminPending: () => call<Subscription[]>("/admin/pending"),
  adminApprove: (id: number) =>
    call<Subscription>(`/admin/subscriptions/${id}/approve`, { method: "POST" }),
  adminReject: (id: number, reason = "") =>
    call<Subscription>(`/admin/subscriptions/${id}/reject`, {
      method: "POST",
      body: JSON.stringify({ reason }),
    }),
  adminExpire: (id: number) =>
    call<Subscription>(`/admin/subscriptions/${id}/expire`, { method: "POST" }),
  adminRevoke: (id: number) => call<void>(`/admin/subscriptions/${id}`, { method: "DELETE" }),
};
