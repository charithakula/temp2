"use client";

import { createContext, useContext, useEffect, useMemo, useState, ReactNode } from "react";

export type Theme = "light" | "dark" | "system";
export type Background = "aurora" | "mesh" | "plain";

type ThemeState = {
  theme: Theme;
  background: Background;
  resolved: "light" | "dark"; // theme after resolving "system"
  setTheme: (t: Theme) => void;
  setBackground: (b: Background) => void;
};

const THEME_KEY = "devportal:theme";
const BG_KEY = "devportal:bg";

const ThemeContext = createContext<ThemeState | null>(null);

function systemPrefersDark(): boolean {
  if (typeof window === "undefined") return true;
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("dark");
  const [background, setBackgroundState] = useState<Background>("aurora");
  const [systemDark, setSystemDark] = useState(true);

  // Load persisted preferences on mount (client only).
  useEffect(() => {
    const t = (localStorage.getItem(THEME_KEY) as Theme | null) ?? "dark";
    const b = (localStorage.getItem(BG_KEY) as Background | null) ?? "aurora";
    setThemeState(t);
    setBackgroundState(b);
    setSystemDark(systemPrefersDark());

    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const resolved: "light" | "dark" = theme === "system" ? (systemDark ? "dark" : "light") : theme;

  // Reflect the resolved theme + background onto <html> so CSS can react.
  useEffect(() => {
    const el = document.documentElement;
    el.dataset.theme = resolved;
    el.dataset.bg = background;
  }, [resolved, background]);

  const setTheme = (t: Theme) => {
    setThemeState(t);
    localStorage.setItem(THEME_KEY, t);
  };
  const setBackground = (b: Background) => {
    setBackgroundState(b);
    localStorage.setItem(BG_KEY, b);
  };

  const value = useMemo(
    () => ({ theme, background, resolved, setTheme, setBackground }),
    [theme, background, resolved],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeState {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
