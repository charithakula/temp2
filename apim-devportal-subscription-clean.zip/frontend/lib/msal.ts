import { Configuration, PublicClientApplication } from "@azure/msal-browser";

const tenantId = process.env.NEXT_PUBLIC_ENTRA_TENANT_ID ?? "";
const clientId = process.env.NEXT_PUBLIC_ENTRA_CLIENT_ID ?? "";

export const apiScope = process.env.NEXT_PUBLIC_API_SCOPE ?? "";

// When true, the frontend skips MSAL entirely and the backend trusts a demo user.
export const DEMO_MODE = process.env.NEXT_PUBLIC_DEMO_MODE === "true";

export const msalConfig: Configuration = {
  auth: {
    clientId,
    authority: `https://login.microsoftonline.com/${tenantId}`,
    redirectUri: typeof window !== "undefined" ? window.location.origin : "/",
  },
  cache: { cacheLocation: "localStorage" },
};

// Created lazily on the client only.
let _instance: PublicClientApplication | null = null;
export function getMsal(): PublicClientApplication {
  if (!_instance) {
    _instance = new PublicClientApplication(msalConfig);
  }
  return _instance;
}

export const loginRequest = { scopes: [apiScope || "openid", "profile", "email"] };
