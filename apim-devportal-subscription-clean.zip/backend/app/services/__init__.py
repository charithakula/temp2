"""Business logic: subscription lifecycle + notifications/email."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.apim import get_apim_client
from app.config import get_settings
from app.models import (
    HistoryEvent,
    Notification,
    NotificationType,
    Subscription,
    SubscriptionHistory,
    SubscriptionStatus,
    User,
)

settings = get_settings()


def _record_history(db: Session, sub: Subscription, event: HistoryEvent, detail: str = "") -> None:
    db.add(SubscriptionHistory(subscription_id=sub.id, event_type=event, detail=detail))


def _notify(db: Session, user_id: int, sub_id: int | None, ntype: NotificationType, message: str) -> None:
    db.add(
        Notification(
            user_id=user_id, subscription_id=sub_id, type=ntype, channel="in_app", message=message
        )
    )


def _product_meta(product_id: str) -> tuple[str, bool]:
    """Return (display_name, approval_required) for a product id."""
    for p in get_apim_client().list_products():
        if p["id"] == product_id:
            return p.get("name", product_id), bool(p.get("approval_required", False))
    return product_id, False


def _display_name(product_name: str, app_name: str | None, user_email: str) -> str:
    """APIM subscription displayName, stamped with the owning app so it's visible
    in the Azure portal too."""
    if app_name:
        return f"{app_name} · {product_name}"
    return f"{product_name} - {user_email}"


def create_subscription(
    db: Session,
    user: User,
    product_id: str,
    term_days: int,
    auto_renew: bool,
    app_id: int | None = None,
    app_name: str | None = None,
) -> Subscription:
    """Create the subscription in APIM and mirror it locally.

    APIM is the source of truth for the subscription's *state*: approval-required
    products are created in the ``submitted`` state (APIM holds them pending);
    open products are created ``active``. Our DB row mirrors that state and adds
    the lifecycle data APIM lacks (expiry, renewal, history).
    """
    product_name, approval_required = _product_meta(product_id)
    now = datetime.now(timezone.utc)

    apim = get_apim_client()
    apim_sub_id = f"sub-{uuid.uuid4().hex[:12]}"
    apim_state = "submitted" if approval_required else "active"
    apim.create_subscription(
        apim_sub_id,
        user.email,
        product_id,
        state=apim_state,
        display_name=_display_name(product_name, app_name, user.email),
    )

    status = SubscriptionStatus.pending if approval_required else SubscriptionStatus.active
    sub = Subscription(
        user_id=user.id,
        app_id=app_id,
        apim_subscription_id=apim_sub_id,
        product_id=product_id,
        product_name=product_name,
        status=status,
        start_date=now,
        end_date=now + timedelta(days=term_days),
        auto_renew=auto_renew,
    )
    db.add(sub)
    db.flush()

    if approval_required:
        _record_history(db, sub, HistoryEvent.submitted, f"Approval requested for {product_name}")
        _notify(
            db,
            user.id,
            sub.id,
            NotificationType.approval_pending,
            f"Your request to subscribe to {product_name} is pending admin approval.",
        )
    else:
        _record_history(
            db, sub, HistoryEvent.created, f"Subscribed to {product_name} for {term_days} days"
        )
    db.commit()
    db.refresh(sub)
    return sub


def approve_subscription(db: Session, sub: Subscription) -> Subscription:
    """Admin approves: transition the APIM subscription from submitted -> active."""
    if sub.status != SubscriptionStatus.pending:
        return sub
    if sub.apim_subscription_id:
        get_apim_client().set_subscription_state(sub.apim_subscription_id, "active")
    sub.status = SubscriptionStatus.active
    _record_history(db, sub, HistoryEvent.approved, "Approved by admin")
    _notify(
        db,
        sub.user_id,
        sub.id,
        NotificationType.approved,
        f"Your subscription to {sub.product_name} was approved and is now active.",
    )
    db.commit()
    db.refresh(sub)
    return sub


def reject_subscription(db: Session, sub: Subscription, reason: str = "") -> Subscription:
    """Admin rejects: cancel the APIM subscription (submitted -> cancelled)."""
    if sub.status != SubscriptionStatus.pending:
        return sub
    if sub.apim_subscription_id:
        get_apim_client().set_subscription_state(sub.apim_subscription_id, "cancelled")
    sub.status = SubscriptionStatus.revoked
    detail = f"Rejected by admin{f': {reason}' if reason else ''}"
    _record_history(db, sub, HistoryEvent.rejected, detail)
    _notify(
        db,
        sub.user_id,
        sub.id,
        NotificationType.rejected,
        f"Your request to subscribe to {sub.product_name} was rejected."
        + (f" Reason: {reason}" if reason else ""),
    )
    db.commit()
    db.refresh(sub)
    return sub


def renew_subscription(db: Session, sub: Subscription, term_days: int = 365) -> Subscription:
    base = max(sub.end_date, datetime.now(timezone.utc))
    sub.end_date = base + timedelta(days=term_days)
    sub.status = SubscriptionStatus.active
    if sub.apim_subscription_id:
        get_apim_client().set_subscription_state(sub.apim_subscription_id, "active")
    _record_history(db, sub, HistoryEvent.renewed, f"Renewed for {term_days} days")
    _notify(db, sub.user_id, sub.id, NotificationType.renewed, f"Subscription {sub.product_name} renewed.")
    db.commit()
    db.refresh(sub)
    return sub


def revoke_subscription(db: Session, sub: Subscription) -> None:
    if sub.apim_subscription_id:
        get_apim_client().delete_subscription(sub.apim_subscription_id)
    sub.status = SubscriptionStatus.revoked
    _record_history(db, sub, HistoryEvent.revoked, "Subscription revoked")
    db.commit()


def expire_subscription(db: Session, sub: Subscription, *, by_admin: bool = False) -> Subscription:
    """Force a subscription into the expired state (admin action or scheduler)."""
    if sub.apim_subscription_id:
        get_apim_client().set_subscription_state(sub.apim_subscription_id, "suspended")
    sub.status = SubscriptionStatus.expired
    detail = "Force-expired by admin" if by_admin else "Lapsed"
    _record_history(db, sub, HistoryEvent.expired, detail)
    _notify(
        db,
        sub.user_id,
        sub.id,
        NotificationType.expired,
        f"Your subscription to {sub.product_name} has expired.",
    )
    db.commit()
    db.refresh(sub)
    return sub


def _mask(key: str) -> str:
    """Show only the last 4 chars of an APIM key."""
    if not key:
        return ""
    return ("•" * 8) + key[-4:] if len(key) > 4 else key


def get_subscription_keys(sub: Subscription, *, reveal: bool = False) -> dict:
    """Return the APIM primary/secondary keys for a subscription.

    Keys are only available once the subscription exists in APIM and is active
    (not while pending approval). Masked by default.
    """
    if not sub.apim_subscription_id or sub.status != SubscriptionStatus.active:
        return {"primary_key": None, "secondary_key": None, "masked": True}
    secrets = get_apim_client().list_secrets(sub.apim_subscription_id)
    if reveal:
        return {
            "primary_key": secrets["primary_key"],
            "secondary_key": secrets["secondary_key"],
            "masked": False,
        }
    return {
        "primary_key": _mask(secrets["primary_key"]),
        "secondary_key": _mask(secrets["secondary_key"]),
        "masked": True,
    }


def regenerate_subscription_key(db: Session, sub: Subscription, which: str) -> dict:
    """Regenerate the primary or secondary key in APIM and return the new (revealed) keys."""
    if not sub.apim_subscription_id or sub.status != SubscriptionStatus.active:
        return {"primary_key": None, "secondary_key": None, "masked": True}
    apim = get_apim_client()
    apim.regenerate_key(sub.apim_subscription_id, which)
    _record_history(db, sub, HistoryEvent.renewed, f"Regenerated {which} key")
    db.commit()
    secrets = apim.list_secrets(sub.apim_subscription_id)
    return {
        "primary_key": secrets["primary_key"],
        "secondary_key": secrets["secondary_key"],
        "masked": False,
    }


def send_email(to_email: str, subject: str, body: str) -> None:
    """Send via Azure Communication Services if configured; otherwise log."""
    if not settings.acs_connection_string:
        print(f"[email:stub] to={to_email} subject={subject!r}")
        return
    try:
        from azure.communication.email import EmailClient

        client = EmailClient.from_connection_string(settings.acs_connection_string)
        message = {
            "senderAddress": settings.email_sender,
            "recipients": {"to": [{"address": to_email}]},
            "content": {"subject": subject, "plainText": body},
        }
        client.begin_send(message)
    except Exception as exc:  # noqa: BLE001 - email must never crash the scan
        print(f"[email:error] {exc}")
