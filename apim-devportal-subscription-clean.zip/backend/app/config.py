"""Application settings loaded from environment variables."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Database
    database_url: str = "postgresql+psycopg://devportal:devportal@localhost:5432/devportal"

    # Demo mode — when true, auth is bypassed and a fixed demo user is used.
    # Lets the whole app run with NO Azure/Entra setup. NEVER enable in prod.
    demo_mode: bool = False
    demo_user_email: str = "demo.developer@example.com"
    demo_user_name: str = "Demo Developer"
    demo_user_oid: str = "demo-oid-0001"

    # Entra ID (token validation)
    entra_tenant_id: str = ""
    entra_api_client_id: str = ""  # backend app id == expected token audience

    # APIM management API
    azure_subscription_id: str = ""
    apim_resource_group: str = ""
    apim_service_name: str = ""
    apim_auth: str = "sp"  # "sp" (service principal / DefaultAzureCredential) or "managed_identity"

    # Email (Azure Communication Services)
    acs_connection_string: str = ""
    email_sender: str = "DoNotReply@example.com"

    # Notifications
    reminder_days: str = "30,7,1"

    # CORS
    frontend_origin: str = "http://localhost:3000"

    @property
    def reminder_days_list(self) -> list[int]:
        return [int(d.strip()) for d in self.reminder_days.split(",") if d.strip()]

    @property
    def jwks_url(self) -> str:
        return f"https://login.microsoftonline.com/{self.entra_tenant_id}/discovery/v2.0/keys"

    @property
    def issuer(self) -> str:
        return f"https://login.microsoftonline.com/{self.entra_tenant_id}/v2.0"


@lru_cache
def get_settings() -> Settings:
    return Settings()
