"""Pydantic request/response schemas."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.models import HistoryEvent, NotificationType, SubscriptionStatus


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    display_name: str
    is_admin: bool = False


class AdminUserOut(BaseModel):
    """A user plus their subscriptions, for the admin console."""

    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    display_name: str
    is_admin: bool = False
    subscriptions: list["SubscriptionOut"] = []


class ProductOut(BaseModel):
    id: str
    name: str
    description: str = ""
    approval_required: bool = False


class AppCreate(BaseModel):
    name: str
    description: str = ""


class AppOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: str
    created_at: datetime
    subscription_count: int = 0


class SubscriptionCreate(BaseModel):
    product_id: str
    app_id: int | None = None
    term_days: int = 365
    auto_renew: bool = False


class HistoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    event_type: HistoryEvent
    detail: str
    event_at: datetime


class SubscriptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    apim_subscription_id: str
    product_id: str
    product_name: str
    status: SubscriptionStatus
    start_date: datetime
    end_date: datetime
    auto_renew: bool
    app_id: int | None = None
    app_name: str | None = None
    # Populated only on admin endpoints (from the related user); harmless elsewhere.
    user_email: str | None = None

    @property
    def days_remaining(self) -> int:  # convenience, computed in router if needed
        return (self.end_date - datetime.now(self.end_date.tzinfo)).days


class SubscriptionKeys(BaseModel):
    primary_key: str | None = None
    secondary_key: str | None = None
    masked: bool = True


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    type: NotificationType
    channel: str
    message: str
    is_read: bool
    sent_at: datetime


# Resolve the forward reference to SubscriptionOut in AdminUserOut.
AdminUserOut.model_rebuild()
