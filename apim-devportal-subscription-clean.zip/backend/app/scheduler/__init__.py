"""APScheduler daily job: scan for expiring subscriptions and notify."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from app.config import get_settings
from app.db import SessionLocal
from app.models import (
    HistoryEvent,
    Notification,
    NotificationType,
    Subscription,
    SubscriptionHistory,
    SubscriptionStatus,
    User,
)
from app.services import send_email

settings = get_settings()
scheduler = BackgroundScheduler(timezone="UTC")


def _already_reminded(db, sub: Subscription, day_bucket: int) -> bool:
    tag = f"reminder:{day_bucket}"
    return (
        db.query(SubscriptionHistory)
        .filter(
            SubscriptionHistory.subscription_id == sub.id,
            SubscriptionHistory.event_type == HistoryEvent.reminder_sent,
            SubscriptionHistory.detail == tag,
        )
        .first()
        is not None
    )


def scan_expiring_subscriptions() -> None:
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)

        # Expire any that have lapsed.
        lapsed = (
            db.query(Subscription)
            .filter(Subscription.status == SubscriptionStatus.active, Subscription.end_date < now)
            .all()
        )
        for sub in lapsed:
            sub.status = SubscriptionStatus.expired
            db.add(SubscriptionHistory(subscription_id=sub.id, event_type=HistoryEvent.expired, detail="Lapsed"))
            db.add(
                Notification(
                    user_id=sub.user_id,
                    subscription_id=sub.id,
                    type=NotificationType.expired,
                    message=f"Your subscription to {sub.product_name} has expired.",
                )
            )

        # Reminders at each configured threshold.
        for days in settings.reminder_days_list:
            window_end = now + timedelta(days=days)
            upcoming = (
                db.query(Subscription)
                .filter(
                    Subscription.status == SubscriptionStatus.active,
                    Subscription.end_date > now,
                    Subscription.end_date <= window_end,
                )
                .all()
            )
            for sub in upcoming:
                if _already_reminded(db, sub, days):
                    continue
                user = db.get(User, sub.user_id)
                msg = f"Your subscription to {sub.product_name} expires in ~{days} day(s)."
                db.add(
                    Notification(
                        user_id=sub.user_id,
                        subscription_id=sub.id,
                        type=NotificationType.renewal_reminder,
                        message=msg,
                    )
                )
                db.add(
                    SubscriptionHistory(
                        subscription_id=sub.id,
                        event_type=HistoryEvent.reminder_sent,
                        detail=f"reminder:{days}",
                    )
                )
                if user and user.email:
                    send_email(user.email, "Subscription renewal reminder", msg)

        db.commit()
    finally:
        db.close()


def start_scheduler() -> None:
    if scheduler.running:
        return
    scheduler.add_job(
        scan_expiring_subscriptions,
        CronTrigger(hour=8, minute=0),  # daily 08:00 UTC
        id="scan_expiring",
        replace_existing=True,
    )
    scheduler.start()
