"""Seed the database with a demo user and sample data.

Idempotent: running it again will not duplicate the demo user or its data.

Usage:
    python -m app.seed
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.config import get_settings
from app.db import SessionLocal
from app.models import (
    App,
    HistoryEvent,
    Notification,
    NotificationType,
    Subscription,
    SubscriptionHistory,
    SubscriptionStatus,
    User,
)

settings = get_settings()


def seed() -> None:
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.entra_oid == settings.demo_user_oid).one_or_none()
        if user is None:
            user = User(
                entra_oid=settings.demo_user_oid,
                email=settings.demo_user_email,
                display_name=settings.demo_user_name,
            )
            db.add(user)
            db.commit()
            db.refresh(user)

        if db.query(Subscription).filter(Subscription.user_id == user.id).count() > 0:
            print("Demo data already present — skipping.")
            return

        now = datetime.now(timezone.utc)

        # A demo application that owns the subscriptions.
        app = App(
            user_id=user.id,
            name="Weather Bot",
            description="Demo application that consumes the weather and starter APIs.",
            created_at=now - timedelta(days=121),
        )
        db.add(app)
        db.flush()

        # 1) Healthy active subscription (well in the future).
        s1 = Subscription(
            user_id=user.id,
            app_id=app.id,
            apim_subscription_id="sub-demo-weather01",
            product_id="weather-api",
            product_name="Weather API",
            status=SubscriptionStatus.active,
            start_date=now - timedelta(days=120),
            end_date=now + timedelta(days=245),
            auto_renew=True,
        )
        # 2) Active but expiring soon (5 days) — should surface on the dashboard.
        s2 = Subscription(
            user_id=user.id,
            app_id=app.id,
            apim_subscription_id="sub-demo-starter01",
            product_id="starter",
            product_name="Starter",
            status=SubscriptionStatus.active,
            start_date=now - timedelta(days=360),
            end_date=now + timedelta(days=5),
            auto_renew=False,
        )
        # 3) Already expired.
        s3 = Subscription(
            user_id=user.id,
            app_id=app.id,
            apim_subscription_id="sub-demo-payments01",
            product_id="payments-pro",
            product_name="Payments Pro",
            status=SubscriptionStatus.expired,
            start_date=now - timedelta(days=400),
            end_date=now - timedelta(days=12),
            auto_renew=False,
        )
        # 4) Pending approval — an approval-required product awaiting an admin decision.
        #    apim_subscription_id is set because, APIM-natively, the subscription
        #    already exists in the "submitted" state while it awaits approval.
        s4 = Subscription(
            user_id=user.id,
            app_id=app.id,
            apim_subscription_id="sub-demo-payments-pending",
            product_id="payments-pro",
            product_name="Payments Pro",
            status=SubscriptionStatus.pending,
            start_date=now - timedelta(days=1),
            end_date=now + timedelta(days=364),
            auto_renew=False,
        )
        db.add_all([s1, s2, s3, s4])
        db.flush()

        db.add_all(
            [
                SubscriptionHistory(
                    subscription_id=s1.id,
                    event_type=HistoryEvent.created,
                    detail="Subscribed to Weather API for 365 days",
                    event_at=now - timedelta(days=120),
                ),
                SubscriptionHistory(
                    subscription_id=s2.id,
                    event_type=HistoryEvent.created,
                    detail="Subscribed to Starter for 365 days",
                    event_at=now - timedelta(days=360),
                ),
                SubscriptionHistory(
                    subscription_id=s2.id,
                    event_type=HistoryEvent.reminder_sent,
                    detail="reminder:7",
                    event_at=now - timedelta(days=2),
                ),
                SubscriptionHistory(
                    subscription_id=s3.id,
                    event_type=HistoryEvent.created,
                    detail="Subscribed to Payments Pro for 365 days",
                    event_at=now - timedelta(days=400),
                ),
                SubscriptionHistory(
                    subscription_id=s3.id,
                    event_type=HistoryEvent.expired,
                    detail="Lapsed",
                    event_at=now - timedelta(days=12),
                ),
                SubscriptionHistory(
                    subscription_id=s4.id,
                    event_type=HistoryEvent.submitted,
                    detail="Approval requested for Payments Pro",
                    event_at=now - timedelta(days=1),
                ),
            ]
        )

        db.add_all(
            [
                Notification(
                    user_id=user.id,
                    subscription_id=s2.id,
                    type=NotificationType.renewal_reminder,
                    message="Your subscription to Starter expires in ~7 day(s).",
                    is_read=False,
                    sent_at=now - timedelta(days=2),
                ),
                Notification(
                    user_id=user.id,
                    subscription_id=s3.id,
                    type=NotificationType.expired,
                    message="Your subscription to Payments Pro has expired.",
                    is_read=False,
                    sent_at=now - timedelta(days=12),
                ),
                Notification(
                    user_id=user.id,
                    subscription_id=s4.id,
                    type=NotificationType.approval_pending,
                    message="Your request to subscribe to Payments Pro is pending admin approval.",
                    is_read=False,
                    sent_at=now - timedelta(days=1),
                ),
            ]
        )
        db.commit()
        print(f"Seeded demo user {user.email} with 3 subscriptions, history, and notifications.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
