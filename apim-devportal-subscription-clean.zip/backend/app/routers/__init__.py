"""API routers."""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.orm import Session

from pydantic import BaseModel

from app.apim import get_apim_client
from app.auth import get_current_user, require_admin
from app.db import get_db
from app.models import App, Notification, Subscription, SubscriptionStatus, User
from app.schemas import (
    AdminUserOut,
    AppCreate,
    AppOut,
    HistoryOut,
    NotificationOut,
    ProductOut,
    SubscriptionCreate,
    SubscriptionKeys,
    SubscriptionOut,
    UserOut,
)
from app.services import (
    approve_subscription,
    create_subscription,
    expire_subscription,
    get_subscription_keys,
    regenerate_subscription_key,
    reject_subscription,
    renew_subscription,
    revoke_subscription,
)

router = APIRouter()


def _sub_out(sub: Subscription, *, with_user: bool = False) -> SubscriptionOut:
    """Serialize a Subscription, enriching app/user fields the ORM can't map directly."""
    out = SubscriptionOut.model_validate(sub)
    update: dict = {"app_name": sub.app.name if sub.app else None}
    if with_user:
        update["user_email"] = sub.user.email
    return out.model_copy(update=update)


@router.get("/me", response_model=UserOut, tags=["auth"])
def me(user: User = Depends(get_current_user)) -> User:
    return user


@router.get("/products", response_model=list[ProductOut], tags=["products"])
def list_products(user: User = Depends(get_current_user)) -> list[dict]:
    return get_apim_client().list_products()


@router.get("/subscriptions", response_model=list[SubscriptionOut], tags=["subscriptions"])
def my_subscriptions(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list[SubscriptionOut]:
    subs = (
        db.query(Subscription)
        .filter(Subscription.user_id == user.id)
        .order_by(Subscription.created_at.desc())
        .all()
    )
    return [_sub_out(s) for s in subs]


@router.post("/subscriptions", response_model=SubscriptionOut, status_code=201, tags=["subscriptions"])
def subscribe(
    payload: SubscriptionCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> SubscriptionOut:
    # If an app is specified it must belong to the caller.
    app_name: str | None = None
    if payload.app_id is not None:
        app = db.get(App, payload.app_id)
        if app is None or app.user_id != user.id:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "App not found")
        app_name = app.name
    sub = create_subscription(
        db,
        user,
        payload.product_id,
        payload.term_days,
        payload.auto_renew,
        payload.app_id,
        app_name,
    )
    return _sub_out(sub)


# ---------------------------------------------------------------------------
# Applications — a developer's named apps that own subscriptions.
# ---------------------------------------------------------------------------


@router.get("/apps", response_model=list[AppOut], tags=["apps"])
def list_apps(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list[AppOut]:
    apps = (
        db.query(App).filter(App.user_id == user.id).order_by(App.created_at.desc()).all()
    )
    return [
        AppOut.model_validate(a).model_copy(update={"subscription_count": len(a.subscriptions)})
        for a in apps
    ]


@router.post("/apps", response_model=AppOut, status_code=201, tags=["apps"])
def create_app(
    payload: AppCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> AppOut:
    name = payload.name.strip()
    if not name:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "App name is required")
    app = App(user_id=user.id, name=name, description=payload.description.strip())
    db.add(app)
    db.commit()
    db.refresh(app)
    return AppOut.model_validate(app).model_copy(update={"subscription_count": 0})


@router.get("/apps/{app_id}/subscriptions", response_model=list[SubscriptionOut], tags=["apps"])
def app_subscriptions(
    app_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list[SubscriptionOut]:
    app = db.get(App, app_id)
    if app is None or app.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "App not found")
    return [_sub_out(s) for s in app.subscriptions]


@router.delete(
    "/apps/{app_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    tags=["apps"],
)
def delete_app(
    app_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> Response:
    app = db.get(App, app_id)
    if app is None or app.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "App not found")
    active = [s for s in app.subscriptions if s.status in (SubscriptionStatus.active, SubscriptionStatus.pending)]
    if active:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Revoke this app's active and pending subscriptions before deleting it.",
        )
    db.delete(app)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


def _owned_sub(sub_id: int, user: User, db: Session) -> Subscription:
    sub = db.get(Subscription, sub_id)
    if sub is None or sub.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Subscription not found")
    return sub


@router.post("/subscriptions/{sub_id}/renew", response_model=SubscriptionOut, tags=["subscriptions"])
def renew(
    sub_id: int,
    term_days: int = 365,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Subscription:
    return renew_subscription(db, _owned_sub(sub_id, user, db), term_days)


@router.delete(
    "/subscriptions/{sub_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    tags=["subscriptions"],
)
def revoke(
    sub_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> Response:
    revoke_subscription(db, _owned_sub(sub_id, user, db))
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/subscriptions/{sub_id}/history", response_model=list[HistoryOut], tags=["history"])
def history(
    sub_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list:
    return _owned_sub(sub_id, user, db).history


@router.get(
    "/subscriptions/{sub_id}/keys", response_model=SubscriptionKeys, tags=["subscriptions"]
)
def subscription_keys(
    sub_id: int,
    reveal: bool = False,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    """The APIM-generated primary/secondary keys. Masked unless ?reveal=true."""
    return get_subscription_keys(_owned_sub(sub_id, user, db), reveal=reveal)


@router.post(
    "/subscriptions/{sub_id}/keys/{which}/regenerate",
    response_model=SubscriptionKeys,
    tags=["subscriptions"],
)
def regenerate_key(
    sub_id: int,
    which: str,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    if which not in ("primary", "secondary"):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "which must be primary|secondary")
    return regenerate_subscription_key(db, _owned_sub(sub_id, user, db), which)


@router.get("/notifications", response_model=list[NotificationOut], tags=["notifications"])
def notifications(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list[Notification]:
    return (
        db.query(Notification)
        .filter(Notification.user_id == user.id)
        .order_by(Notification.sent_at.desc())
        .all()
    )


@router.post(
    "/notifications/{notif_id}/read",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    tags=["notifications"],
)
def mark_read(
    notif_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> Response:
    notif = db.get(Notification, notif_id)
    if notif is None or notif.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Notification not found")
    notif.is_read = True
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/notifications/read-all",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    tags=["notifications"],
)
def mark_all_read(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> Response:
    db.query(Notification).filter(
        Notification.user_id == user.id, Notification.is_read.is_(False)
    ).update({Notification.is_read: True})
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ---------------------------------------------------------------------------
# Admin console — requires an admin user (in demo mode the demo user is admin).
# ---------------------------------------------------------------------------


@router.get("/admin/stats", tags=["admin"])
def admin_stats(
    admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> dict[str, int]:
    def count(status_value: SubscriptionStatus | None = None) -> int:
        q = db.query(Subscription)
        if status_value is not None:
            q = q.filter(Subscription.status == status_value)
        return q.count()

    return {
        "users": db.query(User).count(),
        "subscriptions": count(),
        "pending": count(SubscriptionStatus.pending),
        "active": count(SubscriptionStatus.active),
        "expired": count(SubscriptionStatus.expired),
        "revoked": count(SubscriptionStatus.revoked),
    }


@router.get("/admin/users", response_model=list[AdminUserOut], tags=["admin"])
def admin_users(
    admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> list[User]:
    return db.query(User).order_by(User.created_at.asc()).all()


@router.get("/admin/subscriptions", response_model=list[SubscriptionOut], tags=["admin"])
def admin_subscriptions(
    admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> list[SubscriptionOut]:
    subs = db.query(Subscription).order_by(Subscription.created_at.desc()).all()
    return [_sub_out(s, with_user=True) for s in subs]


@router.get("/admin/pending", response_model=list[SubscriptionOut], tags=["admin"])
def admin_pending(
    admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> list[SubscriptionOut]:
    """The approval queue: subscriptions awaiting an admin decision."""
    subs = (
        db.query(Subscription)
        .filter(Subscription.status == SubscriptionStatus.pending)
        .order_by(Subscription.created_at.asc())
        .all()
    )
    return [_sub_out(s, with_user=True) for s in subs]


def _any_sub(sub_id: int, db: Session) -> Subscription:
    sub = db.get(Subscription, sub_id)
    if sub is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Subscription not found")
    return sub


class RejectBody(BaseModel):
    reason: str = ""


@router.post(
    "/admin/subscriptions/{sub_id}/approve", response_model=SubscriptionOut, tags=["admin"]
)
def admin_approve(
    sub_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> SubscriptionOut:
    sub = _any_sub(sub_id, db)
    if sub.status != SubscriptionStatus.pending:
        raise HTTPException(status.HTTP_409_CONFLICT, "Subscription is not pending approval")
    return _sub_out(approve_subscription(db, sub), with_user=True)


@router.post(
    "/admin/subscriptions/{sub_id}/reject", response_model=SubscriptionOut, tags=["admin"]
)
def admin_reject(
    sub_id: int,
    body: RejectBody | None = None,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
) -> SubscriptionOut:
    sub = _any_sub(sub_id, db)
    if sub.status != SubscriptionStatus.pending:
        raise HTTPException(status.HTTP_409_CONFLICT, "Subscription is not pending approval")
    return _sub_out(reject_subscription(db, sub, (body.reason if body else "")), with_user=True)


@router.post(
    "/admin/subscriptions/{sub_id}/expire", response_model=SubscriptionOut, tags=["admin"]
)
def admin_expire(
    sub_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> Subscription:
    return expire_subscription(db, _any_sub(sub_id, db), by_admin=True)


@router.delete(
    "/admin/subscriptions/{sub_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    tags=["admin"],
)
def admin_revoke(
    sub_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)
) -> Response:
    revoke_subscription(db, _any_sub(sub_id, db))
    return Response(status_code=status.HTTP_204_NO_CONTENT)
