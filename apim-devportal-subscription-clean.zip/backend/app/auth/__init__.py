"""Microsoft Entra ID JWT validation and the current-user dependency.

When ``settings.demo_mode`` is enabled, token validation is skipped entirely and
a single fixed demo user is returned. This lets the whole stack run with no Azure
or Entra configuration. Do NOT enable demo mode in production.
"""
from __future__ import annotations

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jwt import PyJWKClient
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.models import User

settings = get_settings()
# In demo mode the Authorization header is optional.
_bearer = HTTPBearer(auto_error=not settings.demo_mode)
_jwks_client = (
    PyJWKClient(settings.jwks_url)
    if (settings.entra_tenant_id and not settings.demo_mode)
    else None
)


def get_or_create_user(
    db: Session, oid: str, email: str, name: str, is_admin: bool = False
) -> User:
    user = db.query(User).filter(User.entra_oid == oid).one_or_none()
    if user is None:
        user = User(entra_oid=oid, email=email, display_name=name, is_admin=is_admin)
        db.add(user)
        db.commit()
        db.refresh(user)
    elif is_admin and not user.is_admin:
        # Promote (e.g. the demo user) on subsequent logins without re-seeding.
        user.is_admin = True
        db.commit()
        db.refresh(user)
    return user


def _decode_token(token: str) -> dict:
    if _jwks_client is None:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, "Entra tenant not configured")
    try:
        signing_key = _jwks_client.get_signing_key_from_jwt(token).key
        return jwt.decode(
            token,
            signing_key,
            algorithms=["RS256"],
            audience=settings.entra_api_client_id,
            issuer=settings.issuer,
        )
    except jwt.PyJWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, f"Invalid token: {exc}") from exc


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User:
    """Return the current user, validating the Entra token unless in demo mode."""
    if settings.demo_mode:
        # In demo mode the single demo user is treated as an admin so the
        # admin console is reachable without any Entra role configuration.
        return get_or_create_user(
            db,
            settings.demo_user_oid,
            settings.demo_user_email,
            settings.demo_user_name,
            is_admin=True,
        )

    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing bearer token")

    claims = _decode_token(creds.credentials)
    oid = claims.get("oid") or claims.get("sub")
    if not oid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token missing subject")

    email = claims.get("preferred_username") or claims.get("email") or ""
    name = claims.get("name", "")
    # Admin is granted via the Entra "roles" claim (app role "Admin").
    is_admin = "Admin" in (claims.get("roles") or [])
    return get_or_create_user(db, oid, email, name, is_admin=is_admin)


def require_admin(user: User = Depends(get_current_user)) -> User:
    """Dependency that allows only admin users through."""
    if not user.is_admin:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Admin access required")
    return user
