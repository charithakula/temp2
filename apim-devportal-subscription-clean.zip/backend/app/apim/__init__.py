"""Thin client over the Azure APIM management REST API.

Uses azure-identity (DefaultAzureCredential covers service principal env vars,
managed identity, and az-cli login) to obtain ARM tokens.

This client models APIM faithfully: subscriptions carry a *state*
(``submitted`` | ``active`` | ``suspended`` | ``cancelled``) and own the
primary/secondary access keys. Approval-required products create the
subscription in the ``submitted`` state; an admin transitions it to ``active``.
"""
from __future__ import annotations

import hashlib

import httpx

from app.config import get_settings

settings = get_settings()
_ARM = "https://management.azure.com"
_API_VERSION = "2023-05-01-preview"


class ApimClient:
    def __init__(self) -> None:
        # Imported lazily so demo mode never requires azure-identity / credentials.
        from azure.identity import DefaultAzureCredential

        self._cred = DefaultAzureCredential()
        self._base = (
            f"{_ARM}/subscriptions/{settings.azure_subscription_id}"
            f"/resourceGroups/{settings.apim_resource_group}"
            f"/providers/Microsoft.ApiManagement/service/{settings.apim_service_name}"
        )

    def _headers(self) -> dict[str, str]:
        token = self._cred.get_token(f"{_ARM}/.default").token
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def list_products(self) -> list[dict]:
        url = f"{self._base}/products?api-version={_API_VERSION}"
        with httpx.Client(timeout=30) as c:
            r = c.get(url, headers=self._headers())
            r.raise_for_status()
            items = r.json().get("value", [])
        return [
            {
                "id": p["name"],
                "name": p["properties"].get("displayName", p["name"]),
                "description": p["properties"].get("description", ""),
                "approval_required": p["properties"].get("approvalRequired", False),
            }
            for p in items
            if p["properties"].get("state") == "published"
        ]

    def create_subscription(
        self,
        sub_id: str,
        user_email: str,
        product_id: str,
        *,
        state: str = "active",
        display_name: str | None = None,
    ) -> dict:
        """Create a subscription in the given APIM state.

        ``state`` is "submitted" for approval-required products (APIM holds it
        pending) or "active" for open products.
        """
        url = f"{self._base}/subscriptions/{sub_id}?api-version={_API_VERSION}"
        body = {
            "properties": {
                "displayName": display_name or f"{product_id} - {user_email}",
                "scope": f"{self._base}/products/{product_id}",
                "state": state,
            }
        }
        with httpx.Client(timeout=30) as c:
            r = c.put(url, headers=self._headers(), json=body)
            r.raise_for_status()
            return r.json()

    def set_subscription_state(self, sub_id: str, state: str) -> None:
        """state: 'submitted' | 'active' | 'suspended' | 'cancelled' | 'rejected'."""
        url = f"{self._base}/subscriptions/{sub_id}?api-version={_API_VERSION}"
        with httpx.Client(timeout=30) as c:
            r = c.patch(url, headers=self._headers(), json={"properties": {"state": state}})
            r.raise_for_status()

    def list_secrets(self, sub_id: str) -> dict:
        """Return {'primaryKey': ..., 'secondaryKey': ...} for a subscription."""
        url = f"{self._base}/subscriptions/{sub_id}/listSecrets?api-version={_API_VERSION}"
        with httpx.Client(timeout=30) as c:
            r = c.post(url, headers=self._headers())
            r.raise_for_status()
            data = r.json()
        return {
            "primary_key": data.get("primaryKey", ""),
            "secondary_key": data.get("secondaryKey", ""),
        }

    def regenerate_key(self, sub_id: str, which: str) -> None:
        """which: 'primary' | 'secondary'."""
        action = "regeneratePrimaryKey" if which == "primary" else "regenerateSecondaryKey"
        url = f"{self._base}/subscriptions/{sub_id}/{action}?api-version={_API_VERSION}"
        with httpx.Client(timeout=30) as c:
            r = c.post(url, headers=self._headers())
            r.raise_for_status()

    def delete_subscription(self, sub_id: str) -> None:
        url = f"{self._base}/subscriptions/{sub_id}?api-version={_API_VERSION}"
        with httpx.Client(timeout=30) as c:
            r = c.delete(url, headers={**self._headers(), "If-Match": "*"})
            if r.status_code not in (200, 204):
                r.raise_for_status()


class DemoApimClient:
    """Stateful in-memory APIM simulation for demo mode.

    Faithfully mimics APIM semantics — subscriptions hold a *state* and a pair
    of generated keys — so the portal behaves the same as it will against a real
    APIM instance, without any Azure configuration.
    """

    _PRODUCTS = [
        {
            "id": "starter",
            "name": "Starter",
            "description": "Entry tier with generous rate limits for prototyping and demos.",
            "approval_required": False,
        },
        {
            "id": "weather-api",
            "name": "Weather API",
            "description": "Real-time and forecast weather data across global locations.",
            "approval_required": False,
        },
        {
            "id": "payments-pro",
            "name": "Payments Pro",
            "description": "Production-grade payments product. Subscriptions need admin approval.",
            "approval_required": True,
        },
    ]

    # Class-level store so state survives across requests within the process.
    _subs: dict[str, dict] = {}

    @staticmethod
    def _fake_key(sub_id: str, salt: str) -> str:
        return hashlib.sha256(f"{sub_id}:{salt}".encode()).hexdigest()

    def list_products(self) -> list[dict]:
        return list(self._PRODUCTS)

    def create_subscription(
        self,
        sub_id: str,
        user_email: str,
        product_id: str,
        *,
        state: str = "active",
        display_name: str | None = None,
    ) -> dict:
        self._subs[sub_id] = {
            "state": state,
            "displayName": display_name or f"{product_id} - {user_email}",
            "primaryKey": self._fake_key(sub_id, "primary"),
            "secondaryKey": self._fake_key(sub_id, "secondary"),
        }
        return {"name": sub_id, "properties": {"state": state}}

    def set_subscription_state(self, sub_id: str, state: str) -> None:
        if sub_id in self._subs:
            self._subs[sub_id]["state"] = state

    def list_secrets(self, sub_id: str) -> dict:
        s = self._subs.get(sub_id)
        if not s:
            # Subscription created before this process started (e.g. seeded data):
            # synthesize deterministic keys so the UI still has something to show.
            return {
                "primary_key": self._fake_key(sub_id, "primary"),
                "secondary_key": self._fake_key(sub_id, "secondary"),
            }
        return {"primary_key": s["primaryKey"], "secondary_key": s["secondaryKey"]}

    def regenerate_key(self, sub_id: str, which: str) -> None:
        s = self._subs.setdefault(
            sub_id,
            {
                "state": "active",
                "primaryKey": self._fake_key(sub_id, "primary"),
                "secondaryKey": self._fake_key(sub_id, "secondary"),
            },
        )
        # New value: salt with a counter so each regenerate differs.
        s["_rev"] = s.get("_rev", 0) + 1
        key = "primaryKey" if which == "primary" else "secondaryKey"
        s[key] = self._fake_key(sub_id, f"{which}-{s['_rev']}")

    def delete_subscription(self, sub_id: str) -> None:
        self._subs.pop(sub_id, None)


def get_apim_client():
    if settings.demo_mode:
        return DemoApimClient()
    return ApimClient()
