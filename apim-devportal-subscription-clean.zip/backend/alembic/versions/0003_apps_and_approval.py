"""apps + approval workflow

Adds the apps table, links subscriptions to apps, and extends the history/
notification enums with the approval lifecycle values.

Revision ID: 0003_apps_and_approval
Revises: 0002_user_is_admin
Create Date: 2026-06-27
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0003_apps_and_approval"
down_revision: Union[str, None] = "0002_user_is_admin"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# New enum values introduced by the approval workflow.
_HISTORY_NEW = ("submitted", "approved", "rejected")
_NOTIF_NEW = ("approval_pending", "approved", "rejected")


def upgrade() -> None:
    # 1) apps table
    op.create_table(
        "apps",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("description", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_apps_user_id", "apps", ["user_id"])

    # 2) subscriptions.app_id (nullable so existing rows are unaffected)
    op.add_column(
        "subscriptions",
        sa.Column("app_id", sa.Integer(), sa.ForeignKey("apps.id"), nullable=True),
    )
    op.create_index("ix_subscriptions_app_id", "subscriptions", ["app_id"])

    # 3) extend enums (Postgres: ADD VALUE must run outside a transaction block)
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        with op.get_context().autocommit_block():
            for value in _HISTORY_NEW:
                op.execute(
                    f"ALTER TYPE historyevent ADD VALUE IF NOT EXISTS '{value}'"
                )
            for value in _NOTIF_NEW:
                op.execute(
                    f"ALTER TYPE notificationtype ADD VALUE IF NOT EXISTS '{value}'"
                )


def downgrade() -> None:
    # Note: Postgres cannot drop individual enum values; we leave the enum
    # extensions in place and only reverse the structural changes.
    op.drop_index("ix_subscriptions_app_id", table_name="subscriptions")
    op.drop_column("subscriptions", "app_id")
    op.drop_index("ix_apps_user_id", table_name="apps")
    op.drop_table("apps")
