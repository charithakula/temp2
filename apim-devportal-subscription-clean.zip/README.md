# APIM Developer Portal

A custom developer portal for **Azure API Management** where developers sign in with
**Microsoft Entra ID**, browse and subscribe to API products, and track **subscription
history**, **expiry dates**, and **renewal notifications** (in-app + email).

> Full design rationale is in [SOLUTION.md](SOLUTION.md).

## Stack

| Layer | Tech |
|-------|------|
| Frontend | Next.js 14 (App Router) + Tailwind CSS + MSAL (Entra ID) |
| Backend | FastAPI + SQLAlchemy + Alembic + APScheduler |
| Database | PostgreSQL |
| Auth | Microsoft Entra ID (OIDC / JWT) |
| APIM | Azure APIM management REST API |
| Notifications | In-app + Email (Azure Communication Services) + daily scheduler |
| Infra | Bicep (APIM product + subscription) |

## Project layout

```
apim-devportal-subscription/
├─ infra/             # Bicep: APIM product (published to dev portal) + subscription
├─ backend/           # FastAPI app
│  ├─ app/{auth,apim,db,models,schemas,routers,services,scheduler}
│  ├─ app/seed.py     # demo user + sample data seeder
│  └─ alembic/        # migrations (0001_initial)
├─ frontend/          # Next.js + Tailwind
│  ├─ app/            # dashboard, products, subscriptions, history, notifications
│  ├─ components/     # Shell, StatusBadge, NotificationBell, StatCard
│  └─ lib/            # msal config, api client, utils
├─ docker-compose.yml # postgres + backend + frontend
├─ SOLUTION.md
└─ README.md
```

## Quick start — demo mode (zero Azure setup)

The fastest way to see the app. **Demo mode is on by default**, so no Entra ID or
APIM configuration is needed — a seeded demo user is used and APIM is mocked.

```bash
docker compose up --build
```

or on Windows:

```powershell
./scripts/start-demo.ps1
```

Then open:
- Frontend → http://localhost:3000  (no sign-in — you're the demo user)
- Backend  → http://localhost:8000  (docs at `/docs`)

On startup the backend automatically runs migrations **and** seeds a demo user:

| | |
|---|---|
| **Demo user** | `demo.developer@example.com` ("Demo Developer") |
| **Seeded data** | 3 subscriptions (1 healthy, 1 expiring in 5 days, 1 expired), history timeline, 2 notifications |

> ⚠️ Demo mode bypasses authentication. Turn it **off** for any real deployment
> (`DEMO_MODE=false` backend, `NEXT_PUBLIC_DEMO_MODE=false` frontend) and configure
> Entra ID + APIM as below.

## Production mode (real Entra ID + APIM)

1. Set `DEMO_MODE=false` / `NEXT_PUBLIC_DEMO_MODE=false`.
2. Configure env files (see [Entra ID setup](#entra-id-setup-summary)):
   ```bash
   cp backend/.env.example backend/.env
   cp frontend/.env.local.example frontend/.env.local
   ```
   Fill in Entra tenant/client IDs, Azure subscription, and APIM details.
3. `docker compose up --build` (remove the inline `DEMO_MODE` env in
   `docker-compose.yml` or override it, and re-add the `env_file` entries).

## Local dev (without Docker)

**Backend**
```bash
cd backend
python -m venv .venv && source .venv/Scripts/activate   # Windows Git Bash
pip install -r requirements.txt
cp .env.example .env                                     # DEMO_MODE=true by default
alembic upgrade head                                     # applies committed 0001_initial
python -m app.seed                                       # create demo user + sample data
uvicorn app.main:app --reload
```

**Frontend**
```bash
cd frontend
npm install
cp .env.local.example .env.local                         # NEXT_PUBLIC_DEMO_MODE=true by default
npm run dev
```

## Entra ID setup (summary)

You need **two app registrations** (or one app with two platforms):

1. **Backend API app** — *Expose an API* → add scope `access_as_user`. Its
   Application (client) ID is `ENTRA_API_CLIENT_ID` (the token audience).
2. **Frontend SPA app** — platform *Single-page application*, redirect URI
   `http://localhost:3000`. Grant it delegated permission to the backend's
   `access_as_user` scope. Its client ID is `NEXT_PUBLIC_ENTRA_CLIENT_ID`.

Set `NEXT_PUBLIC_API_SCOPE=api://<backend-app-id>/access_as_user`.

The backend authenticates to the **APIM management API** via
`DefaultAzureCredential` — locally that means a service principal
(`AZURE_CLIENT_ID/SECRET/TENANT_ID`) or `az login`; in Azure, a managed identity
with the *API Management Service Contributor* role.

## Features

- 🔐 Entra ID sign-in (MSAL redirect flow)
- 📊 Dashboard with active/expiring/expired stats and renewals-to-watch
- 🧩 Browse published APIM products and subscribe in one click
- 🔑 Subscription management: renew, revoke, view APIM subscription id
- 🕓 Per-subscription history timeline (created / reminder / renewed / expired / revoked)
- 🔔 In-app notifications (bell with unread count) + email reminders
- ⏰ Daily scheduler scans for subscriptions expiring in 30/7/1 days and auto-expires lapsed ones

## How the lifecycle works

APIM stores *what subscriptions exist*; this app's PostgreSQL DB owns the *lifecycle*
(start/end dates, renewals, history, notification state) because APIM has no native
expiry/renewal concept. The scheduler reconciles the two daily.

See [SOLUTION.md](SOLUTION.md) for the full architecture and the Bicep infra in
[infra/](infra/) for creating the underlying APIM product + subscription.
```
