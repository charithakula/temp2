from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireAuthor, RequireViewer
from app.core.config import settings
from app.core.db import get_session
from app.models.entities import Document, Project
from app.services.audit import record as audit
from app.services.embeddings import index_document
from app.services.ingestion import extract_text
from app.services.pii import scan as pii_scan
from app.services.storage import delete as storage_delete, store as storage_store

router = APIRouter(prefix="/projects/{project_id}/documents", tags=["documents"])

MAX_BYTES = 25 * 1024 * 1024  # 25 MB


@router.post("", status_code=201)
async def upload_document(
    project_id: str,
    file: UploadFile = File(...),
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> dict:
    if (await session.get(Project, project_id)) is None:
        raise HTTPException(status_code=404, detail="Project not found")

    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds 25 MB limit")

    text_extracted = extract_text(file.filename or "", file.content_type, data)
    pii = pii_scan(text_extracted)

    doc = Document(
        project_id=project_id,
        filename=file.filename or "untitled",
        content_type=file.content_type,
        size_bytes=len(data),
        text_extracted=text_extracted,
    )
    session.add(doc)
    await session.commit()
    await session.refresh(doc)

    # Persist the original bytes (Blob if configured, else local-uploads/).
    try:
        doc.blob_url = storage_store(
            project_id=project_id,
            document_id=doc.id,
            filename=doc.filename,
            data=data,
        )
        await session.commit()
        await session.refresh(doc)
    except Exception:
        # Don't fail the upload if storage is misconfigured — keep extracted text.
        pass

    chunks_indexed = 0
    if settings.azure_openai_api_key and text_extracted.strip():
        try:
            chunks_indexed = await index_document(
                session=session,
                project_id=project_id,
                document_id=doc.id,
                full_text=text_extracted,
            )
        except Exception:
            chunks_indexed = 0

    await audit(
        session,
        user=user,
        action="document.upload",
        project_id=project_id,
        entity_type="document",
        entity_id=doc.id,
        metadata={
            "filename": doc.filename,
            "size_bytes": doc.size_bytes,
            "chunks_indexed": chunks_indexed,
            "pii_total": pii.total,
        },
    )
    return {
        "id": doc.id,
        "project_id": project_id,
        "filename": doc.filename,
        "content_type": doc.content_type,
        "size_bytes": doc.size_bytes,
        "extracted_chars": len(doc.text_extracted),
        "chunks_indexed": chunks_indexed,
        "pii": {"total": pii.total, "by_kind": pii.counts},
    }


@router.delete("/{doc_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    project_id: str,
    doc_id: str,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> None:
    doc = await session.get(Document, doc_id)
    if doc is None or doc.project_id != project_id:
        raise HTTPException(status_code=404, detail="Document not found")
    filename = doc.filename
    blob_url = doc.blob_url
    await session.delete(doc)
    await session.commit()
    storage_delete(blob_url)
    await audit(
        session,
        user=user,
        action="document.delete",
        project_id=project_id,
        entity_type="document",
        entity_id=doc_id,
        metadata={"filename": filename},
    )


@router.get("")
async def list_documents(
    project_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> list[dict]:
    rows = (
        await session.execute(
            select(Document).where(Document.project_id == project_id)
        )
    ).scalars().all()
    return [
        {
            "id": d.id,
            "filename": d.filename,
            "content_type": d.content_type,
            "size_bytes": d.size_bytes,
            "extracted_chars": len(d.text_extracted or ""),
            "blob_url": d.blob_url,
            "created_at": d.created_at,
        }
        for d in rows
    ]
