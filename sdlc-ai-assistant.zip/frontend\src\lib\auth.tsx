"use client";

import { useRouter } from "next/navigation";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import {
  clearSession,
  getSession,
  setSession,
  type Role,
} from "./api";

interface AuthState {
  ready: boolean;
  signedIn: boolean;
  email: string | null;
  role: Role | null;
  signIn: (email: string, role: Role) => void;
  signOut: () => void;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [email, setEmail] = useState<string | null>(null);
  const [role, setRole] = useState<Role | null>(null);

  useEffect(() => {
    const s = getSession();
    if (s) {
      setEmail(s.email);
      setRole(s.role);
    }
    setReady(true);
  }, []);

  const signIn = useCallback(
    (newEmail: string, newRole: Role) => {
      setSession({ email: newEmail, role: newRole });
      setEmail(newEmail);
      setRole(newRole);
      router.push("/projects");
    },
    [router],
  );

  const signOut = useCallback(() => {
    clearSession();
    setEmail(null);
    setRole(null);
    router.push("/login");
  }, [router]);

  return (
    <Ctx.Provider
      value={{
        ready,
        signedIn: !!email && !!role,
        email,
        role,
        signIn,
        signOut,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside <AuthProvider>");
  return v;
}

export const ROLE_RANK: Record<Role, number> = {
  Viewer: 1,
  Author: 2,
  Admin: 3,
};

export function hasRole(current: Role | null, required: Role): boolean {
  if (!current) return false;
  return ROLE_RANK[current] >= ROLE_RANK[required];
}
