const BASE =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000/api/v1";

export type Role = "Viewer" | "Author" | "Admin";

export interface Project {
  id: string;
  name: string;
  description?: string | null;
  created_by: string;
  created_at: string;
  status: string;
}

export interface DocumentSummary {
  id: string;
  filename: string;
  content_type: string | null;
  size_bytes: number;
  extracted_chars: number;
  created_at: string;
}

export interface Me {
  oid: string;
  email: string;
  roles: Role[];
}

export interface SCSVersion {
  id: string;
  project_id: string;
  version_no: number;
  status: "draft" | "approved";
  markdown: string;
  model: string;
  tokens_in: number;
  tokens_out: number;
  created_by: string;
  created_at: string;
}

export interface OpenAPIVersion {
  id: string;
  project_id: string;
  scs_version_id: string;
  version_no: number;
  yaml: string;
  validation_errors: string;
  model: string;
  tokens_in: number;
  tokens_out: number;
  created_by: string;
  created_at: string;
}

export interface AuditEntry {
  id: string;
  project_id: string | null;
  actor_oid: string;
  actor_email: string;
  actor_role: string;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  metadata_json: string;
  created_at: string;
}

interface Session {
  email: string;
  role: Role;
}

const SESSION_KEY = "sdlc.session";

export function getSession(): Session | null {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Session;
  } catch {
    return null;
  }
}

export function setSession(s: Session) {
  window.localStorage.setItem(SESSION_KEY, JSON.stringify(s));
}

export function clearSession() {
  window.localStorage.removeItem(SESSION_KEY);
}

async function authHeaders(): Promise<Record<string, string>> {
  const s = getSession();
  // Lazy import so msal-browser only loads when actually configured.
  let bearer = "Bearer dev";
  try {
    const { msalConfigured, getAccessToken } = await import("./msal");
    if (msalConfigured) {
      const token = await getAccessToken();
      if (token) bearer = `Bearer ${token}`;
    }
  } catch {
    /* msal not available — fall back to dev */
  }
  return {
    Authorization: bearer,
    ...(s ? { "X-Dev-Role": s.role, "X-Dev-Email": s.email } : {}),
  };
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = await authHeaders();
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...headers,
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new ApiError(res.status, text || res.statusText);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export const api = {
  me: () => request<Me>("/me"),

  listProjects: () => request<Project[]>("/projects"),

  createProject: (body: { name: string; description?: string }) =>
    request<Project>("/projects", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  patchProject: (
    id: string,
    body: { name?: string; description?: string; status?: "active" | "archived" },
  ) =>
    request<Project>(`/projects/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  deleteProject: (id: string) =>
    request<void>(`/projects/${id}`, { method: "DELETE" }),

  deleteDocument: (projectId: string, docId: string) =>
    request<void>(`/projects/${projectId}/documents/${docId}`, {
      method: "DELETE",
    }),

  exportSCSUrl: (projectId: string, versionId: string, format: "md" | "docx") =>
    `${BASE}/projects/${projectId}/scs/${versionId}/export?format=${format}`,

  exportOpenAPIUrl: (projectId: string, versionId: string, format: "yaml" | "json") =>
    `${BASE}/projects/${projectId}/openapi/${versionId}/export?format=${format}`,

  /** Authenticated download — fetches the file then triggers a Save-As. */
  async downloadExport(url: string, suggestedName: string): Promise<void> {
    const headers = await authHeaders();
    const res = await fetch(url, { headers });
    if (!res.ok) throw new ApiError(res.status, await res.text());
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = suggestedName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  },

  listDocuments: (projectId: string) =>
    request<DocumentSummary[]>(`/projects/${projectId}/documents`),

  async uploadDocument(
    projectId: string,
    file: File,
  ): Promise<{
    id: string;
    filename: string;
    size_bytes: number;
    extracted_chars: number;
    chunks_indexed: number;
    pii?: { total: number; by_kind: Record<string, number> };
  }> {
    const form = new FormData();
    form.append("file", file);
    const headers = await authHeaders();
    const res = await fetch(`${BASE}/projects/${projectId}/documents`, {
      method: "POST",
      body: form,
      headers,
    });
    if (!res.ok) throw new ApiError(res.status, await res.text());
    return res.json();
  },

  // ---- SCS ----
  listSCS: (projectId: string) =>
    request<SCSVersion[]>(`/projects/${projectId}/scs`),
  getSCS: (projectId: string, versionId: string) =>
    request<SCSVersion>(`/projects/${projectId}/scs/${versionId}`),
  updateSCS: (projectId: string, versionId: string, markdown: string) =>
    request<SCSVersion>(`/projects/${projectId}/scs/${versionId}`, {
      method: "PUT",
      body: JSON.stringify({ markdown }),
    }),
  approveSCS: (projectId: string, versionId: string) =>
    request<SCSVersion>(`/projects/${projectId}/scs/${versionId}/approve`, {
      method: "POST",
    }),

  /** Stream SCS generation tokens via SSE; resolves with the new version_id. */
  streamSCS(
    projectId: string,
    body: { steering?: string; deployment?: string },
    onDelta: (delta: string) => void,
    signal?: AbortSignal,
  ): Promise<{ version_id: string; version_no: number } | null> {
    return streamSSE(
      `${BASE}/projects/${projectId}/scs/generate`,
      JSON.stringify(body),
      onDelta,
      signal,
    );
  },

  // ---- OpenAPI ----
  listOpenAPI: (projectId: string) =>
    request<OpenAPIVersion[]>(`/projects/${projectId}/openapi`),
  getOpenAPI: (projectId: string, versionId: string) =>
    request<OpenAPIVersion>(`/projects/${projectId}/openapi/${versionId}`),

  streamOpenAPI(
    projectId: string,
    body: { scs_version_id: string; deployment?: string },
    onDelta: (delta: string) => void,
    signal?: AbortSignal,
  ): Promise<{
    version_id: string;
    version_no: number;
    validation_errors: string[];
  } | null> {
    return streamSSE(
      `${BASE}/projects/${projectId}/openapi/generate`,
      JSON.stringify(body),
      onDelta,
      signal,
    );
  },

  // ---- Chat ----
  streamChat(
    projectId: string,
    body: {
      message: string;
      history: { role: "user" | "assistant"; content: string }[];
    },
    onDelta: (delta: string) => void,
    signal?: AbortSignal,
  ): Promise<{ message_id: string } | null> {
    return streamSSE(
      `${BASE}/projects/${projectId}/chat`,
      JSON.stringify(body),
      onDelta,
      signal,
    );
  },

  // ---- Audit ----
  listAudit: (limit = 200) =>
    request<AuditEntry[]>(`/audit?limit=${limit}`),
  listProjectAudit: (projectId: string, limit = 200) =>
    request<AuditEntry[]>(`/projects/${projectId}/audit?limit=${limit}`),
};

async function streamSSE(
  url: string,
  body: string,
  onDelta: (delta: string) => void,
  signal?: AbortSignal,
): Promise<any> {
  const headers = await authHeaders();
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...headers },
    body,
    signal,
  });
  if (!res.ok || !res.body) throw new ApiError(res.status, await res.text());

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let result: any = null;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let idx: number;
      while ((idx = buffer.indexOf("\n\n")) >= 0) {
        const frame = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        const eventLine = frame
          .split("\n")
          .find((l) => l.startsWith("event: "));
        const dataLine = frame
          .split("\n")
          .find((l) => l.startsWith("data: "));
        if (!eventLine || !dataLine) continue;
        const event = eventLine.slice(7).trim();
        const data = JSON.parse(dataLine.slice(6));
        if (event === "token") onDelta(data.delta);
        else if (event === "done") result = data;
        else if (event === "error")
          throw new ApiError(500, data.message ?? "stream error");
      }
    }
  } catch (e) {
    if ((e as Error).name === "AbortError") return null;
    throw e;
  }
  return result;
}
