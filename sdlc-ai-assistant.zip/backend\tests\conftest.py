"""Pytest fixtures — isolated SQLite DB per test session, fresh schema."""
import asyncio
import os
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="session", autouse=True)
def _isolate_db_and_storage():
    tmp = Path(tempfile.mkdtemp(prefix="sdlc-test-"))
    os.environ["DATABASE_URL"] = f"sqlite+aiosqlite:///{(tmp / 'test.db').as_posix()}"
    os.environ["AZURE_OPENAI_API_KEY"] = ""  # disable embeddings in tests
    os.environ["DEV_ROLE"] = "Author"
    yield tmp


@pytest.fixture
def client():
    # Import lazily so env vars above take effect first.
    from app.main import app

    # Run lifespan manually so init_db() builds the schema.
    asyncio.run(_startup(app))
    return TestClient(app)


async def _startup(app):
    # Stop after startup; we just need init_db() to have run.
    cm = app.router.lifespan_context(app)
    await cm.__aenter__()


def auth(role: str = "Author", email: str = "test@example.com") -> dict:
    return {
        "Authorization": "Bearer dev",
        "X-Dev-Role": role,
        "X-Dev-Email": email,
    }
