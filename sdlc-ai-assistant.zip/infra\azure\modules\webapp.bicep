param name string
param location string
param tags object
param planId string
@description('Linux runtime stack, e.g. PYTHON|3.11 or NODE|20-lts.')
param runtime string
param appInsightsConnectionString string
param keyVaultName string
@description('Additional app settings to merge in.')
param appSettings array = []
param startupCommand string = ''

resource site 'Microsoft.Web/sites@2023-12-01' = {
  name: name
  location: location
  tags: tags
  kind: 'app,linux'
  identity: { type: 'SystemAssigned' }
  properties: {
    serverFarmId: planId
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: runtime
      appCommandLine: startupCommand
      minTlsVersion: '1.2'
      ftpsState: 'Disabled'
      appSettings: concat(
        [
          { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING', value: appInsightsConnectionString }
          { name: 'WEBSITE_RUN_FROM_PACKAGE', value: '1' }
        ],
        appSettings
      )
    }
  }
}

// Grant the Web App's managed identity Key Vault Secrets User on the vault
// (so @Microsoft.KeyVault(...) app setting references work).
resource kv 'Microsoft.KeyVault/vaults@2024-04-01-preview' existing = {
  name: keyVaultName
}

resource roleAssign 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: kv
  name: guid(kv.id, site.id, 'kv-secrets-user')
  properties: {
    // Key Vault Secrets User
    roleDefinitionId: subscriptionResourceId(
      'Microsoft.Authorization/roleDefinitions',
      '4633458b-17de-408a-b874-0445c86b69e6'
    )
    principalId: site.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

output defaultHostname string = site.properties.defaultHostName
output principalId string = site.identity.principalId
output id string = site.id
