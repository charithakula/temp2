"""RBAC matrix — every write action enforced on the right role."""
from tests.conftest import auth


def test_unauthenticated_blocked(client):
    assert client.get("/api/v1/projects").status_code == 401


def test_viewer_cannot_create(client):
    r = client.post(
        "/api/v1/projects",
        json={"name": "X"},
        headers=auth("Viewer"),
    )
    assert r.status_code == 403


def test_author_can_create_and_list(client):
    r = client.post(
        "/api/v1/projects",
        json={"name": "Test-A"},
        headers=auth("Author"),
    )
    assert r.status_code == 201, r.text
    pid = r.json()["id"]

    r = client.get("/api/v1/projects", headers=auth("Viewer"))
    assert r.status_code == 200
    assert any(p["id"] == pid for p in r.json())


def test_author_cannot_delete(client):
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Test-Del"},
        headers=auth("Author"),
    ).json()["id"]
    r = client.delete(f"/api/v1/projects/{pid}", headers=auth("Author"))
    assert r.status_code == 403


def test_admin_can_delete(client):
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Test-Del2"},
        headers=auth("Author"),
    ).json()["id"]
    r = client.delete(f"/api/v1/projects/{pid}", headers=auth("Admin"))
    assert r.status_code == 204


def test_admin_only_approve(client):
    # We can't generate without LLM, but we can directly approve a manually-saved
    # version once we have one. For this RBAC test, just confirm 404 path is
    # still protected (Author allowed, Viewer blocked) on a non-existent version.
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Approve-Test"},
        headers=auth("Author"),
    ).json()["id"]
    fake = "00000000-0000-0000-0000-000000000000"
    assert (
        client.post(
            f"/api/v1/projects/{pid}/scs/{fake}/approve",
            headers=auth("Viewer"),
        ).status_code
        == 403
    )
    assert (
        client.post(
            f"/api/v1/projects/{pid}/scs/{fake}/approve",
            headers=auth("Author"),
        ).status_code
        == 403  # Author still blocked — approve is Admin-only
    )
    # Admin gets 404 (version doesn't exist) — meaning RBAC let them through.
    assert (
        client.post(
            f"/api/v1/projects/{pid}/scs/{fake}/approve",
            headers=auth("Admin"),
        ).status_code
        == 404
    )
