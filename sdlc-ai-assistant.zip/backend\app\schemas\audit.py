from datetime import datetime

from pydantic import BaseModel, ConfigDict


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    project_id: str | None = None
    actor_oid: str
    actor_email: str
    actor_role: str
    action: str
    entity_type: str | None = None
    entity_id: str | None = None
    metadata_json: str
    created_at: datetime
