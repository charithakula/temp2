"""Single integration point for the Azure OpenAI Service.

All prompts go through here so we can swap providers without touching routes
or prompts. Streaming uses the Azure OpenAI Chat Completions API with
`stream_options={"include_usage": True}` so the final chunk carries token
usage; callers consume `(text_iter, usage_holder)` and read `usage_holder`
once iteration completes.
"""
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from openai import AsyncAzureOpenAI

from app.core.config import settings

_client: AsyncAzureOpenAI | None = None


def _get_client() -> AsyncAzureOpenAI:
    global _client
    if _client is None:
        _client = AsyncAzureOpenAI(
            api_key=settings.azure_openai_api_key,
            api_version=settings.azure_openai_api_version,
            azure_endpoint=settings.azure_openai_endpoint,
        )
    return _client


@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class StreamHandle:
    """Wraps a streaming completion so the caller can read usage at the end."""

    text: AsyncIterator[str]
    usage: Usage = field(default_factory=Usage)


async def stream_completion(
    *,
    deployment: str,
    system: str,
    cached_corpus: str | None,
    user_message: str,
    max_tokens: int = 16384,
    usage_out: Usage | None = None,
) -> AsyncIterator[str]:
    """Stream text deltas. If `usage_out` is provided, it is populated when
    the stream finishes (Azure sends a final chunk with `usage`)."""
    client = _get_client()

    messages: list[dict[str, str]] = [{"role": "system", "content": system}]
    if cached_corpus:
        messages.append(
            {
                "role": "user",
                "content": f"<project_context>\n{cached_corpus}\n</project_context>",
            }
        )
    messages.append({"role": "user", "content": user_message})

    create_kwargs: dict[str, Any] = {
        "model": deployment,
        "messages": messages,
        "stream": True,
        "stream_options": {"include_usage": True},
        "max_completion_tokens": max_tokens,
    }

    try:
        stream = await client.chat.completions.create(**create_kwargs)
    except Exception as exc:
        msg = str(exc).lower()
        if "max_completion_tokens" in msg or "unsupported parameter" in msg:
            create_kwargs.pop("max_completion_tokens", None)
            create_kwargs["max_tokens"] = max_tokens
            stream = await client.chat.completions.create(**create_kwargs)
        elif "stream_options" in msg:
            create_kwargs.pop("stream_options", None)
            stream = await client.chat.completions.create(**create_kwargs)
        else:
            raise

    async for chunk in stream:
        # Final usage chunk has empty `choices` and a populated `usage`.
        if usage_out is not None and getattr(chunk, "usage", None):
            u = chunk.usage
            usage_out.prompt_tokens = getattr(u, "prompt_tokens", 0) or 0
            usage_out.completion_tokens = getattr(u, "completion_tokens", 0) or 0
            usage_out.total_tokens = getattr(u, "total_tokens", 0) or 0
        if not chunk.choices:
            continue
        delta = chunk.choices[0].delta
        text = getattr(delta, "content", None)
        if text:
            yield text
