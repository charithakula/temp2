import io

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireAdmin, RequireAuthor, RequireViewer
from app.core.db import get_session
from app.models.entities import SCSVersion
from app.schemas.scs import SCSGenerateRequest, SCSVersionOut, SCSVersionUpdate
from app.services.audit import record as audit
from app.services.scs_generator import stream_scs

router = APIRouter(prefix="/projects/{project_id}/scs", tags=["scs"])


@router.post("/generate")
async def generate_scs(
    project_id: str,
    payload: SCSGenerateRequest,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    return StreamingResponse(
        stream_scs(
            session=session,
            project_id=project_id,
            actor_oid=user.oid,
            steering=payload.steering,
            deployment=payload.deployment,
        ),
        media_type="text/event-stream",
    )


@router.get("", response_model=list[SCSVersionOut])
async def list_versions(
    project_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> list[SCSVersionOut]:
    rows = (
        await session.execute(
            select(SCSVersion)
            .where(SCSVersion.project_id == project_id)
            .order_by(SCSVersion.version_no.desc())
        )
    ).scalars().all()
    return [SCSVersionOut.model_validate(r, from_attributes=True) for r in rows]


@router.get("/{version_id}", response_model=SCSVersionOut)
async def get_version(
    project_id: str,
    version_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> SCSVersionOut:
    v = await session.get(SCSVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version not found")
    return SCSVersionOut.model_validate(v, from_attributes=True)


@router.put("/{version_id}", response_model=SCSVersionOut)
async def update_version(
    project_id: str,
    version_id: str,
    payload: SCSVersionUpdate,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> SCSVersionOut:
    v = await session.get(SCSVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version not found")
    v.markdown = payload.markdown
    await session.commit()
    await session.refresh(v)
    await audit(
        session,
        user=user,
        action="scs.update",
        project_id=project_id,
        entity_type="scs_version",
        entity_id=v.id,
        metadata={"version_no": v.version_no, "chars": len(v.markdown)},
    )
    return SCSVersionOut.model_validate(v, from_attributes=True)


@router.post("/{version_id}/approve", response_model=SCSVersionOut)
async def approve_version(
    project_id: str,
    version_id: str,
    user=RequireAdmin,
    session: AsyncSession = Depends(get_session),
) -> SCSVersionOut:
    v = await session.get(SCSVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version not found")
    v.status = "approved"
    await session.commit()
    await session.refresh(v)
    await audit(
        session,
        user=user,
        action="scs.approve",
        project_id=project_id,
        entity_type="scs_version",
        entity_id=v.id,
        metadata={"version_no": v.version_no},
    )
    return SCSVersionOut.model_validate(v, from_attributes=True)


@router.get("/{a_id}/diff/{b_id}")
async def diff_versions(
    project_id: str,
    a_id: str,
    b_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> dict:
    a = await session.get(SCSVersion, a_id)
    b = await session.get(SCSVersion, b_id)
    if a is None or a.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version A not found")
    if b is None or b.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version B not found")
    import difflib

    diff = "\n".join(
        difflib.unified_diff(
            a.markdown.splitlines(),
            b.markdown.splitlines(),
            fromfile=f"v{a.version_no}",
            tofile=f"v{b.version_no}",
            lineterm="",
        )
    )
    return {
        "from": {"id": a.id, "version_no": a.version_no},
        "to": {"id": b.id, "version_no": b.version_no},
        "unified_diff": diff,
    }


@router.get("/{version_id}/export")
async def export_version(
    project_id: str,
    version_id: str,
    format: str = Query(default="md", pattern="^(md|docx)$"),
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> Response:
    v = await session.get(SCSVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="SCS version not found")

    filename = f"scs-v{v.version_no}.{format}"
    if format == "md":
        await audit(
            session,
            user=user,
            action="scs.export",
            project_id=project_id,
            entity_type="scs_version",
            entity_id=v.id,
            metadata={"format": "md"},
        )
        return Response(
            content=v.markdown,
            media_type="text/markdown; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # DOCX export
    from app.services.docx_export import markdown_to_docx_bytes

    buf = io.BytesIO(markdown_to_docx_bytes(v.markdown))

    await audit(
        session,
        user=user,
        action="scs.export",
        project_id=project_id,
        entity_type="scs_version",
        entity_id=v.id,
        metadata={"format": "docx"},
    )
    return Response(
        content=buf.getvalue(),
        media_type=(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        ),
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
