# SDLC AI Assistant

AI-driven SDLC automation for the **Integration 360 / CE platform** under **AMI 2.0**.
Upload a BRD / FDS / user stories, get a draft Solution / System Component Specification
(**SCS / TDS**), have a human review and approve it, then generate an **OpenAPI 3.1**
specification aligned to the approved design.

> Adopted from proven Infosys SDLC tooling and adapted for the CE / Integration 360
> platform. Owner: **Charith Akula**. Stakeholders: Omprakash Dornala (sponsor), Pavan
> (feasibility review).

---

## What's in this repo

```
sdlc-ai-assistant/
├── docs/                  Requirements, architecture, API contract, deployment
│   ├── REQUIREMENTS.md
│   ├── ARCHITECTURE.md
│   ├── API_CONTRACT.md
│   └── DEPLOYMENT_AZURE.md
├── frontend/              Next.js 16 + React 19 + Tailwind 4 + TypeScript
│   └── src/
│       ├── app/           App Router pages (login, projects, audit)
│       ├── components/    AppShell, workspace tabs, UI primitives
│       └── lib/           api client, auth context, MSAL helper
├── backend/               FastAPI 0.115 + Pydantic v2 + SQLAlchemy 2.0 (async)
│   ├── app/
│   │   ├── api/v1/        REST + SSE routes (projects, uploads, scs,
│   │   │                  openapi, chat, audit, /me)
│   │   ├── core/          config, db, auth (Entra ID + dev role)
│   │   ├── services/      llm_client (Azure OpenAI), embeddings (pgvector),
│   │   │                  ingestion (PDF/DOCX/MD/TXT), scs_generator,
│   │   │                  openapi_generator, chat_service, audit,
│   │   │                  storage (Blob with local fallback),
│   │   │                  pii (regex scanner), token_cap, docx_export
│   │   ├── models/        SQLAlchemy entities + pgvector embedding column
│   │   ├── schemas/       Pydantic request/response models
│   │   └── prompts/       Versioned system + user prompt templates
│   ├── alembic/           DB migrations
│   └── tests/             pytest — RBAC matrix, uploads, audit
├── infra/azure/           Bicep — Web Apps, Postgres+pgvector, Azure OpenAI,
│                          Key Vault, Storage, App Insights
├── samples/               Sample BRD inputs + generated SCS outputs (md + docx)
├── .github/workflows/     CI (lint + typecheck + pytest) + deploy workflows
└── README.md              ← you are here
```

## Tech stack

| Layer        | Choice                                                                |
|--------------|-----------------------------------------------------------------------|
| Frontend     | **Next.js 16** (App Router), React 19, TypeScript 6, Tailwind CSS 4   |
| Backend      | **FastAPI 0.115** on Python 3.11, Pydantic v2, Uvicorn / Gunicorn     |
| LLM          | **Azure OpenAI Service** — chat-completions + embeddings              |
| RAG          | **pgvector** on Postgres (cosine distance), chunked at 1500 chars     |
| Database     | Azure Database for PostgreSQL Flexible Server (SQLite locally)        |
| Storage      | Azure Blob Storage (originals + exports), local-uploads/ fallback     |
| Auth         | **Microsoft Entra ID** via MSAL — dev role-picker fallback locally    |
| RBAC         | `Viewer` < `Author` < `Admin` enforced server-side on every write     |
| Hosting      | Azure Web Apps (Linux) for both frontend and backend                  |
| IaC          | Bicep modules in `infra/azure/`                                       |
| CI/CD        | GitHub Actions — CI on every PR, OIDC deploy on push to `main`        |

## How the workflow looks

```
1.  User signs in (Entra ID in prod, dev role-picker locally).
2.  Create a project — bundles documents, SCS versions, OpenAPI versions, audit log.
3.  Upload BRD / FDS / user stories — text extracted, chunked, embedded into pgvector.
4.  Click "Generate SCS" — Azure OpenAI streams a draft Markdown spec into the editor.
5.  Edit it. Save. Repeat. Each save creates a new draft version.
6.  Admin clicks "Approve" on a version  →  unlocks OpenAPI generation.
7.  Click "Generate OpenAPI" — streams a YAML spec aligned to the approved SCS,
    auto-validated against the OpenAPI 3.1 schema.
8.  Download .md / .docx (SCS) or .yaml / .json (OpenAPI), or preview Swagger UI inline.
```

Project-scoped chat (RAG-grounded) is available throughout — answers cite the project's
documents and the latest SCS version. Every meaningful action is recorded to the audit log.

---

## Local development

### Prerequisites

- **Python 3.11+** (project tested on 3.11 and 3.13)
- **Node 20 LTS** + npm 10+
- An **Azure OpenAI** resource with at least one chat-completions deployment
  (e.g. `gpt-4o` or `gpt-5.2-chat`). For full RAG also create a `text-embedding-3-small`
  deployment — without it the app falls back to sending the full document text.
- (Optional, for full Postgres + pgvector path) Docker or a Postgres 16 server with the
  `vector` extension. Local dev runs on **SQLite** by default; embeddings still persist
  there as JSON-encoded vectors with an in-Python cosine fallback.

### 1. Clone and configure

```bash
git clone <this-repo>
cd sdlc-ai-assistant

# Backend secrets — never commit this file (already in .gitignore)
cp backend/.env.example backend/.env
# Edit backend/.env and fill in:
#   AZURE_OPENAI_ENDPOINT     https://<resource>.openai.azure.com/
#   AZURE_OPENAI_API_KEY      <key from Azure Portal → Keys and Endpoint>
#   AZURE_OPENAI_API_VERSION  2024-12-01-preview  (or whatever your resource supports)
#   AZURE_OPENAI_DEPLOYMENT   <your chat deployment name>
#   AZURE_OPENAI_EMBEDDING_DEPLOYMENT  text-embedding-3-small  (if you provisioned one)

cp frontend/.env.local.example frontend/.env.local
# Frontend defaults to http://localhost:8000/api/v1 — only change this if the backend
# is on a different host/port. Leave the NEXT_PUBLIC_ENTRA_* vars empty for dev.
```

### 2. Run the backend

```bash
cd backend
python -m venv .venv
source .venv/Scripts/activate          # Windows bash;  use .venv/bin/activate on macOS/Linux
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

- Swagger UI: <http://127.0.0.1:8000/docs>
- Health check: <http://127.0.0.1:8000/health>

The first run creates `backend/local.db` (SQLite) automatically.

### 3. Run the frontend

```bash
cd frontend
npm install
npm run dev                            # http://localhost:3000
```

You'll land on `/login`. In dev mode, pick **Viewer / Author / Admin** to exercise the
RBAC matrix. Production swaps this for **Sign in with Microsoft** automatically the
moment `NEXT_PUBLIC_ENTRA_TENANT_ID` and `NEXT_PUBLIC_ENTRA_CLIENT_ID` are set.

### 4. Verify

```bash
# Backend tests
cd backend && pytest -q                # RBAC, uploads, audit, document delete
# Frontend typecheck + lint
cd ../frontend && npm run typecheck && npm run lint
```

---

## RBAC at a glance

| Role     | Can view | Can author / upload / generate / chat | Can approve SCS | Can delete project |
|----------|:-------:|:------------------------------------:|:--------------:|:------------------:|
| Viewer   |    ✓    |                                      |                |                    |
| Author   |    ✓    |                  ✓                   |                |                    |
| Admin    |    ✓    |                  ✓                   |       ✓        |         ✓          |

In production roles flow from the Entra ID `roles` claim on the access token. Locally,
the dev login attaches `X-Dev-Role` which the backend reads as a stand-in.

## Azure OpenAI deployments

The single integration point at [`backend/app/services/llm_client.py`](backend/app/services/llm_client.py)
calls Azure OpenAI's Chat Completions API in streaming mode. It auto-falls back from
`max_completion_tokens` (gpt-5.x / o-series) to `max_tokens` (gpt-4o and earlier) so it
works with any deployment.

| Purpose       | Default deployment env var                     |
|---------------|------------------------------------------------|
| SCS gen       | `AZURE_OPENAI_SCS_DEPLOYMENT`                  |
| OpenAPI gen   | `AZURE_OPENAI_OPENAPI_DEPLOYMENT`              |
| Chat          | `AZURE_OPENAI_CHAT_DEPLOYMENT`                 |
| Embeddings    | `AZURE_OPENAI_EMBEDDING_DEPLOYMENT`            |
| **Shared**    | `AZURE_OPENAI_DEPLOYMENT` — falls through if any of the above three are unset |

If you only have one deployment, set `AZURE_OPENAI_DEPLOYMENT` and leave the rest blank.

## Sample artifacts to demo with

The repo ships three end-to-end examples in [`samples/`](samples/):

| BRD (input)                                 | Generated SCS (md + docx)                              |
|---------------------------------------------|--------------------------------------------------------|
| `samples/brd/order-management.md`           | `samples/scs/oms-integration.{md,docx}`                |
| `samples/brd/customer-onboarding.md`        | `samples/scs/customer-onboarding-kyc.{md,docx}`        |
| `samples/brd/loyalty-rewards.md`            | `samples/scs/loyalty-rewards.{md,docx}`                |

Open the `.docx` files in Word — proper headings, bullet lists, and **real Word tables**
(not pipe-separated text). The Markdown sources show what actually got generated by the
live model.

---

## Deploying to Azure

Provision the whole environment (Web Apps, Postgres + pgvector, Azure OpenAI deployments,
Key Vault, Storage, App Insights) with the Bicep modules in [`infra/azure/`](infra/azure/):

```bash
RG=rg-sdlc-ai-dev
LOC=eastus2

az group create -n $RG -l $LOC
export POSTGRES_PASSWORD='<strong-password>'      # consumed by main.dev.bicepparam
az deployment group create -g $RG \
  --template-file infra/azure/main.bicep \
  --parameters infra/azure/main.dev.bicepparam
```

Then push to `main` — the GitHub Actions workflows in `.github/workflows/` deploy both
Web Apps via Azure OIDC. Required GitHub secrets: `AZURE_CLIENT_ID`, `AZURE_TENANT_ID`,
`AZURE_SUBSCRIPTION_ID`, `AZURE_BACKEND_APP_NAME`, `AZURE_FRONTEND_APP_NAME`.

Full deployment runbook: [`docs/DEPLOYMENT_AZURE.md`](docs/DEPLOYMENT_AZURE.md).

---

## What's done · what's pending

### Implemented
- ✅ FastAPI backend with async SQLAlchemy + Pydantic v2
- ✅ Azure OpenAI integration (chat + embeddings + streaming SSE)
- ✅ pgvector RAG with SQLite/in-Python fallback
- ✅ PDF / DOCX / MD / TXT ingestion + chunking
- ✅ SCS generator + OpenAPI generator (validated against OpenAPI 3.1 schema)
- ✅ Project-scoped chat with retrieval-grounded answers
- ✅ Token usage tracking + per-project token cap (429 on exceed)
- ✅ Audit log for create / upload / generate / update / approve / delete / export
- ✅ RBAC (Viewer / Author / Admin) — enforced server-side, mirrored in UI
- ✅ Exports — SCS to `.md` / `.docx` (with real Word tables), OpenAPI to `.yaml` / `.json`
- ✅ SCS diff endpoint between any two versions
- ✅ PII detection on upload (email, SSN, credit card, PAN, Aadhaar, AWS keys, bearer tokens)
- ✅ Persistent file storage — Azure Blob in prod, `local-uploads/` in dev
- ✅ Alembic migrations
- ✅ Backend pytest suite — 10 tests covering RBAC and upload flows
- ✅ Next.js 16 frontend — login page, app shell, projects list, project workspace
- ✅ Workspace tabs — Inputs, SCS (Markdown editor + live preview), OpenAPI (YAML + Swagger UI), Chat, Audit
- ✅ Streaming abort — Cancel/Stop on every long-running generation
- ✅ react-markdown + remark-gfm + syntax highlighting in SCS preview
- ✅ Dark mode toggle (persisted), mobile hamburger, keyboard shortcuts (`g p`, `g a`, `c`, `?`)
- ✅ MSAL wiring — activates the moment Entra env vars are populated
- ✅ Bicep IaC for the full environment
- ✅ CI workflow — ruff + pytest for backend, tsc + next lint for frontend
- ✅ Sample BRDs + generated SCS bundles in `samples/`

### Pending — needs Azure / external setup
- ⏳ **Real Entra ID** sign-in — code is wired, just needs an app registration
- ⏳ **Provision Azure OpenAI embedding deployment** if you want full RAG
- ⏳ **Provision Postgres + pgvector** to graduate beyond the SQLite fallback
- ⏳ **App Insights cost dashboard** — telemetry hooks are placeholders

### Pending — product decisions
- ⏳ SharePoint connector (Phase 1.5)
- ⏳ Octane / Helix / Jira integrations (Phase 2)
- ⏳ Code stub generation from approved OpenAPI (Phase 3)
- ⏳ Multi-tenant, comments-on-SCS-sections, i18n (future)

---

## Documentation

| Doc                                              | What it covers |
|--------------------------------------------------|------------------------------------------------------------|
| [docs/REQUIREMENTS.md](docs/REQUIREMENTS.md)     | Goals, in/out of scope, FRs, NFRs, acceptance criteria, open questions |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)     | Component diagram, data model (incl. `document_chunks` + ivfflat), RAG pipeline, sequence flow, phasing, risks |
| [docs/API_CONTRACT.md](docs/API_CONTRACT.md)     | Every REST + SSE endpoint with request/response shapes |
| [docs/DEPLOYMENT_AZURE.md](docs/DEPLOYMENT_AZURE.md) | Azure resources, app settings, Postgres + pgvector setup, cost guardrails |
| [backend/README.md](backend/README.md)           | Backend layout + conventions |
| [frontend/README.md](frontend/README.md)         | Frontend layout + conventions |
| [infra/azure/README.md](infra/azure/README.md)   | Bicep deploy steps |

## Conventions worth knowing before you change code

- **One LLM integration point** — all model calls go through
  [`backend/app/services/llm_client.py`](backend/app/services/llm_client.py). Routes
  never call the OpenAI SDK directly. This is what lets us swap providers (e.g., to
  Anthropic) without touching prompts or routes.
- **Prompts are versioned files** under [`backend/app/prompts/`](backend/app/prompts/);
  the SHA-256 hash of the rendered prompt is persisted alongside every generated
  artifact (`prompt_hash` column) for traceability.
- **Streaming is SSE** — every long-running generation streams `event: token` frames
  followed by a final `event: done`. The frontend has one `streamSSE` helper that all
  three streaming endpoints share.
- **Frontend never `fetch`es directly** — everything goes through `frontend/src/lib/api.ts`,
  which attaches auth headers (real Entra token if MSAL is configured, otherwise dev
  headers).
- **Don't commit `.env`** — gitignored. Treat any pasted API key as compromised; rotate
  it in Azure Portal → your resource → Keys and Endpoint → Regenerate Key 1.

## Getting unstuck

| Symptom | What it usually means |
|---|---|
| Upload says `chunks_indexed: 0` | Embedding deployment isn't provisioned on your AOAI resource. SCS generation still works (full-text fallback). |
| `DeploymentNotFound` on chat | Your `AZURE_OPENAI_DEPLOYMENT` name doesn't match a deployment in Azure Portal — names are user-defined, not the model name. |
| Empty SCS output | gpt-5.x / o-series models burn `max_completion_tokens` on hidden reasoning. Increase the limit (already 16k by default in `llm_client.py`). |
| 401 on every API call | You haven't signed in via `/login`, or your dev session expired (cleared on Sign Out). |
| Dark mode doesn't toggle | Make sure you reloaded after the latest code; Tailwind v4 needs `@custom-variant dark` in `globals.css` (already set). |
| `PATCH /projects/{id}` returns 405 | Backend wasn't restarted after route changes. Restart uvicorn cold. |
| Frontend hot reload feels slow | Some changes trigger a full Next 16 reload — benign, just slower. |
