"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Button, Field, Spinner, inputClass } from "@/components/ui";
import { useAuth } from "@/lib/auth";
import { msalConfigured, signInPopup } from "@/lib/msal";
import type { Role } from "@/lib/api";

const ROLES: { value: Role; description: string }[] = [
  {
    value: "Viewer",
    description: "Read-only — browse projects, SCS, and OpenAPI versions.",
  },
  {
    value: "Author",
    description: "Create projects, upload docs, generate SCS / OpenAPI, chat.",
  },
  {
    value: "Admin",
    description: "Author + approve SCS and delete projects.",
  },
];

const FEATURES = [
  {
    title: "Requirement → Design",
    body: "Drop in a BRD, FDS, or user stories. Get a Solution / System Component Specification grounded in your documents.",
  },
  {
    title: "Approve, then API",
    body: "Once a human reviews and approves the SCS, the assistant produces an OpenAPI 3.1 YAML aligned to it.",
  },
  {
    title: "Built for Integration 360 / CE",
    body: "Azure OpenAI for the LLM, pgvector for retrieval, Entra ID for sign-in. Lands inside the platform you already run.",
  },
];

export default function LoginPage() {
  const router = useRouter();
  const { ready, signedIn, signIn } = useAuth();
  const [email, setEmail] = useState("dev@example.com");
  const [role, setRole] = useState<Role>("Author");
  const [submitting, setSubmitting] = useState(false);
  const [msalSubmitting, setMsalSubmitting] = useState(false);

  useEffect(() => {
    if (ready && signedIn) router.replace("/projects");
  }, [ready, signedIn, router]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    setSubmitting(true);
    signIn(email.trim(), role);
  }

  async function submitMsal() {
    setMsalSubmitting(true);
    try {
      const account = await signInPopup();
      if (!account) {
        setMsalSubmitting(false);
        return;
      }
      // For now, default Entra-signed-in users to Author. Real role comes
      // from the `roles` claim on the access token; enforced by the backend.
      signIn(account.username || "user@entra", "Author");
    } catch (err) {
      console.error(err);
      setMsalSubmitting(false);
    }
  }

  return (
    <div className="grid min-h-screen grid-cols-1 lg:grid-cols-[1.05fr_1fr]">
      {/* Brand panel */}
      <div className="bg-mesh-brand relative hidden flex-col justify-between overflow-hidden p-10 text-white lg:flex">
        <div className="absolute inset-0 bg-dotgrid opacity-20" aria-hidden />
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-white/15 ring-1 ring-white/30 backdrop-blur">
              <span className="text-sm font-bold">AI</span>
            </div>
            <div className="text-sm font-semibold tracking-wide">
              SDLC AI Assistant
            </div>
          </div>
          <h1 className="mt-12 max-w-md text-4xl font-semibold leading-tight tracking-tight">
            Turn requirements into design and API specs — in minutes.
          </h1>
          <p className="mt-4 max-w-md text-sm text-white/80">
            Adopted from proven Infosys tooling, adapted for the Integration 360
            / CE platform under AMI 2.0.
          </p>
        </div>

        <div className="relative space-y-5">
          {FEATURES.map((f) => (
            <div key={f.title} className="flex items-start gap-3">
              <div className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white/15 text-[11px] font-semibold ring-1 ring-white/30">
                ✓
              </div>
              <div>
                <div className="text-sm font-medium">{f.title}</div>
                <div className="mt-0.5 text-xs text-white/75">{f.body}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="relative text-[11px] text-white/60">
          Internal · Integration 360 / CE · AMI 2.0
        </div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center bg-slate-50 px-6 py-12">
        <div className="w-full max-w-sm">
          {/* Mobile-only logo */}
          <div className="mb-6 flex items-center gap-2 lg:hidden">
            <div className="grid h-8 w-8 place-items-center rounded-md bg-brand-600 text-[11px] font-bold text-white">
              AI
            </div>
            <div className="text-sm font-semibold text-slate-900">
              SDLC AI Assistant
            </div>
          </div>

          <h2 className="text-2xl font-semibold tracking-tight text-slate-900">
            Sign in
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Pick a role to explore the assistant. Microsoft Entra ID (SSO)
            replaces this in production.
          </p>

          <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[11px] text-amber-800">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
            Dev mode
          </div>

          <form onSubmit={submit} className="mt-6 space-y-5">
            <Field label="Email">
              <input
                type="email"
                required
                className={inputClass}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </Field>

            <Field
              label="Role"
              hint="Determines which actions you can perform — enforced by the API."
            >
              <div className="grid grid-cols-1 gap-2">
                {ROLES.map((r) => (
                  <button
                    type="button"
                    key={r.value}
                    onClick={() => setRole(r.value)}
                    className={`rounded-lg border px-3 py-2.5 text-left text-sm transition-all ${
                      role === r.value
                        ? "border-brand-500 bg-brand-50/60 ring-2 ring-brand-500/20"
                        : "border-slate-200 bg-white hover:border-slate-300"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-900">
                        {r.value}
                      </span>
                      {role === r.value && <Badge tone="brand">Selected</Badge>}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-500">
                      {r.description}
                    </div>
                  </button>
                ))}
              </div>
            </Field>

            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? <Spinner /> : "Continue"}
            </Button>

            <div className="flex items-center gap-3 text-[11px] text-slate-400">
              <span className="h-px flex-1 bg-slate-200" />
              <span>Production sign-in</span>
              <span className="h-px flex-1 bg-slate-200" />
            </div>

            {msalConfigured ? (
              <button
                type="button"
                onClick={submitMsal}
                disabled={msalSubmitting}
                className="flex w-full items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 disabled:opacity-50"
              >
                {msalSubmitting ? <Spinner /> : <MicrosoftLogo />}
                Sign in with Microsoft
              </button>
            ) : (
              <button
                type="button"
                disabled
                className="flex w-full items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-4 py-2 text-sm text-slate-400"
                title="Set NEXT_PUBLIC_ENTRA_TENANT_ID + NEXT_PUBLIC_ENTRA_CLIENT_ID to enable"
              >
                <MicrosoftLogo />
                Sign in with Microsoft
                <Badge tone="slate">Configure Entra ID</Badge>
              </button>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}

function MicrosoftLogo() {
  return (
    <svg viewBox="0 0 23 23" className="h-4 w-4" aria-hidden>
      <rect x="1" y="1" width="10" height="10" fill="#F25022" />
      <rect x="12" y="1" width="10" height="10" fill="#7FBA00" />
      <rect x="1" y="12" width="10" height="10" fill="#00A4EF" />
      <rect x="12" y="12" width="10" height="10" fill="#FFB900" />
    </svg>
  );
}
