"""Helpers for emitting Server-Sent Events."""
import json
from typing import Any


def sse(event: str, data: Any) -> bytes:
    payload = data if isinstance(data, str) else json.dumps(data)
    return f"event: {event}\ndata: {payload}\n\n".encode()
