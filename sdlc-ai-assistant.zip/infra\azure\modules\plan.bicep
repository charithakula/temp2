param name string
param location string
param tags object
@description('Environment label — selects SKU tier (B2 for dev, P1v3 for prod).')
param env string = 'dev'

var sku = env == 'prod' ? 'P1v3' : 'B2'
var tier = env == 'prod' ? 'PremiumV3' : 'Basic'

resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: name
  location: location
  tags: tags
  kind: 'linux'
  sku: { name: sku, tier: tier }
  properties: { reserved: true }
}

output id string = plan.id
output name string = plan.name
