# Architecture — SDLC AI Assistant

**Version:** 0.1 (Draft)
**Last updated:** 2026-04-29

---

## 1. High-level diagram

```
                        ┌─────────────────────────────────────┐
                        │         Browser (User)              │
                        │   Next.js 15 App Router + Tailwind  │
                        └───────────────┬─────────────────────┘
                                        │ HTTPS
                                        │ MSAL (Entra ID)
                                        ▼
                        ┌─────────────────────────────────────┐
                        │   Azure Front Door (optional)       │
                        │   • WAF / TLS termination           │
                        └───────────────┬─────────────────────┘
                                        │
              ┌─────────────────────────┴─────────────────────────┐
              ▼                                                   ▼
   ┌──────────────────────┐                          ┌──────────────────────┐
   │  Azure Web App       │                          │  Azure Web App       │
   │  (Frontend, Linux)   │  ─── REST / SSE ────►    │  (Backend, Linux)    │
   │  Node 20 · Next.js   │                          │  Python 3.11·FastAPI │
   └──────────────────────┘                          └──────────┬───────────┘
                                                                │
              ┌─────────────────────────────────────────────────┼─────────────┐
              ▼                          ▼                      ▼             ▼
    ┌───────────────────┐   ┌──────────────────────┐  ┌──────────────────────┐  ┌────────────┐
    │ Azure OpenAI      │   │ Azure Blob Storage   │  │ Azure Postgres       │  │ Azure Key  │
    │  Service          │   │ • Uploaded docs      │  │ Flexible Server      │  │ Vault      │
    │  (gpt-4o /        │   │ • Generated bundles  │  │ + pgvector           │  │ • Secrets  │
    │   gpt-4o-mini /   │   │                      │  │ • Projects           │  │ • Conn str │
    │   embeddings)     │   │                      │  │ • Documents + chunks │  └────────────┘
    └───────────────────┘   └──────────────────────┘  │ • SCS / OpenAPI vers │
                                                      │ • Audit log          │
                                                      └──────────────────────┘
                                                      └────────────────┘
                                                              │
                                                              ▼
                                                    ┌────────────────────┐
                                                    │ Application        │
                                                    │ Insights / Log     │
                                                    │ Analytics          │
                                                    └────────────────────┘
```

## 2. Component responsibilities

### Frontend — Next.js 15 (App Router)

- **Auth** via `@azure/msal-react` against Entra ID; stores ID/access tokens in memory (no localStorage for tokens)
- **Pages**
  - `/projects` — list, create, archive
  - `/projects/[id]` — workspace: tabs for *Inputs*, *SCS*, *OpenAPI*, *Chat*, *Audit*
  - `/projects/[id]/scs/[versionId]` — markdown editor + live preview
  - `/projects/[id]/openapi/[versionId]` — YAML editor + Swagger UI preview
- **Streaming UI** — Server-Sent Events (SSE) consumer for token streaming during generation
- **Styling** — Tailwind CSS + a small shared component library (Button, Card, Tabs, Toast)
- **State** — React Query for server state; Zustand for ephemeral UI state

### Backend — FastAPI

| Module | Purpose |
|---|---|
| `app/main.py` | App factory, CORS, middleware, lifespan (DB pool, LLM client) |
| `app/core/config.py` | Pydantic settings — env vars for Azure / Anthropic / DB |
| `app/core/auth.py` | Entra ID JWT validation (JWKS) |
| `app/core/logging.py` | Structured logs → Application Insights |
| `app/api/v1/projects.py` | CRUD for projects |
| `app/api/v1/uploads.py` | Pre-signed upload to Blob; metadata persistence |
| `app/api/v1/scs.py` | Trigger SCS generation; stream output; version mgmt |
| `app/api/v1/openapi.py` | Generate/validate OpenAPI YAML |
| `app/api/v1/chat.py` | Project-scoped chat endpoint (streaming) |
| `app/services/ingestion.py` | PDF/DOCX/MD/TXT → normalized text + heading tree |
| `app/services/scs_generator.py` | Builds SCS prompt, calls Claude, post-processes |
| `app/services/openapi_generator.py` | Builds OpenAPI prompt from approved SCS, validates via `openapi-spec-validator` |
| `app/services/llm_client.py` | Thin wrapper around the Azure OpenAI Chat Completions API (streaming) — single integration point |
| `app/prompts/*.md` | Versioned prompt templates (system + user scaffolds) |

### Data layer

- **Azure Database for PostgreSQL Flexible Server** with the **`vector` (pgvector) extension** enabled.
  - Tables: `projects`, `documents`, **`document_chunks`** (with `embedding vector(1536)` for RAG), `scs_versions`, `openapi_versions`, `chat_messages`, `audit_log`.
  - Connection: `postgresql+asyncpg://...` over TLS (`ssl=require`).
  - Local dev: SQLite fallback (`sqlite+aiosqlite:///./local.db`) — RAG falls back to in-Python cosine over JSON-encoded vectors so end-to-end works without a DB.
- **Azure Blob Storage**: original uploaded documents, exported DOCX/PDF/YAML bundles.
- **Azure Key Vault**: Azure OpenAI API key, DB connection string, SharePoint client secret.

### LLM integration (Azure OpenAI Service)

- Default deployments (configurable per environment):
  - **SCS generation** — `gpt-4o` (quality)
  - **OpenAPI generation** — `gpt-4o-mini` (deterministic, cost-efficient)
  - **Chat** — `gpt-4o-mini`
  - **Embeddings** — `text-embedding-3-small` (1536-dim) for the RAG corpus
- Routes always pass an Azure OpenAI **deployment name** (not a raw model name) — deployments are provisioned in the Azure OpenAI resource and may be backed by different model versions per environment.
- Streaming responses surfaced over **SSE** to the frontend (Azure OpenAI Chat Completions `stream=True`).
- All prompts versioned in `app/prompts/` and identified by SHA-256 hash so generated artifacts can be traced to the exact prompt + corpus that produced them.

### RAG pipeline (pgvector)

1. On upload, documents are extracted, chunked (~1500 chars / 200 overlap), embedded via Azure OpenAI embeddings, and stored as rows in `document_chunks` with an `embedding vector(1536)` column.
2. On SCS generation, a query vector is built from the SCS prompt's intent (architecture / APIs / flows) plus the user's optional steering, and the top-K (default 20) nearest chunks are retrieved with `ORDER BY embedding <=> :qvec`.
3. Retrieved chunks are concatenated as the **cached corpus** sent to the chat completion alongside the system prompt and user request.
4. Chat uses the same retrieval with a smaller K (default 8), and additionally appends the latest SCS markdown for grounding.
5. If embeddings are unavailable (e.g., `AZURE_OPENAI_API_KEY` missing) or retrieval fails, the system falls back to sending the raw extracted text up to a fixed character cap.

## 3. Data model (initial)

```
Project              SCSVersion                    OpenAPIVersion
─────────            ──────────────                ──────────────────
id (uuid) PK         id (uuid) PK                  id (uuid) PK
name                 project_id FK                 project_id FK
created_by           version_no                    scs_version_id FK
created_at           status (draft|approved)       version_no
status               markdown (text)               yaml (text)
                     prompt_hash                   prompt_hash
                     model                         model
                     token_usage_in/out            token_usage_in/out
                     created_by, created_at        validation_errors (json)
                                                   created_by, created_at

Document             DocumentChunk                 ChatMessage / AuditLog
─────────            ──────────────                ──────────────────
id (uuid) PK         id (uuid) PK                  (as before)
project_id FK        document_id FK
filename             project_id (idx)
blob_url             chunk_index
content_type         content (text)
size_bytes           embedding vector(1536)  ← pgvector
text_extracted (text) created_at
created_at
```

The `document_chunks.embedding` column uses **pgvector**. Similarity search is performed with the cosine distance operator (`embedding <=> :qvec`). An IVFFlat index can be added later under load:

```sql
CREATE INDEX ON document_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

## 4. Sequence — SCS generation

```
User                Frontend            Backend              Azure OpenAI
 │                    │                    │                    │
 │ Click "Generate"   │                    │                    │
 ├───────────────────►│                    │                    │
 │                    │ POST /scs/generate │                    │
 │                    ├───────────────────►│                    │
 │                    │                    │ Load project docs  │
 │                    │                    │ Build messages     │
 │                    │                    │ (system + corpus + │
 │                    │                    │  user request)     │
 │                    │                    ├───────────────────►│
 │                    │                    │                    │ Stream tokens
 │                    │ SSE stream         │◄───────────────────┤
 │                    │◄───────────────────┤                    │
 │ Live preview       │                    │ Persist version    │
 │◄───────────────────┤                    │ Update audit log   │
```

## 5. Security

- All endpoints require a valid Entra ID access token (audience = backend app registration).
- Per-project authorization checked in a FastAPI dependency.
- Uploaded files scanned with Defender for Storage (Azure-side).
- Secrets only in Key Vault — referenced via Web App's Managed Identity.
- CSP / HSTS headers on the frontend.
- Azure OpenAI: data stays within the Azure tenant; not used for training (per Azure OpenAI service terms). Use the same Azure region as the rest of the resources to keep traffic in-region.

## 6. Observability

- **Application Insights** for both apps (request traces, dependencies, exceptions).
- Custom telemetry: model name, tokens in/out, cache hit ratio, generation duration, prompt hash.
- Per-project cost dashboard (Log Analytics workbook).

## 7. Phasing

| Phase | Scope | Target |
|---|---|---|
| **MVP (Phase 1)** | UC-1 + UC-2, upload-only, single-tenant, Entra SSO | 6–8 weeks |
| **Phase 1.5** | SharePoint connector, DOCX/PDF export polish | +3 weeks |
| **Phase 2** | Octane / Jira / Helix integrations, fine-tuned templates per BU | +6 weeks |
| **Phase 3** | Code-stub generation from OpenAPI; deeper Integration 360 hooks | TBD |

## 8. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Generic / low-quality SCS output | Rich grounding (full document corpus via prompt caching), per-domain prompt templates, human-in-the-loop |
| Hallucinated APIs in OpenAPI | Validate generated YAML; require approved SCS as the only input; show source citations |
| Cost overrun on large BRDs | Per-project token cap; route OpenAPI + chat to gpt-4o-mini; reserve gpt-4o for SCS generation |
| Sensitive data leaving tenant | Azure OpenAI keeps traffic + data inside the Azure tenant (no training on inputs); document-level RBAC |
| Vendor lock-in on LLM | `services/llm_client.py` is the single integration point — swap providers without touching prompts or routes |
