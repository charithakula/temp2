"use client";

import dynamic from "next/dynamic";
import { useEffect, useMemo, useRef, useState } from "react";

function DownloadIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" fill="none" className={className} aria-hidden>
      <path
        d="M8 2v8m0 0L4.5 6.5M8 10l3.5-3.5M3 13h10"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
import yaml from "js-yaml";
import { useToast } from "@/components/toast";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Spinner,
} from "@/components/ui";
import { api, type OpenAPIVersion, type SCSVersion } from "@/lib/api";
import { hasRole, useAuth } from "@/lib/auth";
import "swagger-ui-react/swagger-ui.css";

const SwaggerUI = dynamic(() => import("swagger-ui-react"), { ssr: false });

type ViewMode = "yaml" | "preview";

export function OpenApiTab({ projectId }: { projectId: string }) {
  const { role } = useAuth();
  const toast = useToast();
  const [scsList, setScsList] = useState<SCSVersion[]>([]);
  const [versions, setVersions] = useState<OpenAPIVersion[] | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [yamlText, setYamlText] = useState("");
  const [generating, setGenerating] = useState(false);
  const [scsForGen, setScsForGen] = useState<string | "">("");
  const [view, setView] = useState<ViewMode>("yaml");
  const abortRef = useRef<AbortController | null>(null);

  const canGenerate = hasRole(role, "Author");
  const approvedScs = useMemo(
    () => scsList.filter((s) => s.status === "approved"),
    [scsList],
  );
  const active = useMemo(
    () => versions?.find((v) => v.id === activeId) ?? null,
    [versions, activeId],
  );

  async function refresh(selectId?: string) {
    try {
      const [scs, opens] = await Promise.all([
        api.listSCS(projectId),
        api.listOpenAPI(projectId),
      ]);
      setScsList(scs);
      setVersions(opens);
      const next = opens.find((r) => r.id === selectId) ?? opens[0] ?? null;
      setActiveId(next?.id ?? null);
      setYamlText(next?.yaml ?? "");
      const approved = scs.find((s) => s.status === "approved");
      setScsForGen((cur) => cur || approved?.id || "");
    } catch (e) {
      toast.push(`Failed to load OpenAPI: ${(e as Error).message}`, "error");
      setVersions([]);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  async function generate() {
    if (!canGenerate || !scsForGen) return;
    setGenerating(true);
    setYamlText("");
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const result = await api.streamOpenAPI(
        projectId,
        { scs_version_id: scsForGen },
        (delta) => setYamlText((cur) => cur + delta),
        ctrl.signal,
      );
      if (!result) {
        toast.push("Generation cancelled");
        return;
      }
      const errCount = result.validation_errors.length ?? 0;
      toast.push(
        errCount === 0
          ? `Generated OpenAPI v${result.version_no} · valid`
          : `Generated OpenAPI v${result.version_no} · ${errCount} validation error(s)`,
        errCount === 0 ? "success" : "error",
      );
      await refresh(result.version_id);
    } catch (e) {
      toast.push(`Generation failed: ${(e as Error).message}`, "error");
    } finally {
      setGenerating(false);
      abortRef.current = null;
    }
  }

  function cancelGenerate() {
    abortRef.current?.abort();
  }

  async function download(format: "yaml" | "json") {
    if (!active) return;
    try {
      await api.downloadExport(
        api.exportOpenAPIUrl(projectId, active.id, format),
        `openapi-v${active.version_no}.${format}`,
      );
    } catch (e) {
      toast.push(`Download failed: ${(e as Error).message}`, "error");
    }
  }

  if (versions === null) {
    return (
      <div className="flex justify-center p-10">
        <Spinner />
      </div>
    );
  }

  const errors: string[] = active?.validation_errors
    ? safeJson(active.validation_errors) ?? []
    : [];

  let parsedSpec: object | null = null;
  if (yamlText) {
    try {
      const v = yaml.load(yamlText);
      if (v && typeof v === "object") parsedSpec = v as object;
    } catch {
      parsedSpec = null;
    }
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        {approvedScs.length === 0 ? (
          <div className="text-sm text-slate-600 dark:text-slate-300">
            <span className="font-medium text-slate-900 dark:text-slate-100">
              Approve an SCS first.
            </span>{" "}
            Go to the SCS tab, generate a draft, review it, then have an Admin
            click <span className="font-medium">Approve</span>. OpenAPI
            generation requires an approved SCS as the single source of truth.
          </div>
        ) : (
          <div className="flex flex-col gap-3 md:flex-row md:items-end">
            <div className="flex-1">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                Generate from approved SCS
              </label>
              <select
                className="mt-1 w-full rounded-md border border-slate-300 bg-white px-2 py-2 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                value={scsForGen}
                onChange={(e) => setScsForGen(e.target.value)}
              >
                {approvedScs.map((s) => (
                  <option key={s.id} value={s.id}>
                    v{s.version_no} · approved ·{" "}
                    {new Date(s.created_at).toLocaleString()}
                  </option>
                ))}
              </select>
            </div>
            {generating ? (
              <Button variant="secondary" onClick={cancelGenerate}>
                Cancel
              </Button>
            ) : (
              <Button onClick={generate} disabled={!canGenerate || !scsForGen}>
                Generate OpenAPI
              </Button>
            )}
          </div>
        )}
      </Card>

      {versions.length === 0 && !generating && approvedScs.length > 0 && (
        <EmptyState
          title="No OpenAPI yet"
          body="Click Generate to create a YAML spec aligned to the approved SCS."
        />
      )}

      {(versions.length > 0 || generating) && (
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Version
              </span>
              <select
                className="rounded-md border border-slate-300 bg-white px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                value={activeId ?? ""}
                onChange={(e) => {
                  setActiveId(e.target.value);
                  const v = versions.find((x) => x.id === e.target.value);
                  setYamlText(v?.yaml ?? "");
                }}
              >
                {versions.map((v) => (
                  <option key={v.id} value={v.id}>
                    v{v.version_no} ·{" "}
                    {new Date(v.created_at).toLocaleString()}
                  </option>
                ))}
              </select>
              {active && (
                <Badge tone={errors.length === 0 ? "green" : "red"}>
                  {errors.length === 0 ? "valid" : `${errors.length} error(s)`}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex overflow-hidden rounded-md border border-slate-300 text-xs dark:border-slate-700">
                {(["yaml", "preview"] as ViewMode[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setView(m)}
                    className={`px-2 py-1 capitalize ${
                      view === m
                        ? "bg-brand-600 text-white"
                        : "bg-white text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
              {active && (
                <div className="flex overflow-hidden rounded-md border border-slate-300 text-xs dark:border-slate-700">
                  <button
                    onClick={() => download("yaml")}
                    className="flex items-center gap-1 bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Download as YAML"
                  >
                    <DownloadIcon className="h-3 w-3" />
                    .yaml
                  </button>
                  <span className="w-px bg-slate-300 dark:bg-slate-700" />
                  <button
                    onClick={() => download("json")}
                    className="flex items-center gap-1 bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Download as JSON"
                  >
                    <DownloadIcon className="h-3 w-3" />
                    .json
                  </button>
                </div>
              )}
            </div>
          </div>

          {errors.length > 0 && (
            <div className="border-b border-red-200 bg-red-50 px-4 py-3 dark:border-red-900/50 dark:bg-red-950/40">
              <div className="text-xs font-semibold text-red-800 dark:text-red-300">
                Validation errors
              </div>
              <ul className="mt-1 list-disc pl-5 text-xs text-red-700 dark:text-red-300">
                {errors.slice(0, 8).map((e, i) => (
                  <li key={i} className="wrap-break-word">
                    {e}
                  </li>
                ))}
                {errors.length > 8 && (
                  <li className="text-red-500">
                    …and {errors.length - 8} more
                  </li>
                )}
              </ul>
            </div>
          )}

          {view === "yaml" && (
            <pre className="h-[60vh] overflow-auto bg-slate-900 p-4 font-mono text-xs leading-relaxed text-slate-100">
              <code>{yamlText || "Generated YAML will stream here…"}</code>
            </pre>
          )}
          {view === "preview" && (
            <div className="h-[60vh] overflow-auto bg-white p-2 dark:bg-slate-900">
              {parsedSpec ? (
                <SwaggerUI spec={parsedSpec as never} />
              ) : (
                <div className="p-6 text-sm text-slate-500 dark:text-slate-400">
                  YAML isn't valid yet — preview unavailable.
                </div>
              )}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}

function safeJson(s: string): string[] | null {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : null;
  } catch {
    return null;
  }
}
