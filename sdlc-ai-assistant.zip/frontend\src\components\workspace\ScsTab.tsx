"use client";

import { useEffect, useMemo, useRef, useState } from "react";

function DownloadIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" fill="none" className={className} aria-hidden>
      <path
        d="M8 2v8m0 0L4.5 6.5M8 10l3.5-3.5M3 13h10"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
import { useToast } from "@/components/toast";
import { MdPreview } from "@/components/md-preview";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Spinner,
  inputClass,
} from "@/components/ui";
import { api, type SCSVersion } from "@/lib/api";
import { hasRole, useAuth } from "@/lib/auth";

type ViewMode = "split" | "edit" | "preview";

export function ScsTab({ projectId }: { projectId: string }) {
  const { role } = useAuth();
  const toast = useToast();
  const [versions, setVersions] = useState<SCSVersion[] | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [markdown, setMarkdown] = useState("");
  const [steering, setSteering] = useState("");
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [view, setView] = useState<ViewMode>("split");
  const [dirty, setDirty] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const canGenerate = hasRole(role, "Author");
  const canEdit = hasRole(role, "Author");
  const canApprove = hasRole(role, "Admin");

  const active = useMemo(
    () => versions?.find((v) => v.id === activeId) ?? null,
    [versions, activeId],
  );

  async function refresh(selectId?: string) {
    try {
      const rows = await api.listSCS(projectId);
      setVersions(rows);
      const next =
        rows.find((r) => r.id === selectId) ??
        rows[0] ??
        null;
      setActiveId(next?.id ?? null);
      setMarkdown(next?.markdown ?? "");
      setDirty(false);
    } catch (e) {
      toast.push(`Failed to load SCS: ${(e as Error).message}`, "error");
      setVersions([]);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  async function generate() {
    if (!canGenerate) return;
    if (
      dirty &&
      !confirm("You have unsaved edits. Generating will create a new version. Continue?")
    )
      return;
    setGenerating(true);
    setMarkdown("");
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const result = await api.streamSCS(
        projectId,
        { steering: steering.trim() || undefined },
        (delta) => setMarkdown((cur) => cur + delta),
        ctrl.signal,
      );
      if (result) {
        toast.push(
          `Generated SCS version ${result.version_no ?? "?"}`,
          "success",
        );
        await refresh(result.version_id);
      } else {
        toast.push("Generation cancelled");
      }
    } catch (e) {
      toast.push(`Generation failed: ${(e as Error).message}`, "error");
    } finally {
      setGenerating(false);
      abortRef.current = null;
    }
  }

  function cancelGenerate() {
    abortRef.current?.abort();
  }

  async function downloadExport(format: "md" | "docx") {
    if (!active) return;
    try {
      await api.downloadExport(
        api.exportSCSUrl(projectId, active.id, format),
        `scs-v${active.version_no}.${format}`,
      );
    } catch (e) {
      toast.push(`Download failed: ${(e as Error).message}`, "error");
    }
  }

  async function save() {
    if (!active || !canEdit) return;
    setSaving(true);
    try {
      const updated = await api.updateSCS(projectId, active.id, markdown);
      toast.push("Saved", "success");
      setVersions(
        (cur) =>
          cur?.map((v) => (v.id === updated.id ? updated : v)) ?? [updated],
      );
      setDirty(false);
    } catch (e) {
      toast.push((e as Error).message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function approve() {
    if (!active || !canApprove) return;
    if (!confirm(`Approve SCS version ${active.version_no}?`)) return;
    try {
      const updated = await api.approveSCS(projectId, active.id);
      toast.push(
        `Approved v${updated.version_no} — OpenAPI generation unlocked`,
        "success",
      );
      await refresh(updated.id);
    } catch (e) {
      toast.push((e as Error).message, "error");
    }
  }

  function selectVersion(id: string) {
    if (
      dirty &&
      !confirm("You have unsaved edits. Switching will discard them. Continue?")
    )
      return;
    const v = versions?.find((x) => x.id === id);
    if (!v) return;
    setActiveId(v.id);
    setMarkdown(v.markdown);
    setDirty(false);
  }

  if (versions === null) {
    return (
      <div className="flex justify-center p-10">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-end">
          <div className="flex-1">
            <Field
              label="Steering (optional)"
              hint="Extra guidance the AI should follow when drafting the SCS."
            >
              <input
                className={inputClass}
                placeholder="e.g. focus on the payments flow; use customer onboarding terminology"
                value={steering}
                onChange={(e) => setSteering(e.target.value)}
                disabled={generating}
              />
            </Field>
          </div>
          {generating ? (
            <Button variant="secondary" onClick={cancelGenerate}>
              Cancel
            </Button>
          ) : (
            <Button
              onClick={generate}
              disabled={!canGenerate}
              title={canGenerate ? "" : "Author role required"}
            >
              Generate SCS
            </Button>
          )}
        </div>
      </Card>

      {versions.length === 0 && !generating && (
        <Card className="px-6 py-10 text-center">
          <div className="mx-auto max-w-md">
            <div className="text-sm font-medium text-slate-900">
              No SCS yet
            </div>
            <p className="mt-1 text-sm text-slate-500">
              Upload your BRD/FDS in the{" "}
              <span className="font-medium text-slate-700">Inputs</span> tab,
              then click Generate above.
            </p>
          </div>
        </Card>
      )}

      {(versions.length > 0 || generating) && (
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Version
              </span>
              <select
                className="rounded-md border border-slate-300 bg-white px-2 py-1 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                value={activeId ?? ""}
                onChange={(e) => selectVersion(e.target.value)}
              >
                {versions.map((v) => (
                  <option key={v.id} value={v.id}>
                    v{v.version_no} ·{" "}
                    {new Date(v.created_at).toLocaleString()}
                  </option>
                ))}
              </select>
              {active && (
                <Badge tone={active.status === "approved" ? "green" : "amber"}>
                  {active.status}
                </Badge>
              )}
              {dirty && <Badge tone="amber">Unsaved</Badge>}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex overflow-hidden rounded-md border border-slate-300 text-xs dark:border-slate-700">
                {(["edit", "split", "preview"] as ViewMode[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setView(m)}
                    className={`px-2 py-1 capitalize ${
                      view === m
                        ? "bg-brand-600 text-white"
                        : "bg-white text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
              {active && (
                <div className="flex overflow-hidden rounded-md border border-slate-300 text-xs dark:border-slate-700">
                  <button
                    onClick={() => downloadExport("md")}
                    className="flex items-center gap-1 bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Download as Markdown"
                  >
                    <DownloadIcon className="h-3 w-3" />
                    .md
                  </button>
                  <span className="w-px bg-slate-300 dark:bg-slate-700" />
                  <button
                    onClick={() => downloadExport("docx")}
                    className="flex items-center gap-1 bg-white px-2.5 py-1 text-slate-700 hover:bg-slate-50 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Download as Word"
                  >
                    <DownloadIcon className="h-3 w-3" />
                    .docx
                  </button>
                </div>
              )}
              {(canEdit || canApprove) && active && (
                <div className="mx-1 h-6 w-px bg-slate-200 dark:bg-slate-700" />
              )}
              {canEdit && active && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={save}
                  disabled={!dirty || saving || generating}
                >
                  {saving ? <Spinner /> : "Save"}
                </Button>
              )}
              {canApprove && active && active.status !== "approved" && (
                <Button size="sm" onClick={approve} disabled={dirty}>
                  Approve
                </Button>
              )}
            </div>
          </div>

          <div
            className={`grid gap-0 ${
              view === "split" ? "md:grid-cols-2" : "grid-cols-1"
            }`}
          >
            {view !== "preview" && (
              <textarea
                className="h-[65vh] w-full resize-none border-0 border-r border-slate-200 bg-white p-4 font-mono text-xs leading-relaxed text-slate-900 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100"
                value={markdown}
                disabled={!canEdit && !generating}
                onChange={(e) => {
                  setMarkdown(e.target.value);
                  setDirty(true);
                }}
                placeholder="Generated SCS will stream here…"
              />
            )}
            {view !== "edit" && (
              <div className="h-[65vh] overflow-auto bg-white p-5 dark:bg-slate-950">
                {markdown ? (
                  <MdPreview source={markdown} />
                ) : (
                  <div className="text-sm text-slate-400">No content yet.</div>
                )}
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
