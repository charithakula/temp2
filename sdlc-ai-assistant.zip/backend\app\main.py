from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1 import router as v1_router
from app.core.auth import CurrentUserDep
from app.core.config import settings
from app.core.db import init_db
from app.core.logging import configure_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    await init_db()
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="SDLC AI Assistant API",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(v1_router, prefix="/api/v1")

    @app.get("/health", tags=["meta"])
    async def health() -> dict:
        return {"status": "ok", "version": app.version}

    @app.get("/api/v1/me", tags=["meta"])
    async def me(user=CurrentUserDep) -> dict:
        return {"oid": user.oid, "email": user.email, "roles": user.roles}

    return app


app = create_app()
