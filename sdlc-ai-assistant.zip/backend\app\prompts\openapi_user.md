Generate the OpenAPI 3.1 YAML specification now, derived strictly from the approved SCS provided above. Output only the YAML document.
