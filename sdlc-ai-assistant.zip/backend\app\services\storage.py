"""Persistent storage for uploaded documents and exported artifacts.

Production: Azure Blob Storage container `uploads` (set via
`STORAGE_CONNECTION_STRING`). Dev fallback: a local `./local-uploads/`
directory so the upload pipeline still works without an Azure account.
Returns a `blob_url` string that's stored on the Document row — for the
local fallback this is a `file://` URI used only as a pointer.
"""
from __future__ import annotations

import os
from pathlib import Path

from app.core.config import settings

_LOCAL_DIR = Path(__file__).resolve().parent.parent.parent / "local-uploads"
_LOCAL_DIR.mkdir(exist_ok=True)


def _is_blob_configured() -> bool:
    return bool(settings.storage_connection_string)


def store(*, project_id: str, document_id: str, filename: str, data: bytes) -> str:
    """Persist `data`; return a stable URL string."""
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in filename)
    key = f"{project_id}/{document_id}/{safe_name}"

    if _is_blob_configured():
        try:
            from azure.storage.blob import BlobServiceClient

            svc = BlobServiceClient.from_connection_string(
                settings.storage_connection_string
            )
            container = svc.get_container_client("uploads")
            try:
                container.create_container()
            except Exception:
                pass
            blob = container.get_blob_client(key)
            blob.upload_blob(data, overwrite=True)
            return blob.url
        except Exception:
            # Fall through to local on any blob failure (best-effort persistence).
            pass

    # Local fallback
    target = _LOCAL_DIR / project_id / document_id
    target.mkdir(parents=True, exist_ok=True)
    path = target / safe_name
    path.write_bytes(data)
    return path.absolute().as_uri()


def delete(blob_url: str | None) -> None:
    if not blob_url:
        return
    if blob_url.startswith("file://"):
        try:
            local = Path(blob_url.replace("file:///", "").replace("file://", ""))
            if os.name == "nt" and local.as_posix().startswith("/"):
                # Windows file:// URI parsing
                local = Path(blob_url[8:]) if blob_url.startswith("file:///") else local
            if local.exists():
                local.unlink()
        except Exception:
            pass
        return
    if _is_blob_configured():
        try:
            from azure.storage.blob import BlobClient

            BlobClient.from_blob_url(blob_url).delete_blob()
        except Exception:
            pass
