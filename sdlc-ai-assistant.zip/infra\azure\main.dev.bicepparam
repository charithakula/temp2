using './main.bicep'

param env = 'dev'
param postgresAdmin = 'sdlcadmin'
// Set via: az deployment group create ... --parameters postgresPassword=<value>
//                                                      openaiKey=<value>
param postgresPassword = readEnvironmentVariable('POSTGRES_PASSWORD', '')
param openaiKey = readEnvironmentVariable('AZURE_OPENAI_API_KEY', '')
