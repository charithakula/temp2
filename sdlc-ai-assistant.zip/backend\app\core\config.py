from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: str = "local"

    # ---- Azure OpenAI (LLM provider) ----
    azure_openai_endpoint: str = Field(default="", alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: str = Field(default="", alias="AZURE_OPENAI_API_KEY")
    azure_openai_api_version: str = Field(
        default="2024-10-21", alias="AZURE_OPENAI_API_VERSION"
    )
    # Single shared deployment (e.g. one gpt-4o deployment used for SCS + OpenAPI + chat).
    # If the per-purpose deployments below are unset, we fall back to this one.
    azure_openai_deployment: str = Field(
        default="", alias="AZURE_OPENAI_DEPLOYMENT"
    )
    azure_openai_scs_deployment: str = Field(
        default="", alias="AZURE_OPENAI_SCS_DEPLOYMENT"
    )
    azure_openai_openapi_deployment: str = Field(
        default="", alias="AZURE_OPENAI_OPENAPI_DEPLOYMENT"
    )
    azure_openai_chat_deployment: str = Field(
        default="", alias="AZURE_OPENAI_CHAT_DEPLOYMENT"
    )
    # Accept both AZURE_OPENAI_EMBEDDING_DEPLOYMENT (singular) and ..._EMBEDDINGS_...
    azure_openai_embeddings_deployment: str = Field(
        default="text-embedding-3-small",
        validation_alias="AZURE_OPENAI_EMBEDDING_DEPLOYMENT",
    )
    embeddings_dim: int = Field(default=1536, alias="EMBEDDINGS_DIM")

    @property
    def scs_deployment(self) -> str:
        return self.azure_openai_scs_deployment or self.azure_openai_deployment or "gpt-4o"

    @property
    def openapi_deployment(self) -> str:
        return self.azure_openai_openapi_deployment or self.azure_openai_deployment or "gpt-4o-mini"

    @property
    def chat_deployment(self) -> str:
        return self.azure_openai_chat_deployment or self.azure_openai_deployment or "gpt-4o-mini"

    # ---- Database (Azure Database for PostgreSQL Flexible Server, with pgvector) ----
    # Local fallback uses SQLite. Production must use postgresql+asyncpg://...
    database_url: str = Field(
        default="sqlite+aiosqlite:///./local.db", alias="DATABASE_URL"
    )

    # ---- Storage ----
    storage_connection_string: str = ""

    # ---- Auth ----
    entra_tenant_id: str = ""
    entra_api_client_id: str = ""
    # Dev-only: role assigned to the stub user. Production reads roles from the
    # Entra ID `roles` claim. Allowed: Viewer | Author | Admin.
    dev_role: str = Field(default="Author", alias="DEV_ROLE")

    # ---- App ----
    cors_allowed_origins: list[str] = ["http://localhost:3000"]
    project_token_cap_in: int = 1_000_000
    project_token_cap_out: int = 200_000

    @property
    def is_postgres(self) -> bool:
        return self.database_url.startswith("postgresql")


@lru_cache
def _settings() -> Settings:
    return Settings()


settings = _settings()
