from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireAuthor
from app.core.db import get_session
from app.schemas.chat import ChatRequest
from app.services.chat_service import stream_chat

router = APIRouter(prefix="/projects/{project_id}/chat", tags=["chat"])


@router.post("")
async def chat(
    project_id: str,
    payload: ChatRequest,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    return StreamingResponse(
        stream_chat(
            session=session,
            project_id=project_id,
            message=payload.message,
            history=payload.history,
        ),
        media_type="text/event-stream",
    )
