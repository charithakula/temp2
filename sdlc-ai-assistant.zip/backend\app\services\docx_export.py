"""Convert SCS markdown to a Word .docx with proper headings, lists, tables,
fenced code, and basic inline formatting (bold, italic, inline code, links).

Tables: a GFM table is detected by a header row, a separator row of dashes,
then body rows. Each is rendered with `doc.add_table` using the 'Light Grid'
style so it actually shows borders in Word.
"""
from __future__ import annotations

import io
import re
from typing import Iterable

from docx import Document
from docx.shared import Pt, RGBColor

_BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
_ITALIC_RE = re.compile(r"(?<!\*)\*([^*]+?)\*(?!\*)")
_INLINE_CODE_RE = re.compile(r"`([^`]+)`")
_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def _parse_table(lines: list[str], i: int) -> tuple[list[list[str]], int] | None:
    """If lines[i] starts a GFM table, return (rows, next_index). Else None.

    A GFM table is:
      | h1 | h2 |
      |----|----|
      | a  | b  |
    The pipe wrappers are optional in some flavors, but our LLM output uses them.
    """
    if i >= len(lines):
        return None
    head = lines[i].strip()
    if not (head.startswith("|") and head.endswith("|")):
        return None
    if i + 1 >= len(lines):
        return None
    sep = lines[i + 1].strip()
    if not re.match(r"^\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?$", sep):
        return None

    def split_row(row: str) -> list[str]:
        cells = [c.strip() for c in row.strip().strip("|").split("|")]
        return cells

    rows: list[list[str]] = [split_row(head)]
    j = i + 2
    while j < len(lines):
        row = lines[j].strip()
        if not (row.startswith("|") and row.endswith("|")):
            break
        rows.append(split_row(row))
        j += 1
    return rows, j


def _add_inline(paragraph, text: str) -> None:
    """Append text into `paragraph` interpreting **bold**, *italic*, `code`, [link](href)."""
    pos = 0
    # We do a single-pass scan picking the earliest match of any pattern.
    while pos < len(text):
        # Find earliest match
        candidates = []
        for kind, pat in (
            ("link", _LINK_RE),
            ("bold", _BOLD_RE),
            ("italic", _ITALIC_RE),
            ("code", _INLINE_CODE_RE),
        ):
            m = pat.search(text, pos)
            if m:
                candidates.append((m.start(), kind, m))
        if not candidates:
            paragraph.add_run(text[pos:])
            return
        candidates.sort(key=lambda x: x[0])
        start, kind, m = candidates[0]
        if start > pos:
            paragraph.add_run(text[pos:start])
        if kind == "bold":
            r = paragraph.add_run(m.group(1))
            r.bold = True
        elif kind == "italic":
            r = paragraph.add_run(m.group(1))
            r.italic = True
        elif kind == "code":
            r = paragraph.add_run(m.group(1))
            r.font.name = "Consolas"
            r.font.size = Pt(10)
        else:  # link
            r = paragraph.add_run(f"{m.group(1)} ({m.group(2)})")
            r.font.color.rgb = RGBColor(0x1D, 0x4E, 0xD8)
        pos = m.end()


def _iter_blocks(lines: list[str]) -> Iterable[tuple[str, object]]:
    """Yield (kind, payload) blocks. kind ∈ {h1..h4, p, ul, ol, table, code, blank}."""
    i = 0
    while i < len(lines):
        raw = lines[i]
        line = raw.rstrip()
        s = line.strip()

        # Fenced code block
        if s.startswith("```"):
            j = i + 1
            buf: list[str] = []
            while j < len(lines) and not lines[j].lstrip().startswith("```"):
                buf.append(lines[j])
                j += 1
            yield ("code", "\n".join(buf))
            i = j + 1
            continue

        # Table
        tbl = _parse_table(lines, i)
        if tbl is not None:
            rows, ni = tbl
            yield ("table", rows)
            i = ni
            continue

        # Headings
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            level = min(len(m.group(1)), 4)
            yield (f"h{level}", m.group(2))
            i += 1
            continue

        # Bullet list (collect contiguous items)
        if re.match(r"^[-*]\s+", s):
            items: list[str] = []
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i].strip()):
                items.append(re.sub(r"^[-*]\s+", "", lines[i].strip()))
                i += 1
            yield ("ul", items)
            continue

        # Numbered list
        if re.match(r"^\d+\.\s+", s):
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i].strip()):
                items.append(re.sub(r"^\d+\.\s+", "", lines[i].strip()))
                i += 1
            yield ("ol", items)
            continue

        if s == "":
            yield ("blank", None)
            i += 1
            continue

        yield ("p", line)
        i += 1


def markdown_to_docx_bytes(markdown: str) -> bytes:
    doc = Document()
    lines = markdown.replace("\r\n", "\n").split("\n")

    for kind, payload in _iter_blocks(lines):
        if kind in {"h1", "h2", "h3", "h4"}:
            level = int(kind[1])
            p = doc.add_heading("", level=level)
            _add_inline(p, str(payload))
        elif kind == "p":
            p = doc.add_paragraph()
            _add_inline(p, str(payload))
        elif kind == "ul":
            for item in payload:  # type: ignore[arg-type]
                p = doc.add_paragraph(style="List Bullet")
                _add_inline(p, item)
        elif kind == "ol":
            for item in payload:  # type: ignore[arg-type]
                p = doc.add_paragraph(style="List Number")
                _add_inline(p, item)
        elif kind == "code":
            p = doc.add_paragraph()
            r = p.add_run(str(payload))
            r.font.name = "Consolas"
            r.font.size = Pt(9)
        elif kind == "table":
            rows: list[list[str]] = payload  # type: ignore[assignment]
            cols = max(len(r) for r in rows)
            t = doc.add_table(rows=len(rows), cols=cols)
            try:
                t.style = "Light Grid Accent 1"
            except KeyError:
                t.style = "Table Grid"
            for ri, row in enumerate(rows):
                for ci in range(cols):
                    cell = t.cell(ri, ci)
                    cell.text = ""  # ensure clean paragraph
                    p = cell.paragraphs[0]
                    text = row[ci] if ci < len(row) else ""
                    if ri == 0:
                        r = p.add_run(text)
                        r.bold = True
                    else:
                        _add_inline(p, text)
            doc.add_paragraph("")  # spacer after table
        elif kind == "blank":
            doc.add_paragraph("")

    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()
