# Solution / System Component Specification

## 1. Executive Summary
This system enables real-time loyalty points accrual, redemption, and tier management for the e-commerce platform by integrating the OMS, CE Storefront, and the Capillary loyalty vendor. It replaces delayed, batch-based reconciliation with event-driven and API-led interactions to ensure points are visible to customers within seconds of order confirmation. The solution also introduces checkout-time redemption with safeguards against double-spend, and operational capabilities for audited manual adjustments. A daily tier computation process maintains Silver/Gold/Platinum status based on rolling spend and publishes tier-change events to downstream systems. The overall goal is a single, consistent source of truth for loyalty data across channels, reducing customer support tickets and improving customer experience.

## 2. Scope

### In Scope
- Real-time points accrual on order payment confirmation.
- Real-time points redemption at checkout with lock/confirm/release semantics.
- Customer-facing APIs for balance and points history.
- Daily tier computation based on rolling 12-month spend.
- Manual points credit/debit with audit trail and approval controls.
- Integrations with OMS, CE Storefront, Capillary, and CRM.

### Out of Scope
- Partner-funded or third-party points.
- Family or household points pooling.
- Gamification features (missions, badges).
- Non-MVP redemption types explicitly excluded in the BRD.

### Assumptions
- OMS reliably publishes `oms.order.status.v1` events for paid, cancelled, and refunded states.
- Capillary APIs behave as documented and support idempotent operations where required.
- Customer identity is consistently resolvable across OMS, Storefront, and loyalty vendor.

### Dependencies
- Capillary loyalty platform availability and OAuth 2.0 configuration.
- OMS event delivery guarantees.
- CRM subscription to `loyalty.tier.changed.v1` events.

## 3. Architecture Overview

### Components and Responsibilities
- **CE Storefront**: Initiates balance lookup, redemption quote, and history requests; displays points and tier to customers.
- **OMS**: Publishes order lifecycle events (paid, cancelled, refunded).
- **Integration 360 / CE Platform (Loyalty Service)**:
  - Listens to OMS events.
  - Applies earn/redemption rules.
  - Orchestrates calls to Capillary.
  - Exposes APIs to Storefront and Ops.
  - Maintains audit and idempotency controls.
- **Capillary (Loyalty Vendor)**: System of record for points balance, accrual, redemption, and history.
- **CRM**: Consumes tier-change events for customer communications.
- **Operations UI / Tools**: Used by `loyalty_admin` users for manual adjustments.

### Interaction Diagram
```mermaid
flowchart LR
  OMS -- oms.order.status.v1 --> LoyaltySvc
  Storefront -- balance / redeem-quote / history --> LoyaltySvc
  LoyaltySvc -- /accrue --> Capillary
  LoyaltySvc -- /redeem-quote --> Capillary
  LoyaltySvc -- /redeem-confirm --> Capillary
  LoyaltySvc -- /redeem-release --> Capillary
  LoyaltySvc -- /balance /history --> Capillary
  LoyaltySvc -- loyalty.tier.changed.v1 --> CRM
  OpsUser -- manual adjustment --> LoyaltySvc
```

## 4. Required APIs

| API Name | Purpose | Consumer | Provider | Auth |
|--------|---------|----------|----------|------|
| `/accrue` | Accrue points for a confirmed purchase | Loyalty Service | Capillary | OAuth 2.0 |
| `/redeem-quote` | Validate and lock points for checkout redemption | Loyalty Service | Capillary | OAuth 2.0 |
| `/redeem-confirm` | Confirm and finalize redemption on order placement | Loyalty Service | Capillary | OAuth 2.0 |
| `/redeem-release` | Release locked points on cancellation/timeout | Loyalty Service | Capillary | OAuth 2.0 |
| `/balance` | Retrieve current points balance | Loyalty Service | Capillary | OAuth 2.0 |
| `/history` | Retrieve accrual/redemption history | Loyalty Service | Capillary | OAuth 2.0 |
| Balance API | Expose points balance to storefront | CE Storefront | Loyalty Service | TBD |
| Redeem Quote API | Initiate redemption validation from checkout | CE Storefront | Loyalty Service | TBD |
| History API | Expose paginated points history | CE Storefront | Loyalty Service | TBD |

> Note: Storefront-facing API authentication and authorization are not specified in the BRD and remain open.

## 5. Request / Response Flows

### UC-A: Earn Points on Purchase
1. OMS emits `oms.order.status.v1` with status `paid`.
2. Loyalty Service receives event and checks idempotency.
3. Earn rules are applied (earn rate, birthday multiplier).
4. Loyalty Service calls Capillary `/accrue`.
5. Capillary confirms accrual.
6. Points become visible via balance/history APIs.

**Primary Entities**: Order, Customer, Points Transaction.

### UC-B: Redeem Points at Checkout
1. Storefront calls Loyalty Service Redeem Quote API with desired points.
2. Loyalty Service calls Capillary `/redeem-quote` to validate and lock points.
3. On order placement, Loyalty Service calls `/redeem-confirm`.
4. On cancellation or timeout, Loyalty Service calls `/redeem-release`.

**Primary Entities**: Cart/Order, Redemption Lock, Points Balance.

### UC-C: View Points History
1. Storefront calls History API with pagination and date filters.
2. Loyalty Service queries Capillary `/history`.
3. Results returned with timestamps, order IDs, and reason codes.

### UC-D: Tier Computation
1. Daily scheduled job evaluates rolling 365-day spend per customer.
2. Tier is recalculated and updated.
3. On tier-up, Loyalty Service emits `loyalty.tier.changed.v1`.
4. CRM triggers congratulatory communication.

### UC-E: Manual Adjustment
1. Ops user submits credit/debit with reason and reference.
2. Loyalty Service enforces approval rules (dual approval >5,000 points).
3. Adjustment is applied via Capillary and audited.

## 6. Integration & Sequence Details

- **Capillary Integration**:
  - All calls via REST with OAuth 2.0.
  - `/accrue` must be idempotent to handle OMS event redelivery (NFR-2).
  - `/redeem-confirm` must prevent double-spend under retries (NFR-3).
- **Retry Semantics**:
  - Transient failures retried by Loyalty Service.
  - Idempotency keys derived from order ID and transaction type.
- **Refund Handling**:
  - OMS `refunded` events trigger reversal of previously granted points proportional to refunded amount.
- **Error Handling**:
  - Vendor errors surfaced to callers where applicable (e.g., insufficient points).
  - Failed background operations logged and alerting applied.

## 7. Data Model

### Key Entities
- **Customer**
  - Customer ID
  - Tier (Silver/Gold/Platinum)
- **Order**
  - Order ID
  - Amount
  - Status
- **Points Transaction**
  - Transaction ID
  - Type (Accrual, Redemption, Adjustment, Reversal)
  - Points
  - Timestamp
  - Reason Code
  - Reference (Order ID, Ticket ID)
- **Tier Evaluation**
  - Customer ID
  - Rolling 12-month spend
  - Effective tier
- **Audit Record**
  - Actor (system or user)
  - Action
  - Timestamp
  - Approval metadata (if applicable)

### Relationships
- Customer 1..* Points Transactions  
- Order 0..* Points Transactions  
- Customer 1..1 Tier Evaluation  

## 8. Non-functional Requirements

- **Performance**
  - Earn-on-purchase end-to-end latency ≤ 5 seconds P95.
  - Points history queries (12 months) < 500 ms.
- **Reliability**
  - Idempotent processing for accrual and redemption.
  - No double-spend under retry scenarios.
- **Security**
  - OAuth 2.0 for vendor integrations.
  - Role-based access for manual adjustments (`loyalty_admin`).
- **Audit & Compliance**
  - Full audit trail for all manual adjustments.
  - Dual approval required for adjustments above 5,000 points.
- **Observability**
  - Logging and metrics for API calls, retries, and failures.

## 9. Open Questions
- Should redemption be allowed against shipping or gift cards in MVP, or only merchandise?
- Where should points expiry warnings be delivered: email only or also push?
- Are tier criteria strictly spend-based, or should visit frequency be included?
- What authentication/authorization mechanism should be used for Storefront-facing APIs?
- Is Capillary the authoritative store for tier state, or should tier also be persisted locally for performance?