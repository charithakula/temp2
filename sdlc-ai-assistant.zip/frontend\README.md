# Frontend — SDLC AI Assistant

Next.js 15 (App Router) + TypeScript + Tailwind CSS.

## Run locally

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Open http://localhost:3000.

## Layout

```
src/
  app/
    layout.tsx        # shell — header / footer
    page.tsx          # landing page
    projects/
      page.tsx        # list + create projects
      [id]/page.tsx   # project workspace (Inputs / SCS / OpenAPI / Chat tabs)
    globals.css
  lib/
    api.ts            # typed client for the FastAPI backend (incl. SSE)
  components/         # (TBD) shared UI primitives
```

## Conventions

- Tailwind utility classes only — no CSS modules.
- All backend calls go through `lib/api.ts`. Don't `fetch` directly from components.
- Streaming endpoints surface a callback signature: `(delta: string) => void`.
- Auth: stub today (`Bearer dev`). Wire `@azure/msal-react` before any non-local environment.
