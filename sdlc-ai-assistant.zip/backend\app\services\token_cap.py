"""Per-project token cap enforcement.

Sums tokens_in/tokens_out across SCS + OpenAPI versions for a project and
raises a 429 if the configured caps are exceeded before a new generation.
"""
from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entities import OpenAPIVersion, SCSVersion


async def check_cap(session: AsyncSession, project_id: str) -> None:
    scs_in = (
        await session.execute(
            select(func.coalesce(func.sum(SCSVersion.tokens_in), 0)).where(
                SCSVersion.project_id == project_id
            )
        )
    ).scalar_one()
    scs_out = (
        await session.execute(
            select(func.coalesce(func.sum(SCSVersion.tokens_out), 0)).where(
                SCSVersion.project_id == project_id
            )
        )
    ).scalar_one()
    api_in = (
        await session.execute(
            select(func.coalesce(func.sum(OpenAPIVersion.tokens_in), 0)).where(
                OpenAPIVersion.project_id == project_id
            )
        )
    ).scalar_one()
    api_out = (
        await session.execute(
            select(func.coalesce(func.sum(OpenAPIVersion.tokens_out), 0)).where(
                OpenAPIVersion.project_id == project_id
            )
        )
    ).scalar_one()

    total_in = int(scs_in) + int(api_in)
    total_out = int(scs_out) + int(api_out)

    if total_in >= settings.project_token_cap_in:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=(
                f"Project input-token cap reached ({total_in:,} / "
                f"{settings.project_token_cap_in:,}). Contact an admin to raise the limit."
            ),
        )
    if total_out >= settings.project_token_cap_out:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=(
                f"Project output-token cap reached ({total_out:,} / "
                f"{settings.project_token_cap_out:,})."
            ),
        )
