param name string
param location string
param tags object
@description('Map of secretName => secretValue.')
@secure()
param secrets object

resource kv 'Microsoft.KeyVault/vaults@2024-04-01-preview' = {
  name: name
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: { family: 'A', name: 'standard' }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
    publicNetworkAccess: 'Enabled'
  }
}

resource s 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' = [
  for k in items(secrets): {
    parent: kv
    name: k.key
    properties: { value: k.value }
  }
]

output name string = kv.name
output id string = kv.id

@description('Build a secret URI to reference from app settings: @Microsoft.KeyVault(SecretUri=...).')
func secretUri(secretName string) string =>
  '${kv.properties.vaultUri}secrets/${secretName}/'
