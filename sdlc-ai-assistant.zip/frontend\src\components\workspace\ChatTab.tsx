"use client";

import { useEffect, useRef, useState } from "react";
import { useToast } from "@/components/toast";
import { Button, Card, Spinner } from "@/components/ui";
import { api } from "@/lib/api";
import { hasRole, useAuth } from "@/lib/auth";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatTab({ projectId }: { projectId: string }) {
  const { role } = useAuth();
  const toast = useToast();
  const [history, setHistory] = useState<Msg[]>([]);
  const [draft, setDraft] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamBuf, setStreamBuf] = useState("");
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const canChat = hasRole(role, "Author");

  useEffect(() => {
    scrollerRef.current?.scrollTo({
      top: scrollerRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [history, streamBuf]);

  async function send() {
    const text = draft.trim();
    if (!text || streaming || !canChat) return;
    setDraft("");
    const userMsg: Msg = { role: "user", content: text };
    setHistory((h) => [...h, userMsg]);
    setStreamBuf("");
    setStreaming(true);

    let buf = "";
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      await api.streamChat(
        projectId,
        { message: text, history: [...history, userMsg] },
        (delta) => {
          buf += delta;
          setStreamBuf(buf);
        },
        ctrl.signal,
      );
      if (buf) {
        setHistory((h) => [...h, { role: "assistant", content: buf }]);
      }
      setStreamBuf("");
    } catch (e) {
      toast.push(`Chat error: ${(e as Error).message}`, "error");
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  }

  function cancelStream() {
    abortRef.current?.abort();
  }

  return (
    <div className="flex h-[70vh] flex-col gap-3">
      <Card className="flex flex-1 flex-col overflow-hidden">
        <div className="border-b border-slate-200 px-4 py-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          Project-scoped chat — answers cite this project's documents and the
          latest SCS.
        </div>
        <div ref={scrollerRef} className="flex-1 space-y-3 overflow-auto p-4">
          {history.length === 0 && !streaming && (
            <div className="flex h-full items-center justify-center text-sm text-slate-400 dark:text-slate-500">
              Ask a question about the BRD, the SCS, or the OpenAPI spec.
            </div>
          )}
          {history.map((m, i) => (
            <Bubble key={i} role={m.role} text={m.content} />
          ))}
          {streaming && <Bubble role="assistant" text={streamBuf} streaming />}
        </div>
        <div className="border-t border-slate-200 p-3 dark:border-slate-800">
          <div className="flex gap-2">
            <textarea
              className="flex-1 resize-none rounded-md border border-slate-300 bg-white px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500"
              rows={2}
              placeholder={
                canChat ? "Ask anything…" : "Sign in as Author or Admin to chat"
              }
              value={draft}
              disabled={!canChat || streaming}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            {streaming ? (
              <Button variant="secondary" onClick={cancelStream}>
                Stop
              </Button>
            ) : (
              <Button onClick={send} disabled={!canChat || !draft.trim()}>
                Send
              </Button>
            )}
          </div>
          <div className="mt-1 text-[11px] text-slate-400 dark:text-slate-500">
            Enter to send · Shift+Enter for newline
          </div>
        </div>
      </Card>
    </div>
  );
}

function Bubble({
  role,
  text,
  streaming,
}: {
  role: "user" | "assistant";
  text: string;
  streaming?: boolean;
}) {
  const isUser = role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] whitespace-pre-wrap rounded-lg px-3 py-2 text-sm ${
          isUser
            ? "bg-brand-600 text-white"
            : "border border-slate-200 bg-white text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
        }`}
      >
        {text}
        {streaming && <span className="ml-1 animate-pulse">▍</span>}
      </div>
    </div>
  );
}
