"""Convert uploaded documents into normalized text for grounding the LLM.

Supported types: PDF, DOCX, Markdown, plain text.
"""
from __future__ import annotations

import io

from docx import Document as DocxDocument
from pypdf import PdfReader


def extract_text(filename: str, content_type: str | None, data: bytes) -> str:
    name = (filename or "").lower()
    ct = (content_type or "").lower()

    if name.endswith(".pdf") or "pdf" in ct:
        return _extract_pdf(data)
    if name.endswith(".docx") or "officedocument.wordprocessingml" in ct:
        return _extract_docx(data)
    # md / txt / unknown — best effort decode.
    return data.decode("utf-8", errors="replace")


def _extract_pdf(data: bytes) -> str:
    reader = PdfReader(io.BytesIO(data))
    parts: list[str] = []
    for page in reader.pages:
        parts.append(page.extract_text() or "")
    return "\n\n".join(parts).strip()


def _extract_docx(data: bytes) -> str:
    doc = DocxDocument(io.BytesIO(data))
    parts: list[str] = []
    for p in doc.paragraphs:
        if p.text:
            parts.append(p.text)
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text for c in row.cells if c.text]
            if cells:
                parts.append(" | ".join(cells))
    return "\n".join(parts).strip()


def build_corpus(documents: list[tuple[str, str]]) -> str:
    """Build a single corpus string from (filename, extracted_text) pairs.

    The corpus is the long, stable prefix sent before the user's request.
    """
    blocks: list[str] = []
    for filename, text in documents:
        if not text.strip():
            continue
        blocks.append(f"=== Document: {filename} ===\n{text.strip()}")
    return "\n\n".join(blocks)
