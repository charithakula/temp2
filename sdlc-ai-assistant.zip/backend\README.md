# Backend — SDLC AI Assistant

FastAPI service for SCS / OpenAPI generation and project-scoped chat. Calls **Azure OpenAI Service** through a single integration point ([app/services/llm_client.py](app/services/llm_client.py)) and uses **pgvector** on **Azure Database for PostgreSQL Flexible Server** for RAG retrieval over project documents.

## Run locally

```bash
cd backend
python -m venv .venv
source .venv/Scripts/activate    # Windows bash; use .venv/bin/activate elsewhere
pip install -r requirements.txt
cp .env.example .env             # then fill in AZURE_OPENAI_* + (optionally) DATABASE_URL
uvicorn app.main:app --reload --port 8000
```

Local dev uses **SQLite** by default (no Postgres required). Embeddings still work — they're stored as JSON-encoded vectors and searched with an in-Python cosine fallback. Switch `DATABASE_URL` to Postgres when you want real `pgvector` ANN search.

Open http://localhost:8000/docs for the auto-generated Swagger UI.

## Layout

```
app/
  main.py             # FastAPI factory, CORS, lifespan (DB init), /health
  core/               # config, logging, db, auth (Entra ID JWT)
  api/v1/             # route modules — projects, uploads, scs, openapi, chat
  schemas/            # Pydantic request/response models
  services/
    llm_client.py     # Azure OpenAI Chat Completions (streaming) — single integration point
    embeddings.py     # chunking + Azure OpenAI embeddings + pgvector retrieval
    ingestion.py      # PDF/DOCX/MD/TXT → normalized text
    scs_generator.py  # RAG-grounded SCS generation
    openapi_generator.py
    chat_service.py
    sse.py
  prompts/            # versioned system + user prompts
  models/entities.py  # SQLAlchemy + pgvector models
tests/
```

## Conventions

- One integration point for the LLM ([services/llm_client.py](app/services/llm_client.py)). Routes never call the OpenAI SDK directly.
- Prompts live under [prompts/](app/prompts) as Markdown. The SHA-256 hash of the rendered prompt is persisted with each generated artifact for traceability.
- All long-running generation endpoints stream over **SSE** (`text/event-stream`).
- Vector search uses pgvector cosine distance (`embedding <=> :qvec`). On SQLite, an in-Python cosine fallback runs so dev still works without Postgres.
