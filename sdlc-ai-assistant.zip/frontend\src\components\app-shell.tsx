"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { Badge, Button, Modal, Spinner } from "@/components/ui";
import { useAuth } from "@/lib/auth";

const NAV = [
  { href: "/projects", label: "Projects", icon: FolderIcon, key: "p" },
  { href: "/audit", label: "Audit", icon: AuditIcon, key: "a" },
];

const SHORTCUTS = [
  { keys: "g p", action: "Go to Projects" },
  { keys: "g a", action: "Go to Audit" },
  { keys: "c", action: "New project (on Projects page)" },
  { keys: "?", action: "Show this dialog" },
  { keys: "Esc", action: "Close dialogs" },
];

function readTheme(): "light" | "dark" {
  if (typeof window === "undefined") return "light";
  const saved = window.localStorage.getItem("sdlc.theme");
  if (saved === "light" || saved === "dark") return saved;
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

export function AppShell({ children }: { children: ReactNode }) {
  const { ready, signedIn, email, role, signOut } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    setTheme(readTheme());
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    if (typeof window !== "undefined") {
      window.localStorage.setItem("sdlc.theme", theme);
    }
  }, [theme]);

  useEffect(() => {
    if (ready && !signedIn) router.replace("/login");
  }, [ready, signedIn, router]);

  // Global keyboard shortcuts (vim-ish "g p" / "g a" + "c" + "?")
  useEffect(() => {
    let pendingG = false;
    let pendingTimer: ReturnType<typeof setTimeout> | null = null;
    function isTyping(e: KeyboardEvent): boolean {
      const t = e.target as HTMLElement | null;
      if (!t) return false;
      const tag = t.tagName;
      return (
        tag === "INPUT" ||
        tag === "TEXTAREA" ||
        tag === "SELECT" ||
        t.isContentEditable
      );
    }
    function handler(e: KeyboardEvent) {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (isTyping(e)) return;
      if (e.key === "?" || (e.shiftKey && e.key === "/")) {
        setShortcutsOpen(true);
        return;
      }
      if (e.key === "g") {
        pendingG = true;
        if (pendingTimer) clearTimeout(pendingTimer);
        pendingTimer = setTimeout(() => (pendingG = false), 800);
        return;
      }
      if (pendingG) {
        if (e.key === "p") router.push("/projects");
        if (e.key === "a") router.push("/audit");
        pendingG = false;
        return;
      }
      if (e.key === "c" && pathname === "/projects") {
        // Dispatch a custom event the Projects page listens for.
        window.dispatchEvent(new CustomEvent("sdlc:new-project"));
      }
    }
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [router, pathname]);

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Spinner />
      </div>
    );
  }
  if (!signedIn) return null;

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 dark:text-slate-100">
      <Sidebar pathname={pathname} className="hidden md:flex" />

      {/* Mobile drawer */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 md:hidden"
          onClick={() => setMobileOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="h-full w-60 bg-white shadow-xl dark:bg-slate-900"
          >
            <Sidebar
              pathname={pathname}
              onNavigate={() => setMobileOpen(false)}
              className="flex h-full"
            />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 dark:border-slate-800 dark:bg-slate-900 md:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="-ml-1 grid h-8 w-8 place-items-center rounded-md text-slate-500 hover:bg-slate-100 md:hidden dark:hover:bg-slate-800"
              aria-label="Open menu"
            >
              <MenuIcon className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm">
              {breadcrumb(pathname).map((part, i, arr) => (
                <span key={i} className="flex items-center gap-2">
                  {i > 0 && <span className="text-slate-300">/</span>}
                  <span
                    className={
                      i === arr.length - 1
                        ? "font-medium text-slate-900 dark:text-slate-100"
                        : "text-slate-500"
                    }
                  >
                    {part}
                  </span>
                </span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}
              className="grid h-8 w-8 place-items-center rounded-md text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              title={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
              aria-label="Toggle theme"
            >
              {theme === "light" ? (
                <MoonIcon className="h-4 w-4" />
              ) : (
                <SunIcon className="h-4 w-4" />
              )}
            </button>
            <button
              onClick={() => setShortcutsOpen(true)}
              className="hidden h-8 items-center gap-1 rounded-md px-2 text-xs text-slate-500 hover:bg-slate-100 sm:inline-flex dark:hover:bg-slate-800"
              title="Keyboard shortcuts"
            >
              <kbd className="rounded border border-slate-300 px-1 font-mono text-[10px] text-slate-500 dark:border-slate-700">
                ?
              </kbd>
            </button>
            <div className="flex items-center gap-2">
              <span className="hidden text-sm text-slate-700 sm:inline dark:text-slate-300">
                {email}
              </span>
              {role && (
                <Badge tone={role === "Admin" ? "amber" : "brand"}>
                  {role}
                </Badge>
              )}
            </div>
            <Button variant="secondary" size="sm" onClick={signOut}>
              Sign out
            </Button>
          </div>
        </header>
        <main className="flex-1 overflow-auto">
          <div className="w-full px-4 py-6 sm:px-6 md:px-8 2xl:px-12">
            {children}
          </div>
        </main>
      </div>

      <Modal
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
        title="Keyboard shortcuts"
      >
        <ul className="space-y-2 text-sm">
          {SHORTCUTS.map((s) => (
            <li
              key={s.keys}
              className="flex items-center justify-between gap-3"
            >
              <span className="text-slate-600">{s.action}</span>
              <kbd className="rounded border border-slate-300 bg-slate-50 px-2 py-0.5 font-mono text-xs text-slate-700">
                {s.keys}
              </kbd>
            </li>
          ))}
        </ul>
      </Modal>
    </div>
  );
}

function Sidebar({
  pathname,
  className = "",
  onNavigate,
}: {
  pathname: string;
  className?: string;
  onNavigate?: () => void;
}) {
  return (
    <aside
      className={`w-60 shrink-0 flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 ${className}`}
    >
      <div className="flex h-14 shrink-0 items-center gap-2 border-b border-slate-200 px-4 dark:border-slate-800">
        <div className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-brand-600 text-[11px] font-bold text-white">
          AI
        </div>
        <div className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
          SDLC Assistant
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 p-2">
        {NAV.map((item) => {
          const active =
            pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={`flex items-center gap-2 rounded-md px-2.5 py-1.5 text-sm transition-colors ${
                active
                  ? "bg-brand-50 text-brand-700 dark:bg-brand-900/30 dark:text-brand-200"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
              }`}
            >
              <Icon
                className={`h-4 w-4 shrink-0 ${active ? "text-brand-600" : "text-slate-400"}`}
              />
              <span className="truncate">{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-slate-200 px-3 py-2 text-[11px] text-slate-500 dark:border-slate-800">
        Integration 360 / CE · AMI 2.0
      </div>
    </aside>
  );
}

function breadcrumb(pathname: string): string[] {
  if (pathname === "/projects") return ["Projects"];
  if (pathname.startsWith("/projects/")) return ["Projects", "Workspace"];
  if (pathname.startsWith("/audit")) return ["Audit"];
  return [""];
}

function FolderIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M2.5 5.5A1.5 1.5 0 0 1 4 4h3.5l1.5 1.5H16A1.5 1.5 0 0 1 17.5 7v7A1.5 1.5 0 0 1 16 15.5H4A1.5 1.5 0 0 1 2.5 14v-8.5Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
    </svg>
  );
}

function AuditIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M6 3.5h7l3 3v10A1.5 1.5 0 0 1 14.5 18h-9A1.5 1.5 0 0 1 4 16.5V5A1.5 1.5 0 0 1 5.5 3.5H6Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path
        d="M7 9h6M7 12h6M7 15h4"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

function MenuIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M3 6h14M3 10h14M3 14h14"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function SunIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <circle cx="10" cy="10" r="3.5" stroke="currentColor" strokeWidth="1.5" />
      <path
        d="M10 2v2m0 12v2M2 10h2m12 0h2M4.5 4.5l1.4 1.4m8.2 8.2 1.4 1.4M4.5 15.5l1.4-1.4m8.2-8.2 1.4-1.4"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

function MoonIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M16 12.3A6 6 0 0 1 7.7 4 7 7 0 1 0 16 12.3Z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}
