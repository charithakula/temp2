"""Tiny audit-log helper. Best-effort: a logging failure must never break a request."""
import json
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import CurrentUser
from app.models.entities import AuditLog


async def record(
    session: AsyncSession,
    *,
    user: CurrentUser,
    action: str,
    project_id: str | None = None,
    entity_type: str | None = None,
    entity_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    try:
        session.add(
            AuditLog(
                project_id=project_id,
                actor_oid=user.oid,
                actor_email=user.email,
                actor_role=user.roles[0] if user.roles else "",
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                metadata_json=json.dumps(metadata or {}),
            )
        )
        await session.commit()
    except Exception:
        # Never let audit logging break the user's action.
        await session.rollback()
