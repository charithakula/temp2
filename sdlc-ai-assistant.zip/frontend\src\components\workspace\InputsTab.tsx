"use client";

import { useEffect, useState } from "react";
import { useToast } from "@/components/toast";
import { Badge, Button, Card, Spinner } from "@/components/ui";
import { api, type DocumentSummary } from "@/lib/api";
import { hasRole, useAuth } from "@/lib/auth";

type Progress = {
  filename: string;
  size: number;
  status: "pending" | "uploading" | "done" | "error";
  message?: string;
  pii_total?: number;
  chunks?: number;
};

export function InputsTab({ projectId }: { projectId: string }) {
  const { role } = useAuth();
  const toast = useToast();
  const [docs, setDocs] = useState<DocumentSummary[] | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [busy, setBusy] = useState(false);

  const canUpload = hasRole(role, "Author");

  async function refresh() {
    try {
      setDocs(await api.listDocuments(projectId));
    } catch (e) {
      toast.push(`Failed to load documents: ${(e as Error).message}`, "error");
      setDocs([]);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  async function uploadFiles(files: FileList | File[]) {
    if (!canUpload) {
      toast.push("Author role required to upload", "error");
      return;
    }
    const list: Progress[] = Array.from(files).map((f) => ({
      filename: f.name,
      size: f.size,
      status: "pending",
    }));
    setProgress(list);
    setBusy(true);

    let totalPII = 0;
    let totalChunks = 0;
    for (let i = 0; i < list.length; i++) {
      const file = Array.from(files)[i];
      setProgress((cur) =>
        cur.map((p, idx) => (idx === i ? { ...p, status: "uploading" } : p)),
      );
      try {
        const r = await api.uploadDocument(projectId, file);
        totalChunks += r.chunks_indexed;
        const pii = (r as { pii?: { total: number } }).pii?.total ?? 0;
        totalPII += pii;
        setProgress((cur) =>
          cur.map((p, idx) =>
            idx === i
              ? {
                  ...p,
                  status: "done",
                  pii_total: pii,
                  chunks: r.chunks_indexed,
                }
              : p,
          ),
        );
      } catch (e) {
        setProgress((cur) =>
          cur.map((p, idx) =>
            idx === i
              ? { ...p, status: "error", message: (e as Error).message }
              : p,
          ),
        );
      }
    }
    setBusy(false);
    toast.push(
      `Uploaded ${list.length} file(s) · ${totalChunks} chunks indexed${
        totalPII ? ` · ⚠ ${totalPII} possible PII match(es)` : ""
      }`,
      totalPII ? "info" : "success",
    );
    await refresh();
    setTimeout(() => setProgress([]), 4000);
  }

  async function deleteDoc(d: DocumentSummary) {
    if (!confirm(`Delete "${d.filename}"? This also removes its embeddings.`))
      return;
    try {
      await api.deleteDocument(projectId, d.id);
      toast.push("Document deleted", "success");
      await refresh();
    } catch (e) {
      toast.push((e as Error).message, "error");
    }
  }

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
      <Card
        className={`relative overflow-hidden p-6 transition-colors ${
          dragOver ? "border-brand-500 bg-brand-50/40 dark:bg-brand-900/20" : ""
        }`}
      >
        <div
          onDragOver={(e) => {
            e.preventDefault();
            if (canUpload) setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
          }}
          className="flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-slate-200 bg-slate-50/40 px-4 py-10 text-center dark:border-slate-700 dark:bg-slate-950/40"
        >
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">
            <UploadIcon className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Drop BRD, FDS, or user stories
            </div>
            <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              PDF, DOCX, MD, TXT · max 25 MB each
            </div>
          </div>
          <label className="mt-2 inline-flex">
            <input
              type="file"
              multiple
              hidden
              accept=".pdf,.docx,.md,.txt"
              disabled={!canUpload || busy}
              onChange={(e) => {
                if (e.target.files?.length) uploadFiles(e.target.files);
                e.target.value = "";
              }}
            />
            <span
              className={`inline-flex h-9 cursor-pointer items-center gap-2 rounded-md px-4 text-sm font-medium ${
                !canUpload || busy
                  ? "bg-brand-600/50 text-white"
                  : "bg-brand-600 text-white shadow-sm hover:bg-brand-700"
              }`}
            >
              {busy ? <Spinner /> : null}
              {busy ? "Uploading…" : "Choose files"}
            </span>
          </label>
          {!canUpload && (
            <div className="text-xs text-amber-700">
              Sign in as Author or Admin to upload.
            </div>
          )}
        </div>

        {progress.length > 0 && (
          <div className="mt-4 space-y-1.5">
            {progress.map((p, i) => (
              <div
                key={i}
                className="flex items-center justify-between rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex min-w-0 items-center gap-2">
                  <FileIcon className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                  <span className="truncate text-slate-800 dark:text-slate-200">
                    {p.filename}
                  </span>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {p.status === "uploading" && <Spinner />}
                  {p.status === "done" && (
                    <>
                      {p.pii_total ? (
                        <Badge tone="amber">⚠ {p.pii_total} PII</Badge>
                      ) : null}
                      <Badge tone="green">{p.chunks ?? 0} chunks</Badge>
                    </>
                  )}
                  {p.status === "error" && (
                    <Badge tone="red">{p.message?.slice(0, 30) || "error"}</Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[
            { k: "1", v: "Extract" },
            { k: "2", v: "Chunk" },
            { k: "3", v: "Embed → pgvector" },
          ].map((s) => (
            <div
              key={s.k}
              className="rounded-md border border-slate-200 bg-white px-2 py-2 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400"
            >
              <div className="font-mono text-[10px] text-brand-600 dark:text-brand-300">
                Step {s.k}
              </div>
              <div>{s.v}</div>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 dark:border-slate-800">
          <div>
            <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Indexed documents
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              {docs?.length ?? 0} file{docs?.length === 1 ? "" : "s"} · ready
              for SCS generation
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={refresh}>
            Refresh
          </Button>
        </div>
        {docs === null ? (
          <div className="flex justify-center p-8">
            <Spinner />
          </div>
        ) : docs.length === 0 ? (
          <div className="px-5 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
            No documents uploaded yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="text-[11px] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  <th className="px-5 py-2 font-medium">File</th>
                  <th className="px-5 py-2 font-medium">Size</th>
                  <th className="px-5 py-2 font-medium">Extracted</th>
                  <th className="px-5 py-2 font-medium">Uploaded</th>
                  <th className="px-5 py-2 font-medium" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {docs.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-5 py-2.5">
                      <div className="flex items-center gap-2">
                        <FileIcon className="h-4 w-4 text-slate-400" />
                        <span className="font-medium text-slate-900 dark:text-slate-100">
                          {d.filename}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-2.5 text-slate-600 dark:text-slate-400">
                      {fmtBytes(d.size_bytes)}
                    </td>
                    <td className="px-5 py-2.5 text-slate-600 dark:text-slate-400">
                      {d.extracted_chars.toLocaleString()} chars
                    </td>
                    <td className="px-5 py-2.5 text-slate-500 dark:text-slate-400">
                      {new Date(d.created_at).toLocaleString()}
                    </td>
                    <td className="px-5 py-2.5 text-right">
                      {canUpload && (
                        <button
                          onClick={() => deleteDoc(d)}
                          className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                        >
                          Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function UploadIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M10 13V4m0 0-3.5 3.5M10 4l3.5 3.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.5 13v2A1.5 1.5 0 0 0 5 16.5h10a1.5 1.5 0 0 0 1.5-1.5v-2"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function FileIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M5 3.5h7l3 3v10A1.5 1.5 0 0 1 13.5 18h-9A1.5 1.5 0 0 1 3 16.5V5A1.5 1.5 0 0 1 4.5 3.5H5Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path
        d="M12 3.5V6.5A1 1 0 0 0 13 7.5h2"
        stroke="currentColor"
        strokeWidth="1.4"
      />
    </svg>
  );
}
