from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireAdmin, RequireAuthor, RequireViewer
from app.core.db import get_session
from app.models.entities import Project
from app.schemas.projects import ProjectCreate, ProjectOut, ProjectPatch
from app.services.audit import record as audit

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=ProjectOut, status_code=201)
async def create_project(
    payload: ProjectCreate,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> ProjectOut:
    project = Project(name=payload.name, description=payload.description, created_by=user.oid)
    session.add(project)
    await session.commit()
    await session.refresh(project)
    await audit(
        session,
        user=user,
        action="project.create",
        project_id=project.id,
        entity_type="project",
        entity_id=project.id,
        metadata={"name": project.name},
    )
    return ProjectOut.model_validate(project, from_attributes=True)


@router.get("", response_model=list[ProjectOut])
async def list_projects(
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> list[ProjectOut]:
    rows = (await session.execute(select(Project))).scalars().all()
    return [ProjectOut.model_validate(p, from_attributes=True) for p in rows]


@router.get("/{project_id}", response_model=ProjectOut)
async def get_project(
    project_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> ProjectOut:
    project = await session.get(Project, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectOut.model_validate(project, from_attributes=True)


@router.patch("/{project_id}", response_model=ProjectOut)
async def patch_project(
    project_id: str,
    payload: ProjectPatch,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> ProjectOut:
    project = await session.get(Project, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    changes: dict[str, str | None] = {}
    if payload.name is not None and payload.name != project.name:
        changes["name"] = payload.name
        project.name = payload.name
    if payload.description is not None and payload.description != project.description:
        changes["description"] = "updated"
        project.description = payload.description
    if payload.status is not None and payload.status != project.status:
        changes["status"] = payload.status
        project.status = payload.status
    if not changes:
        return ProjectOut.model_validate(project, from_attributes=True)
    await session.commit()
    await session.refresh(project)
    await audit(
        session,
        user=user,
        action="project.update",
        project_id=project_id,
        entity_type="project",
        entity_id=project_id,
        metadata=changes,
    )
    return ProjectOut.model_validate(project, from_attributes=True)


@router.delete("/{project_id}", status_code=204)
async def delete_project(
    project_id: str,
    user=RequireAdmin,
    session: AsyncSession = Depends(get_session),
) -> None:
    project = await session.get(Project, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    name = project.name
    await session.delete(project)
    await session.commit()
    await audit(
        session,
        user=user,
        action="project.delete",
        project_id=project_id,
        entity_type="project",
        entity_id=project_id,
        metadata={"name": name},
    )
