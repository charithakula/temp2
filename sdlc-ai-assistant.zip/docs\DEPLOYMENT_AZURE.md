# Deployment — Azure Web Apps

Both the Next.js frontend and the FastAPI backend deploy as **Azure Web Apps (Linux)**, behind GitHub Actions CI/CD. Secrets live in Azure Key Vault and are referenced by the Web Apps via Managed Identity.

---

## 1. Azure resources (per environment: `dev`, `prod`)

| Resource | Name (suggested) | Notes |
|---|---|---|
| Resource Group | `rg-sdlc-ai-{env}` | Region: `eastus2` (or org default) |
| App Service Plan | `asp-sdlc-ai-{env}` | Linux, **P1v3** (prod) / **B2** (dev) |
| Web App — frontend | `app-sdlc-ai-fe-{env}` | Node 20 runtime |
| Web App — backend | `app-sdlc-ai-be-{env}` | Python 3.11 runtime |
| Storage Account | `stsdlcai{env}` | Blob containers: `uploads`, `exports` |
| Azure OpenAI | `oai-sdlc-ai-{env}` | Deployments: `gpt-4o`, `gpt-4o-mini`, `text-embedding-3-small` |
| Postgres Flexible Server | `psql-sdlc-ai-{env}` / db `sdlc_ai` | Server param `azure.extensions=VECTOR`; run `CREATE EXTENSION vector` once on the DB |
| Key Vault | `kv-sdlc-ai-{env}` | RBAC; access via Managed Identity |
| App Insights | `appi-sdlc-ai-{env}` | Workspace-based |
| Log Analytics | `log-sdlc-ai-{env}` | |
| Front Door (optional) | `afd-sdlc-ai-{env}` | WAF + custom domain |

## 2. Required secrets (in Key Vault)

| Secret | Used by |
|---|---|
| `AZURE-OPENAI-ENDPOINT` | backend |
| `AZURE-OPENAI-API-KEY` | backend |
| `DATABASE-URL` | backend (Postgres `postgresql+asyncpg://...?ssl=require`) |
| `STORAGE-CONNECTION-STRING` | backend |
| `ENTRA-TENANT-ID` | both |
| `ENTRA-API-CLIENT-ID` | backend |
| `ENTRA-WEB-CLIENT-ID` | frontend |
| `SHAREPOINT-CLIENT-SECRET` | backend (Phase 1.5) |

Each Web App gets:
- A **system-assigned managed identity**
- `Key Vault Secrets User` role on the Key Vault
- App Settings that reference secrets via `@Microsoft.KeyVault(...)` syntax

## 3. App settings

### Backend Web App
```
WEBSITES_PORT=8000
SCM_DO_BUILD_DURING_DEPLOYMENT=true

AZURE_OPENAI_ENDPOINT=@Microsoft.KeyVault(SecretUri=...)
AZURE_OPENAI_API_KEY=@Microsoft.KeyVault(SecretUri=...)
AZURE_OPENAI_API_VERSION=2024-10-21
AZURE_OPENAI_SCS_DEPLOYMENT=gpt-4o
AZURE_OPENAI_OPENAPI_DEPLOYMENT=gpt-4o-mini
AZURE_OPENAI_CHAT_DEPLOYMENT=gpt-4o-mini
AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT=text-embedding-3-small
EMBEDDINGS_DIM=1536

DATABASE_URL=@Microsoft.KeyVault(SecretUri=...)   # postgresql+asyncpg://...?ssl=require
STORAGE_CONNECTION_STRING=@Microsoft.KeyVault(SecretUri=...)

ENTRA_TENANT_ID=@Microsoft.KeyVault(SecretUri=...)
ENTRA_API_CLIENT_ID=@Microsoft.KeyVault(SecretUri=...)

APPLICATIONINSIGHTS_CONNECTION_STRING=<from-appi>
CORS_ALLOWED_ORIGINS=https://app-sdlc-ai-fe-{env}.azurewebsites.net
```

Startup command:
```
gunicorn -w 2 -k uvicorn.workers.UvicornWorker app.main:app --bind=0.0.0.0:8000 --timeout 120
```

### Frontend Web App
```
WEBSITES_PORT=3000
NEXT_PUBLIC_API_BASE_URL=https://app-sdlc-ai-be-{env}.azurewebsites.net/api/v1
NEXT_PUBLIC_ENTRA_TENANT_ID=@Microsoft.KeyVault(SecretUri=...)
NEXT_PUBLIC_ENTRA_CLIENT_ID=@Microsoft.KeyVault(SecretUri=...)
APPLICATIONINSIGHTS_CONNECTION_STRING=<from-appi>
```

Startup command:
```
npm run start
```

## 4. CI/CD (GitHub Actions)

Two workflows live in `.github/workflows/`:

- `backend-deploy.yml` — on push to `main` affecting `backend/**`: lint, test, build, deploy to backend Web App via OIDC federated credentials.
- `frontend-deploy.yml` — on push to `main` affecting `frontend/**`: lint, build (`npm run build`), deploy `.next/standalone` output to frontend Web App.

**Auth:** GitHub → Azure via OIDC federated identity (no long-lived secrets).

## 5. Networking & security

- HTTPS only on both Web Apps (`httpsOnly=true`).
- Min TLS 1.2.
- Backend allows CORS only from the frontend origin.
- Optional: VNet integration if backend must reach private SharePoint / SQL endpoints.
- Storage account: disable public blob access; use SAS URLs scoped per request.

## 6. Cost guardrails

- Per-project token cap (configurable; see `NFR-8` in REQUIREMENTS.md).
- Default model routing: `gpt-4o` for SCS only; `gpt-4o-mini` for chat + OpenAPI generation; `text-embedding-3-small` for the RAG index.
- RAG (pgvector) sends only the top-K relevant chunks per generation rather than the full corpus, keeping input tokens flat as projects grow.
- Auto-scale rules on the App Service Plan tied to CPU > 70% for 10 min.

## 6a. Postgres + pgvector setup

Once the Flexible Server is provisioned:

1. Add `VECTOR` to the `azure.extensions` server parameter (Azure portal → server → Server parameters).
2. Connect to the database and run once:
   ```sql
   CREATE EXTENSION IF NOT EXISTS vector;
   ```
   (The backend also runs this in `init_db()` on startup as a safety net.)
3. Optional, once you have a meaningful number of chunks:
   ```sql
   CREATE INDEX ON document_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
   ANALYZE document_chunks;
   ```
4. Connection string format for the backend (`DATABASE_URL`):
   ```
   postgresql+asyncpg://<user>:<pwd>@psql-sdlc-ai-{env}.postgres.database.azure.com:5432/sdlc_ai?ssl=require
   ```

## 7. Bicep (to be added under `infra/azure/`)

- `main.bicep` — orchestrates all resources for one environment
- `modules/webapp.bicep`, `modules/storage.bicep`, `modules/sql.bicep`, `modules/keyvault.bicep`
- Parameters file per env: `main.dev.bicepparam`, `main.prod.bicepparam`
