# Requirements — SDLC AI Assistant

**Source:** New AI Use Cases discussion (Omprakash Dornala, 2026-04-10)
**Owner:** Charith Akula
**Status:** Draft v0.1 — pending stakeholder review (Pavan)

---

## 1. Objective

Introduce AI-driven SDLC automation into the **Integration 360 / CE platform** to reduce manual effort in:

- Requirement analysis
- Technical design (SCS/TDS) authoring
- API specification (OpenAPI/YAML) creation

Deliver a **dedicated AI-powered web app / SDLC chatbot** that operates alongside Integration 360, with the option to integrate deeper later.

## 2. In-scope use cases (MVP)

### UC-1 — Technical Design / SCS Document Generation

| | |
|---|---|
| **Inputs** | BRD, FDS, user stories, vendor documentation, knowledge-base articles (uploaded or pulled from SharePoint) |
| **AI capability** | Generate a Solution/System Component Specification (SCS/TDS) document |
| **Document covers** | Required APIs · Request/response flows · Architecture components · Integration & sequence details |
| **Quality target** | ~80% ready output; human-in-the-loop review and refinement required before approval |
| **Output formats** | Markdown (canonical), exportable to DOCX and PDF |

### UC-2 — OpenAPI Specification Generation

| | |
|---|---|
| **Input** | An **approved** SCS/TDS document from UC-1 |
| **AI capability** | Generate OpenAPI 3.1 (YAML) specification aligned to the SCS |
| **Spec covers** | API schemas · Request/response structures · Standardized error models |
| **Output formats** | YAML (canonical), JSON export, downloadable bundle |

## 3. Out-of-scope (MVP)

- Code generation from OpenAPI (server stubs / SDKs)
- Direct deployment to Integration 360 runtime
- Native integrations with Octane, Helix, Jira (planned for later phases)
- Multi-tenant / external-customer access (internal-only at MVP)

## 4. User personas

| Persona | Needs |
|---|---|
| **Solution Architect** | Generate first-draft SCS quickly; refine with domain context; export to DOCX for stakeholder review |
| **API Designer** | Convert approved SCS to consistent OpenAPI YAML; validate schemas |
| **BA / Product Owner** | Upload BRDs and user stories; track which artifacts produced which designs |
| **Reviewer / Lead** | Compare AI draft vs. final approved version; approve or request edits |

## 5. Functional requirements

### FR-1 — Document ingestion
- FR-1.1 Upload `.pdf`, `.docx`, `.md`, `.txt` (≤ 25 MB each, ≤ 10 files per session)
- FR-1.2 Pull documents from a configured SharePoint site/library (Phase 1.5)
- FR-1.3 Extract text + preserve heading structure for grounding
- FR-1.4 Store original files in Azure Blob Storage with tenant/project scoping

### FR-2 — Project / session management
- FR-2.1 Create a "project" that groups inputs, generated SCS, and generated OpenAPI
- FR-2.2 List, rename, archive projects
- FR-2.3 Persist all generated artifacts with version history

### FR-3 — SCS generation (UC-1)
- FR-3.1 Trigger generation from a project's input documents
- FR-3.2 Stream generation progress to the UI (token streaming)
- FR-3.3 Allow the user to provide additional **steering instructions** (free-text prompt) before generation
- FR-3.4 Render the SCS in a Markdown editor with side-by-side preview
- FR-3.5 Save edits as a new version; mark a version as "Approved"
- FR-3.6 Export SCS as DOCX and PDF

### FR-4 — OpenAPI generation (UC-2)
- FR-4.1 Available only after an SCS version is marked "Approved"
- FR-4.2 Generate OpenAPI 3.1 YAML aligned to the approved SCS
- FR-4.3 Validate output against the OpenAPI schema; surface errors
- FR-4.4 YAML editor with live validation; download as `.yaml` / `.json`

### FR-5 — Conversational interface
- FR-5.1 Chat panel scoped to the current project (the LLM has access to the project's documents and current SCS)
- FR-5.2 Ask for summaries, clarifications, "explain this section", "rewrite section X"
- FR-5.3 Cite which source document(s) a claim came from where possible

### FR-6 — Authentication & authorization
- FR-6.1 SSO via **Microsoft Entra ID** (Azure AD)
- FR-6.2 Role-based access: `Viewer`, `Author`, `Admin`
- FR-6.3 Project-level access lists

### FR-7 — Observability
- FR-7.1 Audit log of who generated/approved/exported what, and when
- FR-7.2 Token-usage and cost telemetry per project

## 6. Non-functional requirements

| ID | Requirement |
|---|---|
| NFR-1 | **Performance** — SCS first-token latency < 5 s; full SCS for a typical BRD (≤ 30 pages) generated in < 90 s |
| NFR-2 | **Scalability** — Support 50 concurrent generation sessions on Azure Web App P1v3 baseline |
| NFR-3 | **Availability** — 99.5% during business hours (internal tool) |
| NFR-4 | **Security** — All traffic over HTTPS; data at rest encrypted (Azure-managed keys); no document content sent to non-approved LLM providers |
| NFR-5 | **Privacy** — Internal data only; LLM calls must not be used for provider-side training (enable Anthropic "no training" terms) |
| NFR-6 | **Auditability** — All generations and approvals logged for ≥ 1 year |
| NFR-7 | **Browser support** — Latest 2 versions of Chrome, Edge, Firefox |
| NFR-8 | **Cost guardrail** — Per-project token cap, configurable; default 1M input / 200K output tokens before warning |

## 7. Workflow (happy path)

```
1. User signs in (Entra ID) and creates a Project.
2. User uploads BRD / FDS / user stories  (or  pulls from SharePoint).
3. User optionally adds steering notes ("focus on payments flow", etc.).
4. AI generates SCS  →  streamed into editor.
5. User edits and clicks "Approve version".
6. AI generates OpenAPI YAML aligned to the approved SCS.
7. User reviews, downloads, or exports.
```

## 8. Key decisions & constraints (from discussion)

- Focus on a **practical, low-effort first release**.
- Avoid overly generic outputs — accuracy improves with richer input data, so ingestion quality matters.
- **Budget is not a blocker** (covered under AMI 2.0).
- Tooling is already proven in other Infosys platforms — **goal is to adapt** that approach into CE / Integration 360, not invent from scratch.
- Start small and simple; expand integrations (Octane, Helix, Jira) in later phases.

## 9. Open questions

- [x] **LLM provider:** Azure OpenAI Service (`gpt-4o` for SCS, `gpt-4o-mini` for OpenAPI + chat, `text-embedding-3-small` for embeddings). Decided 2026-04-29.
- [x] **Database:** Azure Database for PostgreSQL Flexible Server with the `vector` (pgvector) extension. Decided 2026-04-29.
- [ ] SharePoint connector: app-only auth via Graph API, or delegated on behalf of the signed-in user?
- [ ] Are there existing SCS / OpenAPI **templates or style guides** we must conform to?
- [ ] Retention policy for uploaded documents and generated artifacts?
- [ ] Postgres SKU sizing — Burstable B2s for dev / GP_Standard_D2s_v3 for prod, or larger?

## 10. Acceptance criteria (MVP)

1. A user can sign in, create a project, upload a BRD, and receive a generated SCS within 90 seconds.
2. The user can edit the SCS, approve a version, and generate a syntactically valid OpenAPI 3.1 YAML.
3. Generated OpenAPI passes `openapi-spec-validator` with zero errors on at least 5 reference BRDs.
4. All generations and approvals appear in the audit log.
5. The application is deployed to Azure Web Apps with CI/CD from GitHub.
