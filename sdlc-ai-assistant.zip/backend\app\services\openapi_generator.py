import json
from collections.abc import AsyncIterator
from hashlib import sha256
from pathlib import Path

import yaml
from openapi_spec_validator import validate
from openapi_spec_validator.validation.exceptions import OpenAPIValidationError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entities import AuditLog, OpenAPIVersion, SCSVersion
from app.services.llm_client import Usage, stream_completion
from app.services.sse import sse
from app.services.token_cap import check_cap

_PROMPTS = Path(__file__).resolve().parent.parent / "prompts"


def _load(name: str) -> str:
    return (_PROMPTS / name).read_text(encoding="utf-8")


def _hash(text: str) -> str:
    return sha256(text.encode()).hexdigest()


def _validate_yaml(text: str) -> list[str]:
    try:
        spec = yaml.safe_load(text)
        validate(spec)
        return []
    except (yaml.YAMLError, OpenAPIValidationError) as exc:
        return [str(exc)]


async def stream_openapi(
    *,
    session: AsyncSession,
    project_id: str,
    scs_version_id: str,
    actor_oid: str,
    deployment: str | None,
) -> AsyncIterator[bytes]:
    scs = (
        await session.execute(
            select(SCSVersion).where(
                SCSVersion.id == scs_version_id,
                SCSVersion.project_id == project_id,
            )
        )
    ).scalar_one_or_none()

    if scs is None:
        yield sse("error", {"message": "SCS version not found"})
        return
    if scs.status != "approved":
        yield sse("error", {"message": "SCS version must be approved before OpenAPI generation"})
        return

    try:
        await check_cap(session, project_id)
    except Exception as exc:
        yield sse("error", {"message": str(exc.detail) if hasattr(exc, "detail") else str(exc)})
        return

    system = _load("openapi_system.md")
    user_message = _load("openapi_user.md")
    chosen_deployment = deployment or settings.openapi_deployment
    prompt_hash = _hash(system + scs.markdown + user_message)

    usage = Usage()
    buf: list[str] = []
    try:
        async for delta in stream_completion(
            deployment=chosen_deployment,
            system=system,
            cached_corpus=scs.markdown,
            user_message=user_message,
            usage_out=usage,
        ):
            buf.append(delta)
            yield sse("token", {"delta": delta})
    except Exception as exc:
        yield sse("error", {"message": f"Generation failed: {exc}"})
        return

    yaml_text = "".join(buf)
    errors = _validate_yaml(yaml_text)

    existing = await session.execute(
        select(OpenAPIVersion).where(OpenAPIVersion.project_id == project_id)
    )
    version_no = len(existing.scalars().all()) + 1

    version = OpenAPIVersion(
        project_id=project_id,
        scs_version_id=scs_version_id,
        version_no=version_no,
        yaml=yaml_text,
        validation_errors=json.dumps(errors),
        prompt_hash=prompt_hash,
        model=chosen_deployment,
        tokens_in=usage.prompt_tokens,
        tokens_out=usage.completion_tokens,
        created_by=actor_oid,
    )
    session.add(version)
    await session.commit()
    await session.refresh(version)

    session.add(
        AuditLog(
            project_id=project_id,
            actor_oid=actor_oid,
            actor_email="",
            actor_role="",
            action="openapi.generate",
            entity_type="openapi_version",
            entity_id=version.id,
            metadata_json=json.dumps(
                {
                    "version_no": version.version_no,
                    "scs_version_id": scs_version_id,
                    "model": chosen_deployment,
                    "validation_errors": len(errors),
                    "tokens_in": usage.prompt_tokens,
                    "tokens_out": usage.completion_tokens,
                }
            ),
        )
    )
    await session.commit()

    yield sse(
        "done",
        {"version_id": version.id, "version_no": version.version_no, "validation_errors": errors},
    )
