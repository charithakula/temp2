"use client";

import { useEffect, useState } from "react";
import { useToast } from "@/components/toast";
import { Badge, Card, Spinner } from "@/components/ui";
import { api, type AuditEntry } from "@/lib/api";

const ACTION_TONES: Record<string, "brand" | "amber" | "green" | "red" | "slate"> = {
  "project.create": "green",
  "project.delete": "red",
  "document.upload": "brand",
  "scs.generate": "brand",
  "scs.update": "slate",
  "scs.approve": "amber",
  "openapi.generate": "brand",
};

export function AuditList({ projectId }: { projectId?: string }) {
  const toast = useToast();
  const [rows, setRows] = useState<AuditEntry[] | null>(null);

  useEffect(() => {
    (projectId ? api.listProjectAudit(projectId) : api.listAudit())
      .then(setRows)
      .catch((e) => {
        toast.push(`Failed to load audit log: ${(e as Error).message}`, "error");
        setRows([]);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  if (rows === null) {
    return (
      <div className="flex justify-center p-10">
        <Spinner />
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <Card className="p-10 text-center text-sm text-slate-500 dark:text-slate-400">
        No audit events yet.
      </Card>
    );
  }

  return (
    <Card>
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase text-slate-500 dark:bg-slate-900/50 dark:text-slate-400">
          <tr>
            <th className="px-5 py-2">When</th>
            <th className="px-5 py-2">Actor</th>
            <th className="px-5 py-2">Role</th>
            <th className="px-5 py-2">Action</th>
            <th className="px-5 py-2">Details</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((r) => {
            let meta: Record<string, unknown> = {};
            try {
              meta = JSON.parse(r.metadata_json);
            } catch {
              /* ignore */
            }
            return (
              <tr key={r.id} className="align-top hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <td className="whitespace-nowrap px-5 py-2 text-slate-500 dark:text-slate-400">
                  {new Date(r.created_at).toLocaleString()}
                </td>
                <td className="px-5 py-2 text-slate-800 dark:text-slate-200">
                  {r.actor_email || r.actor_oid}
                </td>
                <td className="px-5 py-2">
                  {r.actor_role && <Badge tone="slate">{r.actor_role}</Badge>}
                </td>
                <td className="px-5 py-2">
                  <Badge tone={ACTION_TONES[r.action] ?? "slate"}>
                    {r.action}
                  </Badge>
                </td>
                <td className="px-5 py-2 text-xs text-slate-600 dark:text-slate-400">
                  {Object.keys(meta).length === 0 ? (
                    "—"
                  ) : (
                    <ul className="space-y-0.5">
                      {Object.entries(meta).map(([k, v]) => (
                        <li key={k}>
                          <span className="text-slate-400 dark:text-slate-500">
                            {k}:
                          </span>{" "}
                          <span>{String(v)}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </Card>
  );
}
