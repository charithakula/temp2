# API Contract — SDLC AI Assistant Backend

Base URL (local): `http://localhost:8000/api/v1`
Auth: `Authorization: Bearer <Entra ID access token>` on all routes except `/health`.

---

## Health

```
GET /health        → 200 { "status": "ok", "version": "x.y.z" }
```

## Projects

```
POST   /projects
  body: { "name": string, "description"?: string }
  → 201 { "id": uuid, "name", "created_at", ... }

GET    /projects                      → 200 [Project]
GET    /projects/{id}                 → 200 Project
PATCH  /projects/{id}                 → 200 Project   (rename, archive)
DELETE /projects/{id}                 → 204
```

## Documents

```
POST   /projects/{id}/documents
  multipart/form-data: file
  → 201 { "id", "filename", "size_bytes", "content_type", "created_at" }

GET    /projects/{id}/documents       → 200 [Document]
DELETE /projects/{id}/documents/{docId} → 204
```

## SCS generation (UC-1)

```
POST   /projects/{id}/scs/generate
  body: { "steering"?: string, "deployment"?: string }   # Azure OpenAI deployment name override
  → 200 (SSE stream)
       event: token   data: { "delta": "..." }
       event: done    data: { "version_id": uuid, "version_no": int }

GET    /projects/{id}/scs                       → 200 [SCSVersion summary]
GET    /projects/{id}/scs/{versionId}           → 200 SCSVersion (full markdown)
PUT    /projects/{id}/scs/{versionId}
  body: { "markdown": string }
  → 200 SCSVersion (creates a new draft version)
POST   /projects/{id}/scs/{versionId}/approve   → 200 SCSVersion (status=approved)
GET    /projects/{id}/scs/{versionId}/export?format=docx|pdf|md → 200 file
```

## OpenAPI generation (UC-2)

```
POST   /projects/{id}/openapi/generate
  body: { "scs_version_id": uuid, "deployment"?: string }   # Azure OpenAI deployment name override
  → 200 (SSE stream of YAML tokens)
       event: token   data: { "delta": "..." }
       event: done    data: { "version_id", "version_no", "validation_errors": [...] }

GET    /projects/{id}/openapi                   → 200 [OpenAPIVersion summary]
GET    /projects/{id}/openapi/{versionId}       → 200 OpenAPIVersion
PUT    /projects/{id}/openapi/{versionId}
  body: { "yaml": string }
  → 200 OpenAPIVersion (re-validated)
GET    /projects/{id}/openapi/{versionId}/export?format=yaml|json → 200 file
```

## Chat (project-scoped)

```
POST   /projects/{id}/chat
  body: { "message": string, "history"?: [{role, content}] }
  → 200 (SSE stream)
       event: token   data: { "delta": "..." }
       event: done    data: { "message_id" }

GET    /projects/{id}/chat                      → 200 [ChatMessage]
```

## Audit

```
GET    /projects/{id}/audit                     → 200 [AuditLog]
```

---

## Error format

```json
{
  "error": {
    "code": "VALIDATION_ERROR" | "NOT_FOUND" | "UNAUTHORIZED" | "FORBIDDEN" | "LLM_ERROR" | "INTERNAL",
    "message": "Human readable",
    "details": { ... }
  }
}
```
