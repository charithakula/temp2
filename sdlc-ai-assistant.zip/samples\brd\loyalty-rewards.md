# Business Requirements Document — Loyalty Rewards Engine

**Project:** Loyalty Rewards Integration for E-commerce
**Author:** Loyalty Programs Team
**Date:** 2026-04-02
**Version:** 0.9 (DRAFT)

## 1. Why

Today, points are awarded only after the order is fulfilled and a manual end-of-day batch
reconciles them with the loyalty vendor. Customers see their points 1–3 days late, and
support gets ~200 tickets/week asking "where are my points?". We want real-time accrual,
real-time redemption, and a single source of truth across the storefront, OMS, and the
loyalty vendor.

## 2. Outcomes

- Points visible in the customer's account within 5 seconds of order confirmation.
- Customers can redeem points at checkout to reduce the amount payable.
- A "tier" (Silver / Gold / Platinum) is computed from rolling 12-month spend and shown in
  the customer profile.
- Operations can correct points (manual credit/debit) with reason and audit trail.

## 3. Use Cases

### UC-A Earn Points on Purchase
On order confirmation (event `oms.order.status.v1` with status `paid`), compute earnable
points using the active rules engine. Call the loyalty vendor's `/accrue` endpoint.

### UC-B Redeem Points at Checkout
At checkout, the customer chooses how many points to redeem. The platform calls the
vendor's `/redeem-quote` endpoint to validate and lock points, then `/redeem-confirm` on
order placement, or `/redeem-release` on cancellation/timeout.

### UC-C View Points History
Show a paginated history of accrual + redemption events with timestamps, order IDs, and
reason codes. Filterable by date range.

### UC-D Tier Computation
Daily job evaluates each customer's rolling spend (last 365 days) and updates tier.
Tier-up triggers a congratulations email; tier-down is silent.

### UC-E Manual Adjustment
An operations user (role: `loyalty_admin`) can credit or debit points for a customer with
a mandatory reason and reference (e.g., support ticket ID). All adjustments are audited.

## 4. Rules (Initial)

- Earn rate: 1 point per ₹10 spent on eligible categories; 2× on the customer's birthday.
- Redemption: 100 points = ₹10 off, max 50% of order value.
- Points expire 24 months after issue.
- Refunds: reverse the points granted for the refunded amount.

## 5. Integrations

- Loyalty vendor (Capillary) — REST APIs: `/accrue`, `/redeem-quote`, `/redeem-confirm`,
  `/redeem-release`, `/balance`, `/history`. OAuth 2.0.
- OMS — consumed events: `oms.order.status.v1` (paid, cancelled, refunded).
- CE Storefront — calls platform APIs for balance, redeem-quote, history.
- CRM — receives tier-change events on topic `loyalty.tier.changed.v1`.

## 6. NFRs

- NFR-1 Earn-on-purchase end-to-end ≤ 5s P95.
- NFR-2 Idempotency on `/accrue` to handle event redelivery.
- NFR-3 No double-spend on `/redeem-confirm` even under retries.
- NFR-4 Manual adjustments require dual approval above 5,000 points.
- NFR-5 12-month history must remain queryable in <500 ms.

## 7. Out of Scope (MVP)

- Partner-funded points (third-party brand credits).
- Family / household points pooling.
- Gamified missions and badges.

## 8. Open Questions

- Should redemption be allowed against shipping or gift cards in MVP, or only on
  merchandise?
- Where should points expiry warnings be sent: email only, or also push?
- Tier criteria — spend-only, or also visit frequency?
