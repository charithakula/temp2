"use client";

import {
  AccountInfo,
  Configuration,
  PublicClientApplication,
} from "@azure/msal-browser";

const tenantId = process.env.NEXT_PUBLIC_ENTRA_TENANT_ID || "";
const clientId = process.env.NEXT_PUBLIC_ENTRA_CLIENT_ID || "";
const apiClientId =
  process.env.NEXT_PUBLIC_ENTRA_API_CLIENT_ID || ""; // backend app reg client id

export const msalConfigured = Boolean(tenantId && clientId);

let instance: PublicClientApplication | null = null;

function _config(): Configuration {
  return {
    auth: {
      clientId,
      authority: `https://login.microsoftonline.com/${tenantId}`,
      redirectUri:
        typeof window !== "undefined" ? window.location.origin + "/login" : "/",
      postLogoutRedirectUri:
        typeof window !== "undefined" ? window.location.origin + "/login" : "/",
    },
    cache: { cacheLocation: "sessionStorage" },
  };
}

export async function getMsal(): Promise<PublicClientApplication | null> {
  if (!msalConfigured) return null;
  if (!instance) {
    instance = new PublicClientApplication(_config());
    await instance.initialize();
  }
  return instance;
}

const SCOPES = apiClientId
  ? [`api://${apiClientId}/.default`]
  : ["openid", "profile", "email"];

export async function signInPopup(): Promise<AccountInfo | null> {
  const m = await getMsal();
  if (!m) return null;
  const r = await m.loginPopup({ scopes: SCOPES, prompt: "select_account" });
  return r.account ?? null;
}

export async function getAccessToken(): Promise<string | null> {
  const m = await getMsal();
  if (!m) return null;
  const account = m.getAllAccounts()[0];
  if (!account) return null;
  try {
    const r = await m.acquireTokenSilent({ account, scopes: SCOPES });
    return r.accessToken;
  } catch {
    const r = await m.acquireTokenPopup({ account, scopes: SCOPES });
    return r.accessToken;
  }
}

export async function signOutMsal(): Promise<void> {
  const m = await getMsal();
  if (!m) return;
  const account = m.getAllAccounts()[0];
  if (!account) return;
  await m.logoutPopup({ account });
}
