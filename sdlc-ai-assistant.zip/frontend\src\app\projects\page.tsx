"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { useToast } from "@/components/toast";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Modal,
  Spinner,
  inputClass,
} from "@/components/ui";
import { api, type Project } from "@/lib/api";
import { hasRole, useAuth } from "@/lib/auth";

export default function ProjectsPage() {
  return (
    <AppShell>
      <ProjectsView />
    </AppShell>
  );
}

function ProjectsView() {
  const { role, email } = useAuth();
  const toast = useToast();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [query, setQuery] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Project | null>(null);

  const canCreate = hasRole(role, "Author");
  const canDelete = hasRole(role, "Admin");

  async function refresh() {
    try {
      setProjects(await api.listProjects());
    } catch (e) {
      toast.push(`Failed to load projects: ${(e as Error).message}`, "error");
      setProjects([]);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Listen for the 'c' keyboard shortcut from AppShell.
  useEffect(() => {
    function handler() {
      if (canCreate) setShowCreate(true);
    }
    window.addEventListener("sdlc:new-project", handler);
    return () => window.removeEventListener("sdlc:new-project", handler);
  }, [canCreate]);

  const filtered = useMemo(() => {
    if (!projects) return null;
    const q = query.trim().toLowerCase();
    if (!q) return projects;
    return projects.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.description ?? "").toLowerCase().includes(q),
    );
  }, [projects, query]);

  const stats = useMemo(() => {
    const list = projects ?? [];
    const active = list.filter((p) => p.status === "active").length;
    return [
      { label: "Total projects", value: list.length },
      { label: "Active", value: active },
      { label: "Your role", value: role ?? "—" },
    ];
  }, [projects, role]);

  return (
    <div className="space-y-6">
      {/* Hero strip */}
      <div className="overflow-hidden rounded-2xl border border-brand-200/70 bg-linear-to-br from-brand-50 via-white to-slate-50 px-6 py-5 dark:border-brand-900/40 dark:from-brand-900/30 dark:via-slate-900 dark:to-slate-900">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-brand-700 dark:text-brand-300">
              Workspace
            </div>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
              Welcome back{email ? `, ${email.split("@")[0]}` : ""}
            </h1>
            <p className="mt-1 max-w-2xl text-sm text-slate-600 dark:text-slate-400">
              Each project bundles requirement docs, generated SCS versions, and
              OpenAPI specs. Start a new one, or open an existing project to
              review the latest design draft.
            </p>
          </div>
          <Button
            disabled={!canCreate}
            title={canCreate ? "" : "Author role required"}
            onClick={() => setShowCreate(true)}
          >
            + New project
          </Button>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-3">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-lg border border-slate-200/70 bg-white/70 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/60"
            >
              <div className="text-[11px] font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {s.label}
              </div>
              <div className="mt-0.5 text-lg font-semibold text-slate-900 dark:text-slate-100">
                {s.value}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search bar */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <SearchIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            className={`${inputClass} pl-9`}
            placeholder="Search projects by name or description…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {filtered && (
          <span className="hidden text-xs text-slate-500 sm:inline">
            {filtered.length} of {projects?.length ?? 0}
          </span>
        )}
      </div>

      {projects === null && (
        <div className="flex justify-center p-10">
          <Spinner />
        </div>
      )}

      {filtered && filtered.length === 0 && (
        <EmptyState
          title={
            projects && projects.length === 0 ? "No projects yet" : "No matches"
          }
          body={
            projects && projects.length === 0
              ? "Create your first project to upload requirement documents and generate an SCS."
              : "Try a different search term."
          }
          action={
            canCreate &&
            projects &&
            projects.length === 0 && (
              <Button onClick={() => setShowCreate(true)}>+ New project</Button>
            )
          }
        />
      )}

      {filtered && filtered.length > 0 && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="group block focus:outline-none"
            >
              <Card className="flex h-full flex-col p-5 transition-all group-hover:-translate-y-0.5 group-hover:border-brand-200 group-hover:shadow-popover group-focus-visible:border-brand-500 dark:group-hover:border-brand-700">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="grid h-9 w-9 place-items-center rounded-lg bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">
                      <FolderIcon className="h-4 w-4" />
                    </div>
                    <div className="text-sm font-semibold text-slate-900 group-hover:text-brand-700 dark:text-slate-100 dark:group-hover:text-brand-300">
                      {p.name}
                    </div>
                  </div>
                  <Badge tone={p.status === "active" ? "green" : "slate"}>
                    {p.status}
                  </Badge>
                </div>
                {p.description && (
                  <p className="mt-3 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">
                    {p.description}
                  </p>
                )}
                <div className="mt-auto flex items-end justify-between pt-4 text-[11px] text-slate-500 dark:text-slate-400">
                  <span>
                    Created {new Date(p.created_at).toLocaleDateString()}
                  </span>
                  <div className="flex items-center gap-2">
                    {canDelete && (
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          setConfirmDelete(p);
                        }}
                        className="text-red-600 hover:text-red-700"
                      >
                        Delete
                      </button>
                    )}
                    <span className="text-brand-600 group-hover:text-brand-700 dark:text-brand-300">
                      Open →
                    </span>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}

      <CreateModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreated={async () => {
          setShowCreate(false);
          toast.push("Project created", "success");
          await refresh();
        }}
      />

      <Modal
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        title="Delete project?"
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={async () => {
                if (!confirmDelete) return;
                try {
                  await api.deleteProject(confirmDelete.id);
                  toast.push("Project deleted", "success");
                  setConfirmDelete(null);
                  await refresh();
                } catch (e) {
                  toast.push((e as Error).message, "error");
                }
              }}
            >
              Delete
            </Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">
          This will permanently remove{" "}
          <span className="font-medium">{confirmDelete?.name}</span> and all of
          its documents, SCS versions, and OpenAPI versions. This cannot be
          undone.
        </p>
      </Modal>
    </div>
  );
}

function CreateModal({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setName("");
      setDescription("");
    }
  }, [open]);

  async function submit() {
    if (!name.trim()) return;
    setSubmitting(true);
    try {
      await api.createProject({
        name: name.trim(),
        description: description.trim() || undefined,
      });
      onCreated();
    } catch (e) {
      toast.push((e as Error).message, "error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="New project"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={!name.trim() || submitting}>
            {submitting ? <Spinner /> : "Create"}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Name">
          <input
            autoFocus
            className={inputClass}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Order Management Integration"
          />
        </Field>
        <Field label="Description (optional)">
          <textarea
            className={`${inputClass} h-20 resize-none`}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Short summary of what this project covers."
          />
        </Field>
      </div>
    </Modal>
  );
}

function SearchIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <circle cx="9" cy="9" r="5.5" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="m17 17-3.4-3.4"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function FolderIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" fill="none" className={className} aria-hidden>
      <path
        d="M2.5 5.5A1.5 1.5 0 0 1 4 4h3.5l1.5 1.5H16A1.5 1.5 0 0 1 17.5 7v7A1.5 1.5 0 0 1 16 15.5H4A1.5 1.5 0 0 1 2.5 14v-8.5Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
    </svg>
  );
}
