from datetime import datetime

from pydantic import BaseModel, ConfigDict


class SCSGenerateRequest(BaseModel):
    steering: str | None = None
    deployment: str | None = None  # Azure OpenAI deployment override


class SCSVersionUpdate(BaseModel):
    markdown: str


class SCSVersionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    project_id: str
    version_no: int
    status: str
    markdown: str
    model: str
    tokens_in: int
    tokens_out: int
    created_by: str
    created_at: datetime
