from fastapi import APIRouter

from app.api.v1 import audit, chat, openapi_spec, projects, scs, uploads

router = APIRouter()
router.include_router(projects.router)
router.include_router(uploads.router)
router.include_router(scs.router)
router.include_router(openapi_spec.router)
router.include_router(chat.router)
router.include_router(audit.router)
