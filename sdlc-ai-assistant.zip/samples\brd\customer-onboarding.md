# Business Requirements Document — Customer Onboarding (KYC)

**Project:** Digital Customer Onboarding for Retail Banking
**Author:** Retail Banking Product Team
**Date:** 2026-03-30
**Version:** 1.2

## 1. Background

Retail Banking wants to launch a fully digital onboarding journey for new customers,
replacing the existing branch-only process. The journey must collect identity data,
perform KYC + AML screening, capture consents, and provision a savings account.

## 2. Goals

- Reduce time-to-account from 3 business days to under 10 minutes for low-risk applicants.
- Achieve a STP (straight-through processing) rate of ≥ 70% in the first 6 months.
- Stay fully compliant with the regulator's e-KYC framework and DPDP guidelines.

## 3. User Stories

- As a **prospect**, I want to start onboarding from my phone and finish on my laptop, so
  that I can complete on whatever device I have at hand.
- As a **prospect**, I want to upload my photo ID and a selfie, so that the bank can verify
  my identity without me visiting a branch.
- As a **compliance officer**, I want every applicant screened against PEP and sanctions
  lists, so that we don't onboard prohibited customers.
- As an **operations agent**, I want a queue of "needs manual review" cases with all
  evidence in one place, so that I can decide quickly.

## 4. Functional Scope

### F-1 Application Capture
Capture: full legal name, DOB, mobile, email, residential address, occupation, source of
funds. Real-time validations (e.g., DOB ≥ 18, mobile OTP).

### F-2 Document & Biometrics
Accept JPEG/PDF for ID (Aadhaar / PAN / passport). Capture a live selfie, perform liveness
check, and match the selfie against the ID photo. Liveness threshold ≥ 0.85.

### F-3 KYC Orchestration
Call the KYC vendor for ID extraction (OCR), name/DOB cross-check against the ID, and
PEP/sanctions screening. Store the vendor's reference IDs and decisions.

### F-4 Risk Decision
Combine KYC outcomes + AML screening into a `low | medium | high | reject` decision.
Low → auto-approve. Medium → manual review queue. High/reject → reject with reason.

### F-5 Account Provisioning
On approval, call the core banking system to open a savings account, generate the customer
ID, and return account number + welcome details to the journey.

### F-6 Notifications
Email + SMS at journey start, document received, decision, and account provisioned.

## 5. Integrations

| System | Purpose | Protocol |
|--------|---------|----------|
| KYC Vendor (Acuant) | OCR + face match + liveness | REST + webhook callbacks |
| AML Screening (Refinitiv) | PEP / sanctions / adverse media | REST |
| Core Banking (Finacle) | Account provisioning + customer master | SOAP / MQ |
| Document Store (S3) | Encrypted storage of ID + selfie | S3 PUT |
| Notification Hub | Email + SMS templates | REST |

## 6. Non-functional

- NFR-1 PII encrypted at rest (AES-256) and in transit (TLS 1.2+).
- NFR-2 Data residency: all customer data must remain within India.
- NFR-3 Response time P95 < 8s per step (ID upload, selfie, decision, provisioning).
- NFR-4 Audit log: every step, decision, vendor reference, and operator action.
- NFR-5 Disaster recovery RPO 15 min, RTO 1 hour.
- NFR-6 Accessibility: WCAG 2.1 AA.

## 7. Open Items

- Will photo masking be required for documents containing additional persons?
- For NRIs, which document set is mandatory at MVP?
- Should the journey resume across devices using a magic link, or only on the same device?
