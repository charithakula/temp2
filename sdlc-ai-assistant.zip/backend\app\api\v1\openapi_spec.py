import json as _json

import yaml as _yaml
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireAuthor, RequireViewer
from app.core.db import get_session
from app.models.entities import OpenAPIVersion
from app.schemas.openapi_spec import OpenAPIGenerateRequest, OpenAPIVersionOut
from app.services.openapi_generator import stream_openapi

router = APIRouter(prefix="/projects/{project_id}/openapi", tags=["openapi"])


@router.post("/generate")
async def generate_openapi(
    project_id: str,
    payload: OpenAPIGenerateRequest,
    user=RequireAuthor,
    session: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    return StreamingResponse(
        stream_openapi(
            session=session,
            project_id=project_id,
            scs_version_id=payload.scs_version_id,
            actor_oid=user.oid,
            deployment=payload.deployment,
        ),
        media_type="text/event-stream",
    )


@router.get("", response_model=list[OpenAPIVersionOut])
async def list_versions(
    project_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> list[OpenAPIVersionOut]:
    rows = (
        await session.execute(
            select(OpenAPIVersion)
            .where(OpenAPIVersion.project_id == project_id)
            .order_by(OpenAPIVersion.version_no.desc())
        )
    ).scalars().all()
    return [OpenAPIVersionOut.model_validate(r, from_attributes=True) for r in rows]


@router.get("/{version_id}", response_model=OpenAPIVersionOut)
async def get_version(
    project_id: str,
    version_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> OpenAPIVersionOut:
    v = await session.get(OpenAPIVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="OpenAPI version not found")
    return OpenAPIVersionOut.model_validate(v, from_attributes=True)


@router.get("/{version_id}/export")
async def export_version(
    project_id: str,
    version_id: str,
    format: str = Query(default="yaml", pattern="^(yaml|json)$"),
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
) -> Response:
    v = await session.get(OpenAPIVersion, version_id)
    if v is None or v.project_id != project_id:
        raise HTTPException(status_code=404, detail="OpenAPI version not found")

    if format == "yaml":
        body = v.yaml.encode("utf-8")
        media = "application/yaml; charset=utf-8"
        ext = "yaml"
    else:
        try:
            spec = _yaml.safe_load(v.yaml)
        except Exception:
            raise HTTPException(status_code=422, detail="Stored YAML is not parseable")
        body = _json.dumps(spec, indent=2).encode("utf-8")
        media = "application/json; charset=utf-8"
        ext = "json"

    filename = f"openapi-v{v.version_no}.{ext}"
    return Response(
        content=body,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
