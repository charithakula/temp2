"use client";

import { AppShell } from "@/components/app-shell";
import { AuditList } from "@/components/audit-list";

export default function AuditPage() {
  return (
    <AppShell>
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 dark:text-slate-100">
            Audit log
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            All projects · most recent 200 events.
          </p>
        </div>
        <AuditList />
      </div>
    </AppShell>
  );
}
