# Solution / System Component Specification

## 1. Executive Summary
This solution modernizes the integration between the CE storefront and the Order Management System (OMS) by routing all order-related interactions through the Integration 360 / CE platform. It replaces legacy point‑to‑point connections with managed APIs, eventing, and observability while meeting strict performance and compliance requirements. The system supports real-time order creation, order status retrieval, OMS-driven status updates, cancellations, and daily financial reconciliation. Idempotency, correlation, and auditability are built in to support scale and operational reliability. The outcome is a resilient, replayable, and supportable order integration aligned with business growth.

## 2. Scope

### In Scope
- Order creation from CE storefront to OMS.
- Order status lookup by order ID.
- Inbound OMS order status webhook/event handling.
- Order cancellation requests and responses.
- Downstream notification triggering on status changes (SMS/email).
- Daily reconciliation file delivery to SFTP at 02:00 IST.
- Observability, correlation ID propagation, and audit logging.

### Out of Scope
- Payment processing beyond passing payment tokens (no PAN/CVV handling).
- Partial order cancellations (pending clarification).
- OMS internal fulfillment or inventory logic.
- Notification channel implementation details (content/templates).

### Assumptions
- OMS REST APIs and message bus topics are available as documented.
- CE storefront and CSR tools consume platform APIs.
- Payment authorization is handled by OMS using provided payment tokens.

### Dependencies
- OMS REST APIs (`/v2/orders`, `/v2/orders/{id}`, `/v2/orders/{id}/cancel`).
- OMS events on Integration 360 message bus topic `oms.order.status.v1`.
- OAuth 2.0 client‑credentials for OMS authentication.
- SFTP endpoint for finance reconciliation.

## 3. Architecture Overview

### Components & Responsibilities
- **CE Storefront / CSR Tools**: Initiate order create, lookup, and cancellation requests.
- **Integration 360 / CE Platform**:
  - API layer for order operations.
  - Idempotency and correlation handling.
  - Event subscription and webhook verification.
  - Persistence of order state and audit logs.
  - Triggering notifications and reconciliation exports.
- **OMS**:
  - System of record for orders.
  - Provides REST APIs and publishes order status events.
- **Notification Services**: Send SMS/email on status changes.
- **Finance SFTP**: Receives daily reconciliation files.

### Interaction Diagram
```mermaid
flowchart LR
    CE[CE Storefront / CSR] -->|Order APIs| I360[Integration 360 / CE]
    I360 -->|REST / OAuth2| OMS[Order Management System]
    OMS -->|Status Events| I360
    I360 -->|Triggers| Notify[SMS / Email]
    I360 -->|Daily File 02:00 IST| SFTP[Finance SFTP]
```

## 4. Required APIs

| API Name | Purpose | Consumer | Provider | Auth |
|--------|---------|----------|----------|------|
| Order Create API | Create a new sales order | CE Storefront | Integration 360 | Platform standard (not specified) |
| Order Status API | Retrieve latest order status | CE / CSR | Integration 360 | Platform standard (not specified) |
| Order Cancel API | Request order cancellation | CE / CSR | Integration 360 | Platform standard (not specified) |
| `/v2/orders` | Create order in OMS | Integration 360 | OMS | OAuth 2.0 client‑credentials |
| `/v2/orders/{id}` | Get order details/status | Integration 360 | OMS | OAuth 2.0 client‑credentials |
| `/v2/orders/{id}/cancel` | Cancel order | Integration 360 | OMS | OAuth 2.0 client‑credentials |
| Status Webhook / Event | Push order status changes | OMS | Integration 360 | HMAC SHA‑256 signature |

## 5. Request / Response Flows

### Flow 1: UC‑1 Place an Order
1. Customer completes checkout on CE storefront.
2. CE calls Integration 360 Order Create API with order data and `Idempotency-Key`.
3. Integration 360 validates request, propagates correlation ID.
4. Integration 360 calls OMS `/v2/orders`.
5. OMS returns `orderId` and payment authorization status.
6. Integration 360 persists response and returns confirmation to CE.
7. Confirmation email is triggered.

**Primary Entities:** Customer, Order, Line Item, Payment Token.

### Flow 2: UC‑2 Order Status Lookup
1. CE/CSR submits `orderId` to Integration 360.
2. Integration 360 retrieves latest known status (and/or queries OMS `/v2/orders/{id}`).
3. Response returned with status, fulfillment details, tracking number, payment summary.

**Primary Entities:** Order, Fulfillment, Payment Summary.

### Flow 3: UC‑3 Order Status Webhook/Event
1. OMS publishes status transition on `oms.order.status.v1`.
2. Integration 360 verifies HMAC SHA‑256 signature.
3. Status is persisted and correlated to existing order.
4. Notifications are triggered and order history updated.

**Primary Entities:** Order Status Event, Notification.

### Flow 4: UC‑4 Cancellation
1. CE/CSR requests cancellation with reason code.
2. Integration 360 calls OMS `/v2/orders/{id}/cancel`.
3. OMS validates fulfillment state and responds with success or reason code.
4. Integration 360 updates order state and returns result to requester.

**Primary Entities:** Order, Cancellation Request.

## 6. Integration & Sequence Details

- **Authentication:** OAuth 2.0 client‑credentials for all OMS REST calls; token validity 60 minutes.
- **Idempotency:** `Idempotency-Key` header supported on order creation; same key returns original response for 24 hours.
- **Event Handling:** OMS status updates consumed from Integration 360 message bus topic `oms.order.status.v1`.
- **Webhook Security:** All inbound payloads verified using HMAC SHA‑256 signatures.
- **Retries & Errors:**
  - REST call failures handled by platform retry mechanisms (policy not specified).
  - Duplicate create requests resolved via idempotency.
  - Error responses from OMS propagated with reason codes for cancellations.
- **Reconciliation:** Daily export generated by Integration 360 and delivered to SFTP at 02:00 IST.

## 7. Data Model

### Key Entities
- **Order**
  - orderId
  - customerId
  - status
  - totalAmount
  - currency
  - lastUpdatedAt
- **Line Item**
  - sku
  - quantity
  - unitPrice
- **Fulfillment Details**
  - fulfillmentStatus
  - trackingNumber
- **Payment Summary**
  - authorizationStatus
  - paymentToken (reference only)
- **Cancellation**
  - reasonCode (`customer_request`, `payment_failed`, `inventory_short`, `fraud_detected`, `address_invalid`)

### Relationships
- Order **has many** Line Items.
- Order **has one** Payment Summary.
- Order **has zero or one** Fulfillment Details.
- Order **may have** a Cancellation.

## 8. Non-functional Requirements

- **Performance:** Order creation P95 latency < 2 seconds end‑to‑end.
- **Availability:** ≥ 99.9% during business hours.
- **Security:** OAuth 2.0, HMAC‑signed webhooks, no PAN/CVV logging.
- **Observability:** Correlation ID included and propagated across all payloads.
- **Compliance:** PCI constraints respected via tokenization only.
- **Audit & Retention:** Order and refund audit logs retained for 7 years.

## 9. Open Questions
- Should partial cancellations be supported in MVP, or full‑order only?
- Should the daily reconciliation be a full refresh or delta‑only?
- Is webhook/event retry policy owned by OMS or by the Integration 360 platform?
- Should order status lookup always call OMS, or rely on persisted state when available?