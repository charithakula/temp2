from collections.abc import AsyncIterator
from hashlib import sha256
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entities import AuditLog, Document, SCSVersion
from app.services.embeddings import retrieve_relevant
from app.services.ingestion import build_corpus
from app.services.llm_client import Usage, stream_completion
from app.services.sse import sse
from app.services.token_cap import check_cap

_PROMPTS = Path(__file__).resolve().parent.parent / "prompts"

# How much of the document corpus to send when no embeddings are available.
_FULL_TEXT_FALLBACK_LIMIT = 80_000  # characters


def _load(name: str) -> str:
    return (_PROMPTS / name).read_text(encoding="utf-8")


def _hash(text: str) -> str:
    return sha256(text.encode()).hexdigest()


async def _full_corpus(session: AsyncSession, project_id: str) -> str:
    rows = (
        await session.execute(
            select(Document.filename, Document.text_extracted).where(
                Document.project_id == project_id
            )
        )
    ).all()
    corpus = build_corpus([(r[0], r[1] or "") for r in rows])
    return corpus[:_FULL_TEXT_FALLBACK_LIMIT]


async def _build_corpus(
    session: AsyncSession, project_id: str, steering: str | None
) -> str:
    """Prefer pgvector retrieval; fall back to whole document text on failure."""
    if not settings.azure_openai_api_key:
        return await _full_corpus(session, project_id)

    query_parts = [
        "solution architecture, required APIs, request/response flows, integration sequences",
    ]
    if steering:
        query_parts.append(steering)
    query = " ".join(query_parts)

    try:
        chunks = await retrieve_relevant(
            session=session, project_id=project_id, query=query, top_k=20
        )
    except Exception:
        return await _full_corpus(session, project_id)

    if not chunks:
        return await _full_corpus(session, project_id)
    return "\n\n---\n\n".join(chunks)


async def _next_version_no(session: AsyncSession, project_id: str) -> int:
    rows = (
        await session.execute(
            select(SCSVersion).where(SCSVersion.project_id == project_id)
        )
    ).scalars().all()
    return len(rows) + 1


async def stream_scs(
    *,
    session: AsyncSession,
    project_id: str,
    actor_oid: str,
    steering: str | None,
    deployment: str | None,
) -> AsyncIterator[bytes]:
    try:
        await check_cap(session, project_id)
    except Exception as exc:
        yield sse("error", {"message": str(exc.detail) if hasattr(exc, "detail") else str(exc)})
        return

    cached_corpus = await _build_corpus(session, project_id, steering)

    system = _load("scs_system.md")
    user_message = _load("scs_user.md").replace("{{STEERING}}", steering or "")
    chosen_deployment = deployment or settings.scs_deployment

    prompt_hash = _hash(system + (cached_corpus or "") + user_message)

    usage = Usage()
    buf: list[str] = []
    try:
        async for delta in stream_completion(
            deployment=chosen_deployment,
            system=system,
            cached_corpus=cached_corpus or None,
            user_message=user_message,
            usage_out=usage,
        ):
            buf.append(delta)
            yield sse("token", {"delta": delta})
    except Exception as exc:
        yield sse("error", {"message": f"Generation failed: {exc}"})
        return

    markdown = "".join(buf)
    version_no = await _next_version_no(session, project_id)
    version = SCSVersion(
        project_id=project_id,
        version_no=version_no,
        status="draft",
        markdown=markdown,
        prompt_hash=prompt_hash,
        model=chosen_deployment,
        tokens_in=usage.prompt_tokens,
        tokens_out=usage.completion_tokens,
        created_by=actor_oid,
    )
    session.add(version)
    await session.commit()
    await session.refresh(version)

    import json as _json
    session.add(
        AuditLog(
            project_id=project_id,
            actor_oid=actor_oid,
            actor_email="",
            actor_role="",
            action="scs.generate",
            entity_type="scs_version",
            entity_id=version.id,
            metadata_json=_json.dumps(
                {
                    "version_no": version.version_no,
                    "model": chosen_deployment,
                    "chars": len(markdown),
                    "tokens_in": usage.prompt_tokens,
                    "tokens_out": usage.completion_tokens,
                }
            ),
        )
    )
    await session.commit()

    yield sse(
        "done",
        {
            "version_id": version.id,
            "version_no": version.version_no,
            "tokens_in": usage.prompt_tokens,
            "tokens_out": usage.completion_tokens,
        },
    )
