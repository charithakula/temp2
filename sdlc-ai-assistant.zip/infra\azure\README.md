# Azure Infrastructure (Bicep)

Provisions a complete environment of the SDLC AI Assistant. Deploys:

- **App Service Plan** (Linux, B2 for dev / P1v3 for prod)
- **Web App — backend** (Python 3.11, FastAPI)
- **Web App — frontend** (Node 20, Next.js 16)
- **Azure OpenAI** with `gpt-4o` and `text-embedding-3-small` deployments
- **Azure Database for PostgreSQL Flexible Server** with **pgvector** (`azure.extensions=VECTOR`)
- **Azure Storage** account + `uploads` and `exports` containers
- **Azure Key Vault** (RBAC) holding all secrets, referenced from Web App settings via Managed Identity
- **Application Insights** + **Log Analytics workspace**

## Files

```
main.bicep              — orchestrator
main.dev.bicepparam     — dev parameters (reads secrets from env vars)
main.prod.bicepparam    — prod parameters (create when ready)
modules/
  appinsights.bicep
  keyvault.bicep
  openai.bicep
  plan.bicep
  postgres.bicep
  storage.bicep
  webapp.bicep
```

## Deploy

```bash
RG=rg-sdlc-ai-dev
LOC=eastus2

# 1. Resource group
az group create -n $RG -l $LOC

# 2. Provide secrets (don't commit these — .bicepparam reads from env)
export POSTGRES_PASSWORD='<strong-password>'
export AZURE_OPENAI_API_KEY=''   # set after AOAI is created, or leave empty

# 3. Deploy
az deployment group create \
  -g $RG \
  --template-file main.bicep \
  --parameters main.dev.bicepparam

# 4. Once Azure OpenAI is up, copy its key into Key Vault:
KV=$(az keyvault list -g $RG --query "[0].name" -o tsv)
AOAI=$(az cognitiveservices account list -g $RG --query "[0].name" -o tsv)
KEY=$(az cognitiveservices account keys list -g $RG -n $AOAI --query "key1" -o tsv)
az keyvault secret set --vault-name $KV --name AZURE-OPENAI-API-KEY --value $KEY
```

The two Web Apps' deploy workflows in [`../../.github/workflows/`](../../.github/workflows/) handle application-code releases — this Bicep only stands up the resources.

## Per-environment

Copy `main.dev.bicepparam` → `main.prod.bicepparam` and bump:
- `env = 'prod'`
- the SKU upgrades automatically inside `plan.bicep` (B2 → P1v3) based on `env`.

## Cost notes

- AOAI on `S0` is pay-as-you-go.
- Postgres `Standard_B2s` ≈ $30/mo at idle.
- App Service `B2` ≈ $55/mo (per app); `P1v3` prod ≈ $130/mo.
- Storage / Key Vault / App Insights are negligible at this scale.
