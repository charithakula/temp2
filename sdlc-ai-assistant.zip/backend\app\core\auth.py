"""Entra ID JWT validation + RBAC.

Roles map to Entra ID **app roles** declared on the API app registration. The
token's `roles` claim is an array of role strings (e.g. `["Author"]`). Until
real JWKS validation is wired (see `TODO`), the dev stub reads a single role
from `DEV_ROLE` so the rest of the stack — including authorization checks —
can be exercised locally.
"""
from __future__ import annotations

from enum import StrEnum

from fastapi import Depends, Header, HTTPException, status

from app.core.config import settings


class Role(StrEnum):
    VIEWER = "Viewer"
    AUTHOR = "Author"
    ADMIN = "Admin"


# Higher number = more privilege. A required role is satisfied if the user
# holds any role at or above the required level.
_RANK: dict[str, int] = {
    Role.VIEWER: 1,
    Role.AUTHOR: 2,
    Role.ADMIN: 3,
}


class CurrentUser:
    def __init__(self, oid: str, email: str, roles: list[str]) -> None:
        self.oid = oid
        self.email = email
        self.roles = roles

    @property
    def max_rank(self) -> int:
        return max((_RANK.get(r, 0) for r in self.roles), default=0)

    def has_at_least(self, required: Role) -> bool:
        return self.max_rank >= _RANK[required]


_VALID_ROLES = {r.value for r in Role}


async def get_current_user(
    authorization: str | None = Header(default=None),
    x_dev_role: str | None = Header(default=None, alias="X-Dev-Role"),
    x_dev_email: str | None = Header(default=None, alias="X-Dev-Email"),
) -> CurrentUser:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing bearer token",
        )

    # TODO: validate the bearer token against Entra ID JWKS, then read:
    #   - oid from the `oid` (or `sub`) claim
    #   - email from `preferred_username` / `email`
    #   - roles from the `roles` claim (array of strings)
    # Dev-mode stub: trust the X-Dev-Role / X-Dev-Email headers from the SPA's
    # dev login, falling back to DEV_ROLE from .env.
    role = (x_dev_role or settings.dev_role or Role.AUTHOR.value).strip()
    if role not in _VALID_ROLES:
        role = Role.AUTHOR.value
    return CurrentUser(
        oid="dev-user",
        email=(x_dev_email or "dev@example.com").strip(),
        roles=[role],
    )


CurrentUserDep = Depends(get_current_user)


def require_role(minimum: Role):
    """FastAPI dependency that enforces a minimum role on a route."""

    async def _check(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if not user.has_at_least(minimum):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"Requires role '{minimum.value}' or higher; "
                    f"user has {user.roles or 'no roles'}"
                ),
            )
        return user

    return _check


# Convenience pre-bound dependencies
RequireViewer = Depends(require_role(Role.VIEWER))
RequireAuthor = Depends(require_role(Role.AUTHOR))
RequireAdmin = Depends(require_role(Role.ADMIN))
