// Provisions all infrastructure for one environment of the SDLC AI Assistant.
//
//   az deployment group create \
//     --resource-group rg-sdlc-ai-dev \
//     --template-file main.bicep \
//     --parameters main.dev.bicepparam
//
// Deploy the application code separately via the GitHub Actions workflows.

@description('Short environment label (e.g. dev / prod). Used in resource names.')
param env string = 'dev'

@description('Azure region for all resources.')
param location string = resourceGroup().location

@description('Postgres administrator login.')
param postgresAdmin string = 'sdlcadmin'

@description('Postgres administrator password (provide via .bicepparam — do not commit).')
@secure()
param postgresPassword string

@description('Anthropic / Azure OpenAI key (set after the AOAI resource is created).')
@secure()
param openaiKey string = ''

var prefix = 'sdlc-ai-${env}'
var tags = { project: 'sdlc-ai-assistant', env: env, cost: 'AMI-2.0' }

// -------------------- Log Analytics + App Insights --------------------
module appi 'modules/appinsights.bicep' = {
  name: 'appi'
  params: { name: 'appi-${prefix}', location: location, tags: tags }
}

// -------------------- Storage account (uploads / exports) --------------------
module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: { name: replace('st${prefix}', '-', ''), location: location, tags: tags }
}

// -------------------- Postgres Flexible Server (with pgvector) --------------------
module pg 'modules/postgres.bicep' = {
  name: 'pg'
  params: {
    name: 'psql-${prefix}'
    location: location
    tags: tags
    administratorLogin: postgresAdmin
    administratorPassword: postgresPassword
  }
}

// -------------------- Azure OpenAI --------------------
module aoai 'modules/openai.bicep' = {
  name: 'aoai'
  params: { name: 'oai-${prefix}', location: location, tags: tags }
}

// -------------------- Key Vault --------------------
module kv 'modules/keyvault.bicep' = {
  name: 'kv'
  params: {
    name: 'kv-${take(prefix, 20)}'
    location: location
    tags: tags
    secrets: {
      'AZURE-OPENAI-API-KEY': openaiKey
      'DATABASE-URL': 'postgresql+asyncpg://${postgresAdmin}:${postgresPassword}@${pg.outputs.fqdn}:5432/sdlc_ai?ssl=require'
      'STORAGE-CONNECTION-STRING': storage.outputs.connectionString
    }
  }
}

// -------------------- App Service Plan + two Web Apps --------------------
module plan 'modules/plan.bicep' = {
  name: 'plan'
  params: { name: 'asp-${prefix}', location: location, tags: tags, env: env }
}

module backend 'modules/webapp.bicep' = {
  name: 'backend'
  params: {
    name: 'app-${prefix}-be'
    location: location
    tags: tags
    planId: plan.outputs.id
    runtime: 'PYTHON|3.11'
    appInsightsConnectionString: appi.outputs.connectionString
    keyVaultName: kv.outputs.name
    appSettings: [
      { name: 'WEBSITES_PORT', value: '8000' }
      { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT', value: 'true' }
      { name: 'AZURE_OPENAI_ENDPOINT', value: aoai.outputs.endpoint }
      { name: 'AZURE_OPENAI_API_KEY', value: '@Microsoft.KeyVault(SecretUri=${kv.outputs.secretUri('AZURE-OPENAI-API-KEY')})' }
      { name: 'AZURE_OPENAI_API_VERSION', value: '2024-12-01-preview' }
      { name: 'AZURE_OPENAI_DEPLOYMENT', value: 'gpt-4o' }
      { name: 'AZURE_OPENAI_EMBEDDING_DEPLOYMENT', value: 'text-embedding-3-small' }
      { name: 'EMBEDDINGS_DIM', value: '1536' }
      { name: 'DATABASE_URL', value: '@Microsoft.KeyVault(SecretUri=${kv.outputs.secretUri('DATABASE-URL')})' }
      { name: 'STORAGE_CONNECTION_STRING', value: '@Microsoft.KeyVault(SecretUri=${kv.outputs.secretUri('STORAGE-CONNECTION-STRING')})' }
    ]
    startupCommand: 'gunicorn -w 2 -k uvicorn.workers.UvicornWorker app.main:app --bind=0.0.0.0:8000 --timeout 120'
  }
}

module frontend 'modules/webapp.bicep' = {
  name: 'frontend'
  params: {
    name: 'app-${prefix}-fe'
    location: location
    tags: tags
    planId: plan.outputs.id
    runtime: 'NODE|20-lts'
    appInsightsConnectionString: appi.outputs.connectionString
    keyVaultName: kv.outputs.name
    appSettings: [
      { name: 'WEBSITES_PORT', value: '3000' }
      { name: 'NEXT_PUBLIC_API_BASE_URL', value: 'https://app-${prefix}-be.azurewebsites.net/api/v1' }
    ]
    startupCommand: 'npm run start'
  }
}

output backendUrl string = 'https://${backend.outputs.defaultHostname}'
output frontendUrl string = 'https://${frontend.outputs.defaultHostname}'
output postgresFqdn string = pg.outputs.fqdn
output openaiEndpoint string = aoai.outputs.endpoint
