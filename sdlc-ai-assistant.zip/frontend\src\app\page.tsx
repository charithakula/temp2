"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Spinner } from "@/components/ui";
import { useAuth } from "@/lib/auth";

export default function HomePage() {
  const router = useRouter();
  const { ready, signedIn } = useAuth();

  useEffect(() => {
    if (!ready) return;
    router.replace(signedIn ? "/projects" : "/login");
  }, [ready, signedIn, router]);

  return (
    <div className="flex min-h-screen items-center justify-center">
      <Spinner />
    </div>
  );
}
