from fastapi import APIRouter, Depends, Query
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import RequireViewer
from app.core.db import get_session
from app.models.entities import AuditLog
from app.schemas.audit import AuditLogOut

router = APIRouter(tags=["audit"])


@router.get("/audit", response_model=list[AuditLogOut])
async def global_audit(
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
    limit: int = Query(default=200, ge=1, le=1000),
) -> list[AuditLogOut]:
    rows = (
        await session.execute(
            select(AuditLog).order_by(desc(AuditLog.created_at)).limit(limit)
        )
    ).scalars().all()
    return [AuditLogOut.model_validate(r, from_attributes=True) for r in rows]


@router.get("/projects/{project_id}/audit", response_model=list[AuditLogOut])
async def project_audit(
    project_id: str,
    user=RequireViewer,
    session: AsyncSession = Depends(get_session),
    limit: int = Query(default=200, ge=1, le=1000),
) -> list[AuditLogOut]:
    rows = (
        await session.execute(
            select(AuditLog)
            .where(AuditLog.project_id == project_id)
            .order_by(desc(AuditLog.created_at))
            .limit(limit)
        )
    ).scalars().all()
    return [AuditLogOut.model_validate(r, from_attributes=True) for r in rows]
