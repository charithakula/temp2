"""Lightweight regex-based PII detection for uploaded documents.

This is a *flag* not a *block* — uploads still succeed but the response
includes counts the UI can show as a warning. Patterns are intentionally
conservative: false positives are worse than missed entities for an
internal SDLC tool.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# Anchored / bounded patterns to keep false-positive noise low.
_PATTERNS: dict[str, re.Pattern[str]] = {
    "email": re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b", re.IGNORECASE),
    # US-style SSN with dashes; we deliberately don't match bare 9-digit numbers.
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    # 13-19 digit card-shaped numbers, with optional separators.
    "credit_card": re.compile(r"\b(?:\d[ -]?){13,19}\b"),
    # Indian PAN (5 letters, 4 digits, 1 letter).
    "pan": re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b"),
    # Indian Aadhaar — 12 digits, often grouped 4-4-4.
    "aadhaar": re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),
    # AWS access key id.
    "aws_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    # Generic bearer-ish tokens (long opaque strings).
    "bearer_token": re.compile(r"\b(?:sk|pat|ghp|xox[baprs])-[A-Za-z0-9_-]{20,}\b"),
}


@dataclass
class PIIReport:
    counts: dict[str, int]
    total: int


def scan(text: str) -> PIIReport:
    counts: dict[str, int] = {}
    for kind, pat in _PATTERNS.items():
        n = sum(1 for _ in pat.finditer(text))
        if n:
            counts[kind] = n
    return PIIReport(counts=counts, total=sum(counts.values()))
