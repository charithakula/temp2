"""Embeddings + chunking + vector retrieval (RAG) for project documents.

Uses Azure OpenAI's embeddings deployment (default `text-embedding-3-small`,
1536 dims). On Postgres + pgvector we run a real ANN search; on SQLite we
fall back to a Python cosine over JSON-encoded vectors so local dev works.
"""
from __future__ import annotations

import json
import math

from openai import AsyncAzureOpenAI
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entities import DocumentChunk

_client: AsyncAzureOpenAI | None = None


def _get_client() -> AsyncAzureOpenAI:
    global _client
    if _client is None:
        _client = AsyncAzureOpenAI(
            api_key=settings.azure_openai_api_key,
            api_version=settings.azure_openai_api_version,
            azure_endpoint=settings.azure_openai_endpoint,
        )
    return _client


# ---- Chunking -----------------------------------------------------------

CHUNK_SIZE = 1500   # characters
CHUNK_OVERLAP = 200


def chunk_text(text_in: str) -> list[str]:
    """Naive character-based chunker with overlap. Good enough for MVP."""
    text_in = text_in.strip()
    if not text_in:
        return []
    if len(text_in) <= CHUNK_SIZE:
        return [text_in]

    chunks: list[str] = []
    step = CHUNK_SIZE - CHUNK_OVERLAP
    for start in range(0, len(text_in), step):
        end = start + CHUNK_SIZE
        chunks.append(text_in[start:end])
        if end >= len(text_in):
            break
    return chunks


# ---- Embeddings ---------------------------------------------------------

async def embed_batch(texts: list[str]) -> list[list[float]]:
    if not texts:
        return []
    client = _get_client()
    res = await client.embeddings.create(
        model=settings.azure_openai_embeddings_deployment,
        input=texts,
    )
    return [item.embedding for item in res.data]


def _encode_for_storage(vec: list[float]) -> object:
    """On Postgres pgvector accepts the list directly; on SQLite we JSON-encode."""
    return vec if settings.is_postgres else json.dumps(vec)


def _decode_from_storage(value: object) -> list[float]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return json.loads(value)
    # pgvector may return a numpy-like array
    return list(value)  # type: ignore[arg-type]


async def index_document(
    *,
    session: AsyncSession,
    project_id: str,
    document_id: str,
    full_text: str,
) -> int:
    """Chunk + embed + persist. Returns the number of chunks indexed."""
    chunks = chunk_text(full_text)
    if not chunks:
        return 0
    vectors = await embed_batch(chunks)

    for idx, (content, vec) in enumerate(zip(chunks, vectors)):
        session.add(
            DocumentChunk(
                document_id=document_id,
                project_id=project_id,
                chunk_index=idx,
                content=content,
                embedding=_encode_for_storage(vec),
            )
        )
    await session.commit()
    return len(chunks)


# ---- Retrieval ----------------------------------------------------------

def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


async def retrieve_relevant(
    *,
    session: AsyncSession,
    project_id: str,
    query: str,
    top_k: int = 12,
) -> list[str]:
    """Return the top-k most relevant chunk texts for `query` in this project."""
    [qvec] = await embed_batch([query])

    if settings.is_postgres:
        # pgvector cosine distance: smaller = closer. `<=>` is the distance op.
        rows = (
            await session.execute(
                text(
                    """
                    SELECT content
                    FROM document_chunks
                    WHERE project_id = :pid
                    ORDER BY embedding <=> CAST(:qvec AS vector)
                    LIMIT :k
                    """
                ),
                {"pid": project_id, "qvec": qvec, "k": top_k},
            )
        ).all()
        return [r[0] for r in rows]

    # SQLite fallback — load all chunks for the project and rank in Python.
    all_rows = (
        await session.execute(
            select(DocumentChunk.content, DocumentChunk.embedding).where(
                DocumentChunk.project_id == project_id
            )
        )
    ).all()
    scored = [
        (_cosine(qvec, _decode_from_storage(emb)), content)
        for content, emb in all_rows
    ]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c in scored[:top_k]]
