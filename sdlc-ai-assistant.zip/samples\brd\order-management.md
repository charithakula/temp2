# Business Requirements Document — Order Management Integration

**Project:** OMS Integration with Integration 360 / CE
**Author:** Order Operations Team
**Date:** 2026-04-15
**Version:** 1.0

## 1. Background

The Customer Engagement (CE) platform currently relies on a legacy point-to-point connection
to the Order Management System (OMS) for order creation and status retrieval. As volumes
have grown, the team needs a managed, observable, and replayable integration through the
Integration 360 hub.

## 2. Business Objectives

- Create new sales orders from the CE storefront in OMS within 2 seconds (P95).
- Retrieve up-to-date order status (created → paid → fulfilled → delivered → returned).
- Trigger downstream notifications (SMS / email) when status changes.
- Provide finance with a daily reconciliation export.

## 3. In-Scope Use Cases

### UC-1 Place an Order
A customer completes checkout on the CE storefront. The platform submits the cart, billing,
and shipping details to OMS. OMS returns an order ID and a payment authorization status.
On success, the customer sees an order confirmation and an email is sent.

### UC-2 Order Status Lookup
A customer or CSR queries an order by `orderId`. The platform returns the latest status,
fulfillment details, tracking number (if shipped), and payment summary.

### UC-3 Order Status Webhook
OMS pushes status transitions to the platform via a webhook. The platform persists the new
status, triggers a notification, and updates the customer's order history.

### UC-4 Cancellation
A CSR (or eligible customer) requests cancellation. The platform calls OMS; OMS validates
based on fulfillment state and either cancels and refunds, or returns a reason code.

## 4. Stakeholders

| Stakeholder | Role |
|-------------|------|
| Order Operations | Owner of OMS configuration |
| CE Product Team | Owner of the storefront experience |
| Finance | Consumer of reconciliation reports |
| Customer Care | Uses status lookup + cancellation flows |

## 5. Functional Requirements

- FR-1 Create order accepts: customer ID, shipping address, billing address, line items
  (sku, qty, unit price), promo codes, payment token.
- FR-2 Order status response includes: orderId, status, fulfillmentDetails, trackingNumber,
  totalAmount, currency, lastUpdatedAt.
- FR-3 Webhook payloads must be signed (HMAC SHA-256) and verified.
- FR-4 Idempotency: order create accepts an `Idempotency-Key` header; the same key returns
  the original response within 24 hours.
- FR-5 Cancellation reason codes: `customer_request`, `payment_failed`, `inventory_short`,
  `fraud_detected`, `address_invalid`.
- FR-6 Daily reconciliation file delivered to SFTP at 02:00 IST.

## 6. Non-functional Requirements

- NFR-1 Availability ≥ 99.9% during business hours.
- NFR-2 Order create P95 latency < 2 seconds end-to-end.
- NFR-3 All payloads contain a correlation ID propagated across systems.
- NFR-4 PCI: never log card PAN or CVV; payment tokens only.
- NFR-5 Audit log retention 7 years for orders and refunds.

## 7. Vendor Documentation Notes

OMS exposes a REST API (`/v2/orders`, `/v2/orders/{id}`, `/v2/orders/{id}/cancel`) and
publishes events to the Integration 360 message bus on topic `oms.order.status.v1`.
OAuth 2.0 client-credentials authentication; tokens valid 60 minutes.

## 8. Open Questions

- Should partial cancellations be supported in MVP, or full-order only?
- Reconciliation: full refresh daily, or delta-only?
- Should the webhook retry policy be owned by the platform or by OMS?
