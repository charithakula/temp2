# Solution / System Component Specification

## 1. Executive Summary
This solution enables a fully digital customer onboarding journey for Retail Banking, covering application capture, e‑KYC/AML checks, risk decisioning, and savings account provisioning. The primary objective is to reduce time-to-account opening to under 10 minutes for low‑risk applicants while maintaining regulatory compliance with the e‑KYC framework and DPDP guidelines. The system orchestrates multiple vendor and internal integrations using the Integration 360 / CE platform to achieve straight‑through processing for at least 70% of applicants. Manual review workflows are supported for medium‑risk cases, ensuring compliance oversight without degrading customer experience. All customer data is securely handled with strong encryption, auditability, and in‑country data residency.

## 2. Scope

### In Scope
- Digital onboarding journey across devices (mobile and desktop).
- Capture of applicant personal, contact, and financial profile data.
- Upload and storage of identity documents and live selfie.
- Liveness detection and face match via KYC vendor.
- KYC orchestration including OCR, ID verification, and PEP/sanctions screening.
- Risk decisioning (`low | medium | high | reject`).
- Manual review queue for medium‑risk applications.
- Savings account provisioning in core banking for approved customers.
- Email and SMS notifications at key journey milestones.
- End‑to‑end audit logging.

### Out of Scope
- Existing branch‑based onboarding processes.
- Post‑onboarding servicing (e.g., account maintenance, transactions).
- Advanced fraud analytics beyond vendor‑provided checks.

### Assumptions
- Applicants are retail customers subject to standard KYC norms.
- KYC vendor and AML screening systems are available and certified for regulatory use.
- Core Banking system exposes required provisioning interfaces.

### Dependencies
- Acuant (KYC vendor) availability and webhook callbacks.
- Refinitiv AML screening service availability.
- Core Banking (Finacle) SOAP/MQ interfaces.
- Document Store (S3) with encryption enabled.
- Notification Hub for email and SMS delivery.

## 3. Architecture Overview

### Components & Responsibilities
- **Digital Onboarding UI**: Captures user inputs, document uploads, selfie, and displays status.
- **Integration 360 / CE Platform**: Central orchestration layer handling API mediation, sequencing, error handling, and audit logging.
- **KYC Vendor (Acuant)**: OCR, face match, liveness detection, ID verification.
- **AML Screening (Refinitiv)**: PEP, sanctions, and adverse media screening.
- **Risk Decision Engine**: Combines KYC and AML outcomes into a final risk decision.
- **Manual Review Queue**: Interface for operations agents to review medium‑risk cases.
- **Core Banking (Finacle)**: Customer master creation and savings account provisioning.
- **Document Store (S3)**: Encrypted storage of ID documents and selfies.
- **Notification Hub**: Sends email and SMS notifications.

### Interaction Diagram
```mermaid
flowchart LR
UI[Digital Onboarding UI]
I360[Integration 360 / CE]
KYC[Acuant KYC Vendor]
AML[Refinitiv AML]
DOC[S3 Document Store]
CORE[Core Banking - Finacle]
NOTIF[Notification Hub]
OPS[Manual Review Queue]

UI --> I360
I360 --> DOC
I360 --> KYC
KYC --> I360
I360 --> AML
AML --> I360
I360 --> OPS
OPS --> I360
I360 --> CORE
CORE --> I360
I360 --> NOTIF
I360 --> UI
```

## 4. Required APIs

| API Name | Purpose | Consumer | Provider | Auth |
|--------|---------|----------|----------|------|
| Application Capture API | Submit and update onboarding application data | Digital UI | Integration 360 | TBD |
| Document Upload API | Upload ID documents and selfie | Digital UI | Integration 360 | TBD |
| KYC Request API | OCR, face match, liveness, ID verification | Integration 360 | Acuant | TBD |
| KYC Webhook Callback | Asynchronous KYC results | Acuant | Integration 360 | TBD |
| AML Screening API | PEP/sanctions screening | Integration 360 | Refinitiv | TBD |
| Risk Decision API | Evaluate overall applicant risk | Integration 360 | Risk Engine | TBD |
| Account Provisioning API | Open savings account | Integration 360 | Core Banking | TBD |
| Notification API | Send email/SMS notifications | Integration 360 | Notification Hub | TBD |

> Authentication mechanisms are not specified in the source documents and are captured as open questions.

## 5. Request / Response Flows

### Flow 1: Application Capture & Validation
1. Prospect enters personal details via Digital UI.
2. Integration 360 validates inputs (e.g., DOB ≥ 18, mobile OTP).
3. Application state is persisted and audit‑logged.

**Primary Entities**: Prospect, Application.

### Flow 2: Document & Selfie Processing
1. Prospect uploads ID document and captures live selfie.
2. Integration 360 stores files in S3 (encrypted).
3. KYC request sent to Acuant for OCR, liveness, and face match.
4. Acuant returns results synchronously or via webhook callback.

**Primary Entities**: Document, Biometric Data, KYC Reference ID.

### Flow 3: KYC + AML Orchestration
1. Integration 360 submits AML screening request to Refinitiv.
2. AML results received and correlated with KYC outcome.
3. Vendor reference IDs and decisions are stored.

**Primary Entities**: KYC Result, AML Result.

### Flow 4: Risk Decision & Review
1. Risk engine computes `low | medium | high | reject`.
2. Low → auto‑approve.
3. Medium → case routed to Manual Review Queue.
4. High/Reject → application rejected with reason.

**Primary Entities**: Risk Decision, Review Case.

### Flow 5: Account Provisioning
1. On approval, Integration 360 calls Core Banking.
2. Customer ID and account number returned.
3. UI updated with welcome details.

**Primary Entities**: Customer, Account.

### Flow 6: Notifications
1. Notifications triggered at start, document received, decision, and provisioning.
2. Email and SMS sent via Notification Hub.

## 6. Integration & Sequence Details

- **KYC Vendor (Acuant)**:
  - REST APIs with webhook callbacks.
  - Vendor reference IDs stored for audit.
  - Liveness threshold must be ≥ 0.85 as per requirements.
- **AML Screening (Refinitiv)**:
  - Synchronous REST calls for screening.
  - Results combined with KYC for decisioning.
- **Core Banking (Finacle)**:
  - SOAP/MQ based provisioning.
  - Account creation only after approval.
- **Retry & Error Handling**:
  - Transient failures retried by Integration 360 (details TBD).
  - Idempotency required for provisioning and KYC submissions.
- **Error Semantics**:
  - Vendor or system errors logged and surfaced for manual intervention where required.

## 7. Data Model

### Key Entities
- **Application**
  - Personal details, contact info, occupation, source of funds.
- **Document**
  - Type (Aadhaar/PAN/Passport), storage reference, upload timestamp.
- **Biometric**
  - Selfie reference, liveness score.
- **KYC Result**
  - OCR data, face match score, vendor reference ID.
- **AML Result**
  - PEP/sanctions status, screening reference ID.
- **Risk Decision**
  - Decision code, reason, timestamp.
- **Customer**
  - Customer ID from core banking.
- **Account**
  - Account number, product type, status.
- **Audit Log**
  - Step, actor, timestamp, outcome, references.

### Relationships
- One Application → Many Documents.
- One Application → One KYC Result.
- One Application → One AML Result.
- One Application → One Risk Decision.
- One Approved Application → One Customer → One Account.

## 8. Non-functional Requirements

- **Security**
  - PII encrypted at rest (AES‑256) and in transit (TLS 1.2+).
- **Data Residency**
  - All customer data stored and processed within India.
- **Performance**
  - P95 response time < 8 seconds per major step.
- **Reliability**
  - DR with RPO 15 minutes, RTO 1 hour.
- **Audit & Compliance**
  - Comprehensive audit logs for every step and decision.
- **Accessibility**
  - UI compliant with WCAG 2.1 AA.
- **Observability**
  - End‑to‑end logging and traceability across integrations.

## 9. Open Questions
- What authentication mechanisms are required for each external and internal API?
- Will photo masking be required for documents containing additional persons?
- For NRIs, which document set is mandatory at MVP?
- Should the journey resume across devices using a magic link or be restricted to the same device?
- What are the detailed retry and idempotency policies for vendor and core banking integrations?