from datetime import datetime

from pydantic import BaseModel, ConfigDict


class OpenAPIGenerateRequest(BaseModel):
    scs_version_id: str
    deployment: str | None = None  # Azure OpenAI deployment override


class OpenAPIVersionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    project_id: str
    scs_version_id: str
    version_no: int
    yaml: str
    validation_errors: str
    model: str
    tokens_in: int
    tokens_out: int
    created_by: str
    created_at: datetime
