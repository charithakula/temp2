Generate the SCS / TDS document now, using the project's source documents (provided above) as the only ground truth.

Additional steering from the user (may be empty):
{{STEERING}}

Begin the Markdown document with the title `# Solution / System Component Specification` and proceed through the sections in order. Do not include any preamble or commentary outside the document.
