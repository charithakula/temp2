"use client";

import ReactMarkdown from "react-markdown";
import rehypeHighlight from "rehype-highlight";
import remarkGfm from "remark-gfm";
import "highlight.js/styles/github.css";

export function MdPreview({ source }: { source: string }) {
  return (
    <div className="prose prose-slate max-w-none prose-headings:scroll-mt-20 prose-pre:bg-slate-900 prose-pre:text-slate-100 prose-code:before:hidden prose-code:after:hidden dark:prose-invert">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight]}
        components={{
          a: (props) => (
            <a {...props} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline" />
          ),
          table: (props) => (
            <div className="overflow-x-auto">
              <table {...props} className="w-full text-left text-sm" />
            </div>
          ),
        }}
      >
        {source}
      </ReactMarkdown>
    </div>
  );
}
