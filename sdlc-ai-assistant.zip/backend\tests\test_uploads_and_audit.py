from tests.conftest import auth


def test_upload_text_extraction_and_audit(client):
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Upload-Test"},
        headers=auth("Author"),
    ).json()["id"]

    files = {"file": ("brd.txt", b"Hello SCS world.\nUser: alice@example.com", "text/plain")}
    r = client.post(
        f"/api/v1/projects/{pid}/documents",
        files=files,
        headers=auth("Author"),
    )
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["filename"] == "brd.txt"
    assert body["extracted_chars"] > 0
    assert body["pii"]["total"] >= 1  # email PII detected

    # Audit log should record the upload.
    rows = client.get(
        f"/api/v1/projects/{pid}/audit", headers=auth("Viewer")
    ).json()
    actions = [r["action"] for r in rows]
    assert "document.upload" in actions
    assert "project.create" in actions


def test_upload_size_limit(client):
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Size-Test"},
        headers=auth("Author"),
    ).json()["id"]
    big = b"x" * (26 * 1024 * 1024)
    r = client.post(
        f"/api/v1/projects/{pid}/documents",
        files={"file": ("big.txt", big, "text/plain")},
        headers=auth("Author"),
    )
    assert r.status_code == 413


def test_document_delete(client):
    pid = client.post(
        "/api/v1/projects",
        json={"name": "Del-Doc"},
        headers=auth("Author"),
    ).json()["id"]
    did = client.post(
        f"/api/v1/projects/{pid}/documents",
        files={"file": ("a.txt", b"hi", "text/plain")},
        headers=auth("Author"),
    ).json()["id"]
    assert (
        client.delete(
            f"/api/v1/projects/{pid}/documents/{did}",
            headers=auth("Viewer"),
        ).status_code
        == 403
    )
    assert (
        client.delete(
            f"/api/v1/projects/{pid}/documents/{did}",
            headers=auth("Author"),
        ).status_code
        == 204
    )
