from collections.abc import AsyncIterator
from uuid import uuid4

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entities import SCSVersion
from app.schemas.chat import ChatHistoryItem
from app.services.embeddings import retrieve_relevant
from app.services.llm_client import stream_completion
from app.services.sse import sse

_SYSTEM = (
    "You are an assistant embedded in the SDLC AI Assistant. Help the user reason "
    "about the project's BRD/FDS inputs, generated SCS, and OpenAPI specification. "
    "Cite source documents when possible. Be concise and accurate."
)


async def _build_context(
    session: AsyncSession, project_id: str, query: str
) -> str:
    chunks: list[str] = []
    if settings.azure_openai_api_key:
        try:
            chunks = await retrieve_relevant(
                session=session, project_id=project_id, query=query, top_k=8
            )
        except Exception:
            chunks = []

    latest_scs = (
        await session.execute(
            select(SCSVersion)
            .where(SCSVersion.project_id == project_id)
            .order_by(desc(SCSVersion.version_no))
            .limit(1)
        )
    ).scalar_one_or_none()

    parts: list[str] = []
    if chunks:
        parts.append("=== Relevant Document Excerpts ===\n" + "\n\n---\n\n".join(chunks))
    if latest_scs and latest_scs.markdown:
        parts.append(
            f"=== Current SCS (v{latest_scs.version_no}, {latest_scs.status}) ===\n"
            f"{latest_scs.markdown}"
        )
    return "\n\n".join(parts)


async def stream_chat(
    *,
    session: AsyncSession,
    project_id: str,
    message: str,
    history: list[ChatHistoryItem],
) -> AsyncIterator[bytes]:
    cached_corpus = await _build_context(session, project_id, message)

    transcript = "\n".join(f"{h.role.upper()}: {h.content}" for h in history)
    user_message = f"{transcript}\n\nUSER: {message}" if transcript else message

    async for delta in stream_completion(
        deployment=settings.chat_deployment,
        system=_SYSTEM,
        cached_corpus=cached_corpus or None,
        user_message=user_message,
    ):
        yield sse("token", {"delta": delta})

    yield sse("done", {"message_id": str(uuid4())})
