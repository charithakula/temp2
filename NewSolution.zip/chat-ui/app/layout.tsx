import "./globals.css";

export const metadata = {
  title: "APIM Chat",
  description: "Chat over Azure APIM APIs via MCP and Azure OpenAI",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
