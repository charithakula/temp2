"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Server = {
  name: string;
  url: string;
  authHeader?: string;
  authValue?: string;
  authEnv?: string;
  disabled?: boolean;
};

type TestResult =
  | { state: "idle" }
  | { state: "running" }
  | { state: "ok"; latencyMs: number; tools: string[] }
  | { state: "error"; error: string; latencyMs?: number };

const EMPTY: Server = {
  name: "",
  url: "",
  authHeader: "Ocp-Apim-Subscription-Key",
  authValue: "",
};

export default function SettingsPage() {
  const [servers, setServers] = useState<Server[] | null>(null);
  const [editing, setEditing] = useState<Server | null>(null);
  const [originalName, setOriginalName] = useState<string | null>(null);
  const [test, setTest] = useState<TestResult>({ state: "idle" });
  const [saveError, setSaveError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const r = await fetch("/api/mcp-servers");
    const j = (await r.json()) as { servers: Server[] };
    setServers(j.servers);
  }
  useEffect(() => {
    refresh();
  }, []);

  function startNew() {
    setEditing({ ...EMPTY });
    setOriginalName(null);
    setTest({ state: "idle" });
    setSaveError(null);
  }
  function startEdit(s: Server) {
    setEditing({ ...s });
    setOriginalName(s.name);
    setTest({ state: "idle" });
    setSaveError(null);
  }
  function cancelEdit() {
    setEditing(null);
    setOriginalName(null);
    setTest({ state: "idle" });
    setSaveError(null);
  }

  async function runTest() {
    if (!editing) return;
    setTest({ state: "running" });
    try {
      const r = await fetch("/api/mcp-servers/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: editing.url,
          authHeader: editing.authHeader,
          authValue: editing.authValue,
          authEnv: editing.authEnv,
        }),
      });
      const j = await r.json();
      if (j.ok) {
        setTest({ state: "ok", latencyMs: j.latencyMs, tools: j.tools ?? [] });
      } else {
        setTest({ state: "error", error: j.error ?? "Unknown error", latencyMs: j.latencyMs });
      }
    } catch (err) {
      setTest({ state: "error", error: err instanceof Error ? err.message : String(err) });
    }
  }

  async function save() {
    if (!editing) return;
    setBusy(true);
    setSaveError(null);
    try {
      const isNew = originalName === null;
      const url = isNew ? "/api/mcp-servers" : `/api/mcp-servers/${encodeURIComponent(originalName!)}`;
      const method = isNew ? "POST" : "PUT";
      const r = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing),
      });
      const j = await r.json();
      if (!r.ok) {
        setSaveError(j.error ?? `HTTP ${r.status}`);
        return;
      }
      setServers(j.servers);
      cancelEdit();
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  async function remove(name: string) {
    if (!confirm(`Remove MCP server "${name}"?`)) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/mcp-servers/${encodeURIComponent(name)}`, {
        method: "DELETE",
      });
      const j = await r.json();
      if (r.ok) setServers(j.servers);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="min-h-screen"
      style={{ background: "var(--bg)", color: "var(--fg)" }}
    >
      <header
        className="flex h-12 items-center justify-between border-b px-4 text-sm"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-2 font-medium">
          <span
            className="inline-block size-2 rounded-full"
            style={{ background: "var(--accent)" }}
          />
          MCP Server Settings
        </div>
        <Link
          href="/"
          className="rounded-md border px-2.5 py-1 text-xs"
          style={{ borderColor: "var(--border)" }}
        >
          ← Back to chat
        </Link>
      </header>

      <main className="mx-auto w-full max-w-3xl px-4 py-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold">MCP servers</h1>
            <p className="text-sm" style={{ color: "var(--fg-muted)" }}>
              The chat connects to every server listed here on each turn.
              Changes take effect immediately — no restart.
            </p>
          </div>
          {!editing && (
            <button
              type="button"
              onClick={startNew}
              className="rounded-md px-3 py-1.5 text-sm font-medium"
              style={{ background: "var(--accent)", color: "var(--accent-fg)" }}
            >
              + Add MCP server
            </button>
          )}
        </div>

        {/* List */}
        {!editing && (
          <div className="flex flex-col gap-2">
            {servers === null && (
              <div className="text-sm" style={{ color: "var(--fg-muted)" }}>
                Loading…
              </div>
            )}
            {servers?.length === 0 && (
              <div
                className="rounded-lg border p-4 text-sm"
                style={{ borderColor: "var(--border)", color: "var(--fg-muted)" }}
              >
                No MCP servers configured. Click <strong>+ Add MCP server</strong> to
                configure one. While this list is empty, the chat falls back to
                environment-variable configuration if any is set.
              </div>
            )}
            {servers?.map((s) => (
              <div
                key={s.name}
                className="flex items-center justify-between rounded-lg border p-3"
                style={{ borderColor: "var(--border)", background: "var(--bg-elev)" }}
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <div className="font-medium">{s.name}</div>
                    {s.disabled && (
                      <span
                        className="rounded px-1.5 py-0.5 text-[10px] uppercase tracking-wide"
                        style={{ background: "var(--border)", color: "var(--fg-muted)" }}
                      >
                        disabled
                      </span>
                    )}
                  </div>
                  <div
                    className="truncate text-xs"
                    style={{ color: "var(--fg-muted)" }}
                  >
                    {s.url}
                  </div>
                  <div
                    className="mt-0.5 text-[11px]"
                    style={{ color: "var(--fg-muted)" }}
                  >
                    {s.authHeader ? (
                      <>
                        auth: {s.authHeader} ={" "}
                        {s.authValue
                          ? "•••• set"
                          : s.authEnv
                          ? `env:${s.authEnv}`
                          : "—"}
                      </>
                    ) : (
                      "no auth"
                    )}
                  </div>
                </div>
                <div className="flex shrink-0 gap-2">
                  <button
                    type="button"
                    onClick={() => startEdit(s)}
                    className="rounded-md border px-2.5 py-1 text-xs"
                    style={{ borderColor: "var(--border)" }}
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(s.name)}
                    disabled={busy}
                    className="rounded-md border px-2.5 py-1 text-xs"
                    style={{ borderColor: "var(--border)", color: "#b91c1c" }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Editor */}
        {editing && (
          <div
            className="rounded-lg border p-4"
            style={{
              borderColor: "var(--border)",
              background: "var(--bg-elev)",
            }}
          >
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-semibold">
                {originalName ? `Edit "${originalName}"` : "New MCP server"}
              </h2>
              <button
                type="button"
                onClick={cancelEdit}
                className="text-sm"
                style={{ color: "var(--fg-muted)" }}
              >
                Cancel
              </button>
            </div>

            <div className="grid gap-3 text-sm">
              <Field
                label="Name"
                hint="Becomes the tool prefix, e.g. `orders.getAnOrderById`. Letters, digits, _ or - only."
              >
                <input
                  value={editing.name}
                  onChange={(e) =>
                    setEditing({ ...editing, name: e.target.value })
                  }
                  className="w-full rounded-md border bg-transparent px-2 py-1.5"
                  style={{ borderColor: "var(--border)" }}
                  placeholder="customers"
                />
              </Field>

              <Field
                label="URL"
                hint="Streamable-HTTP MCP endpoint. For APIM-native MCP this looks like https://<apim>.azure-api.net/<slug>/mcp"
              >
                <input
                  value={editing.url}
                  onChange={(e) =>
                    setEditing({ ...editing, url: e.target.value })
                  }
                  className="w-full rounded-md border bg-transparent px-2 py-1.5 font-mono text-xs"
                  style={{ borderColor: "var(--border)" }}
                  placeholder="https://my-apim.azure-api.net/customersmcp/mcp"
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Auth header" hint="HTTP header to send the key on.">
                  <input
                    value={editing.authHeader ?? ""}
                    onChange={(e) =>
                      setEditing({ ...editing, authHeader: e.target.value })
                    }
                    className="w-full rounded-md border bg-transparent px-2 py-1.5 font-mono text-xs"
                    style={{ borderColor: "var(--border)" }}
                    placeholder="Ocp-Apim-Subscription-Key"
                  />
                </Field>
                <Field label="Auth value" hint="Key value. Stored in this file in plaintext (dev mode).">
                  <input
                    type="password"
                    value={editing.authValue ?? ""}
                    onChange={(e) =>
                      setEditing({ ...editing, authValue: e.target.value })
                    }
                    className="w-full rounded-md border bg-transparent px-2 py-1.5 font-mono text-xs"
                    style={{ borderColor: "var(--border)" }}
                    placeholder="paste subscription key"
                  />
                </Field>
              </div>

              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={!!editing.disabled}
                  onChange={(e) =>
                    setEditing({ ...editing, disabled: e.target.checked })
                  }
                />
                Disable (keep config, but skip on every chat turn)
              </label>

              {/* Test button + result */}
              <div className="mt-1 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={runTest}
                  disabled={!editing.url || test.state === "running"}
                  className="rounded-md border px-3 py-1.5 text-sm"
                  style={{ borderColor: "var(--border)" }}
                >
                  {test.state === "running" ? "Testing…" : "Test connection"}
                </button>
                <TestResultPill result={test} />
              </div>
              {test.state === "ok" && test.tools.length > 0 && (
                <div
                  className="rounded-md border p-2 text-xs"
                  style={{ borderColor: "var(--border)" }}
                >
                  <div style={{ color: "var(--fg-muted)" }}>
                    {test.tools.length} tool{test.tools.length === 1 ? "" : "s"} discovered:
                  </div>
                  <ul className="mt-1 flex flex-wrap gap-1">
                    {test.tools.map((t) => (
                      <li
                        key={t}
                        className="rounded px-1.5 py-0.5 font-mono"
                        style={{ background: "var(--bg)" }}
                      >
                        {editing.name || "?"}.{t}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {saveError && (
                <div className="text-sm" style={{ color: "#b91c1c" }}>
                  {saveError}
                </div>
              )}

              <div className="mt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="rounded-md border px-3 py-1.5 text-sm"
                  style={{ borderColor: "var(--border)" }}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={save}
                  disabled={busy || !editing.name || !editing.url}
                  className="rounded-md px-3 py-1.5 text-sm font-medium disabled:opacity-50"
                  style={{
                    background: "var(--accent)",
                    color: "var(--accent-fg)",
                  }}
                >
                  {busy ? "Saving…" : originalName ? "Save changes" : "Add server"}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs font-medium">{label}</span>
      {children}
      {hint && (
        <span className="text-[11px]" style={{ color: "var(--fg-muted)" }}>
          {hint}
        </span>
      )}
    </label>
  );
}

function TestResultPill({ result }: { result: TestResult }) {
  if (result.state === "idle") return null;
  if (result.state === "running")
    return (
      <span className="text-xs" style={{ color: "var(--fg-muted)" }}>
        probing endpoint…
      </span>
    );
  if (result.state === "ok")
    return (
      <span
        className="rounded-full px-2 py-0.5 text-xs font-medium"
        style={{ background: "#dcfce7", color: "#15803d" }}
      >
        ✓ Connected · {result.tools.length} tools · {result.latencyMs}ms
      </span>
    );
  return (
    <span
      className="rounded-full px-2 py-0.5 text-xs font-medium"
      style={{ background: "#fee2e2", color: "#b91c1c" }}
      title={result.error}
    >
      ✗ {result.error.slice(0, 80)}
      {result.error.length > 80 ? "…" : ""}
    </span>
  );
}
