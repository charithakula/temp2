"use client";

import { useChat } from "@ai-sdk/react";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export default function Chat() {
  const { messages, input, handleInputChange, handleSubmit, status, stop } =
    useChat();

  const scrollerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = scrollerRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, status]);

  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "0px";
    ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
  }, [input]);

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (input.trim() && status === "ready") handleSubmit();
    }
  };

  const isBusy = status === "submitted" || status === "streaming";
  const empty = messages.length === 0;

  return (
    <div
      className="flex h-screen flex-col"
      style={{ background: "var(--bg)", color: "var(--fg)" }}
    >
      {/* Header */}
      <header
        className="flex h-12 items-center justify-between border-b px-4 text-sm"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-2 font-medium">
          <span
            className="inline-block size-2 rounded-full"
            style={{ background: "var(--accent)" }}
          />
          APIM Chat
        </div>
        <div className="flex items-center gap-3 text-xs" style={{ color: "var(--fg-muted)" }}>
          <span>Azure OpenAI + MCP</span>
          <Link
            href="/settings"
            className="rounded-md border px-2 py-1"
            style={{ borderColor: "var(--border)", color: "var(--fg)" }}
            title="Manage MCP servers"
          >
            ⚙ Settings
          </Link>
        </div>
      </header>

      {/* Conversation */}
      <div ref={scrollerRef} className="flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-3xl px-4 py-6">
          {empty && (
            <div
              className="mt-24 text-center"
              style={{ color: "var(--fg-muted)" }}
            >
              <div
                className="mx-auto mb-4 flex size-12 items-center justify-center rounded-full text-lg"
                style={{ background: "var(--bg-elev)" }}
              >
                ✦
              </div>
              <h1
                className="mb-1 text-xl font-semibold"
                style={{ color: "var(--fg)" }}
              >
                How can I help with your APIs?
              </h1>
              <p className="text-sm">
                Ask anything — I can call your Azure APIM operations as tools.
              </p>
            </div>
          )}

          <div className="flex flex-col gap-6">
            {messages.map((m) => (
              <MessageRow key={m.id} message={m} />
            ))}
            {status === "submitted" && (
              <div
                className="flex items-center gap-2 text-sm"
                style={{ color: "var(--fg-muted)" }}
              >
                <span className="size-1.5 animate-pulse rounded-full bg-current" />
                Thinking…
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Composer */}
      <div
        className="border-t"
        style={{ borderColor: "var(--border)", background: "var(--bg)" }}
      >
        <form
          onSubmit={handleSubmit}
          className="mx-auto w-full max-w-3xl px-4 py-3"
        >
          <div
            className="flex items-end gap-2 rounded-2xl border px-3 py-2 shadow-sm focus-within:ring-1"
            style={{
              borderColor: "var(--border)",
              background: "var(--bg-elev)",
            }}
          >
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={onKeyDown}
              rows={1}
              placeholder="Message APIM Chat…"
              className="flex-1 resize-none bg-transparent py-1.5 text-[15px] outline-none placeholder:opacity-60"
              style={{ color: "var(--fg)" }}
            />
            {isBusy ? (
              <button
                type="button"
                onClick={stop}
                aria-label="Stop"
                className="grid size-8 place-items-center rounded-full transition"
                style={{ background: "var(--fg)", color: "var(--bg)" }}
              >
                <span className="block size-2.5 rounded-[2px] bg-current" />
              </button>
            ) : (
              <button
                type="submit"
                aria-label="Send"
                disabled={!input.trim()}
                className="grid size-8 place-items-center rounded-full transition disabled:opacity-30"
                style={{
                  background: "var(--accent)",
                  color: "var(--accent-fg)",
                }}
              >
                <svg viewBox="0 0 24 24" className="size-4" fill="currentColor">
                  <path d="M3.4 20.6 21 12 3.4 3.4 3 10l12 2-12 2 .4 6.6Z" />
                </svg>
              </button>
            )}
          </div>
          <p
            className="mt-2 text-center text-[11px]"
            style={{ color: "var(--fg-muted)" }}
          >
            Enter to send · Shift+Enter for newline
          </p>
        </form>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Message row
// ────────────────────────────────────────────────────────────────────────────

type ChatMessage = ReturnType<typeof useChat>["messages"][number];

function MessageRow({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && <Avatar kind="assistant" />}
      <div
        className={`max-w-[85%] ${isUser ? "order-1" : ""}`}
        style={{ minWidth: 0 }}
      >
        <div className="text-[11px] mb-1" style={{ color: "var(--fg-muted)" }}>
          {isUser ? "You" : "Assistant"}
        </div>
        <div
          className={`rounded-2xl px-4 py-3 text-[15px] leading-relaxed break-words ${
            isUser ? "rounded-tr-sm" : "rounded-tl-sm"
          }`}
          style={{
            background: isUser ? "var(--user-bg)" : "var(--bg-elev)",
            color: "var(--fg)",
          }}
        >
          {message.parts.map((part, i) => {
            if (part.type === "text") {
              return isUser ? (
                <span key={i} className="whitespace-pre-wrap">
                  {part.text}
                </span>
              ) : (
                <div key={i} className="md">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {part.text}
                  </ReactMarkdown>
                </div>
              );
            }
            if (part.type === "tool-invocation") {
              return <ToolCall key={i} part={part} />;
            }
            return null;
          })}
        </div>
      </div>
      {isUser && <Avatar kind="user" />}
    </div>
  );
}

function Avatar({ kind }: { kind: "user" | "assistant" }) {
  return (
    <div
      className="mt-5 grid size-7 shrink-0 place-items-center rounded-full text-[11px] font-semibold"
      style={{
        background: kind === "user" ? "var(--user-bg)" : "var(--accent)",
        color: kind === "user" ? "var(--fg)" : "var(--accent-fg)",
        border: kind === "user" ? "1px solid var(--border)" : "none",
      }}
    >
      {kind === "user" ? "You" : "AI"}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Collapsible tool-call row + entity-card renderer for tool results
// ────────────────────────────────────────────────────────────────────────────

type ToolPart = Extract<ChatMessage["parts"][number], { type: "tool-invocation" }>;

function ToolCall({ part }: { part: ToolPart }) {
  const inv = part.toolInvocation;
  const state = inv.state;
  const [open, setOpen] = useState(false);

  const isDone = state === "result";
  const statusLabel =
    state === "call" ? "calling…" : state === "result" ? "done" : state;

  // Pull tool result content (text payload from MCP) if available.
  const resultText: string | null =
    state === "result" && (inv as unknown as { result?: unknown }).result
      ? extractTextFromMcpResult((inv as unknown as { result: unknown }).result)
      : null;

  const entity = resultText ? tryParseEntity(resultText) : null;

  return (
    <div className="my-2 flex flex-col gap-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-left font-mono text-xs transition hover:opacity-90"
        style={{
          background: "var(--tool-bg)",
          borderColor: "var(--tool-border)",
        }}
      >
        <span
          className="inline-block size-1.5 rounded-full"
          style={{ background: isDone ? "var(--accent)" : "var(--fg-muted)" }}
        />
        <span className="font-semibold">{inv.toolName}</span>
        <span style={{ color: "var(--fg-muted)" }}>· {statusLabel}</span>
        <span className="ml-auto" style={{ color: "var(--fg-muted)" }}>
          {open ? "▾" : "▸"}
        </span>
      </button>

      {open && (
        <div
          className="rounded-md border px-3 py-2 font-mono text-xs"
          style={{
            background: "var(--tool-bg)",
            borderColor: "var(--tool-border)",
            color: "var(--fg-muted)",
          }}
        >
          {"args" in inv && inv.args ? (
            <div className="mb-1">args: {JSON.stringify(inv.args)}</div>
          ) : null}
          {resultText ? (
            <details>
              <summary className="cursor-pointer select-none">raw result</summary>
              <pre className="mt-1 max-h-64 overflow-auto whitespace-pre-wrap">
                {resultText}
              </pre>
            </details>
          ) : null}
        </div>
      )}

      {/* Rich entity card next to the tool call — visible always when we can detect one. */}
      {entity && <EntityCard data={entity} />}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Entity card rendering (Order, Customer, CustomerOrders list)
// ────────────────────────────────────────────────────────────────────────────

type Order = {
  kind: "order";
  id: string;
  customer?: string;
  status?: string;
  total?: number;
  currency?: string;
  items?: { sku: string; name: string; qty: number; price: number }[];
  shippingAddress?: {
    line1?: string;
    city?: string;
    region?: string;
    postalCode?: string;
    country?: string;
  };
};
type Customer = {
  kind: "customer";
  id: string;
  name?: string;
  email?: string;
  tier?: string;
  lifetimeValue?: number;
  currency?: string;
  phone?: string;
  address?: Record<string, string>;
};
type CustomerOrders = {
  kind: "customerOrders";
  customerId: string;
  orders: string[];
};
type CustomerList = {
  kind: "customerList";
  total?: number;
  items: Customer[];
};
type Entity = Order | Customer | CustomerOrders | CustomerList;

function extractTextFromMcpResult(result: unknown): string | null {
  // Streamable-HTTP MCP wraps results as { content: [{ type: "text", text: "..." }, ...] }
  if (!result || typeof result !== "object") return null;
  const r = result as Record<string, unknown>;
  const content = r.content;
  if (Array.isArray(content)) {
    const text = content
      .map((c) => (c && typeof c === "object" && (c as { text?: string }).text) || "")
      .filter(Boolean)
      .join("\n");
    if (text) return text;
  }
  if (typeof r.text === "string") return r.text;
  return null;
}

function tryParseEntity(text: string): Entity | null {
  let obj: unknown;
  try {
    obj = JSON.parse(text);
  } catch {
    return null;
  }
  if (!obj || typeof obj !== "object") return null;
  const o = obj as Record<string, unknown>;

  // CustomerList: { total, items: [Customer, ...] }
  if (Array.isArray(o.items) && (o.items as unknown[]).every(isCustomer)) {
    return {
      kind: "customerList",
      total: typeof o.total === "number" ? o.total : undefined,
      items: (o.items as unknown[]).map((c) =>
        toCustomer(c as Record<string, unknown>),
      ),
    };
  }

  // CustomerOrders: { customerId, orders: ["42", ...] }
  if (
    typeof o.customerId === "string" &&
    Array.isArray(o.orders) &&
    (o.orders as unknown[]).every((x) => typeof x === "string")
  ) {
    return {
      kind: "customerOrders",
      customerId: o.customerId,
      orders: o.orders as string[],
    };
  }

  // Order: has id + total + items (array of skus)
  if (
    typeof o.id === "string" &&
    typeof o.total === "number" &&
    Array.isArray(o.items)
  ) {
    return {
      kind: "order",
      id: o.id,
      customer: typeof o.customer === "string" ? o.customer : undefined,
      status: typeof o.status === "string" ? o.status : undefined,
      total: o.total,
      currency: typeof o.currency === "string" ? o.currency : undefined,
      items: (o.items as unknown[])
        .filter((it): it is Record<string, unknown> => !!it && typeof it === "object")
        .map((it) => ({
          sku: String(it.sku ?? ""),
          name: String(it.name ?? ""),
          qty: Number(it.qty ?? 0),
          price: Number(it.price ?? 0),
        })),
      shippingAddress:
        o.shippingAddress && typeof o.shippingAddress === "object"
          ? (o.shippingAddress as Order["shippingAddress"])
          : undefined,
    };
  }

  // Customer: has id + tier
  if (isCustomer(o)) {
    return toCustomer(o);
  }

  return null;
}

function isCustomer(c: unknown): boolean {
  if (!c || typeof c !== "object") return false;
  const o = c as Record<string, unknown>;
  return typeof o.id === "string" && typeof o.tier === "string";
}
function toCustomer(o: Record<string, unknown>): Customer {
  return {
    kind: "customer",
    id: String(o.id),
    name: typeof o.name === "string" ? o.name : undefined,
    email: typeof o.email === "string" ? o.email : undefined,
    tier: typeof o.tier === "string" ? o.tier : undefined,
    lifetimeValue:
      typeof o.lifetimeValue === "number" ? o.lifetimeValue : undefined,
    currency: typeof o.currency === "string" ? o.currency : undefined,
    phone: typeof o.phone === "string" ? o.phone : undefined,
    address:
      o.address && typeof o.address === "object"
        ? (o.address as Record<string, string>)
        : undefined,
  };
}

function EntityCard({ data }: { data: Entity }) {
  if (data.kind === "order") return <OrderCard order={data} />;
  if (data.kind === "customer") return <CustomerCard customer={data} />;
  if (data.kind === "customerOrders") return <OrderListCard data={data} />;
  if (data.kind === "customerList") return <CustomerListCard data={data} />;
  return null;
}

function money(n?: number, currency = "USD") {
  if (typeof n !== "number") return "—";
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency,
    }).format(n);
  } catch {
    return `$${n.toFixed(2)}`;
  }
}

function StatusPill({ value }: { value?: string }) {
  if (!value) return null;
  const cls = `pill pill-${value.toLowerCase()}`;
  return <span className={cls}>{value}</span>;
}

function Card({
  title,
  subtitle,
  children,
}: {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <div
      className="rounded-xl border p-4 shadow-sm"
      style={{
        background: "var(--bg)",
        borderColor: "var(--border)",
      }}
    >
      <div className="mb-2 flex items-start justify-between gap-3">
        <div>
          <div className="text-[13px] font-semibold">{title}</div>
          {subtitle && (
            <div className="text-xs" style={{ color: "var(--fg-muted)" }}>
              {subtitle}
            </div>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

function OrderCard({ order }: { order: Order }) {
  return (
    <Card
      title={
        <div className="flex items-center gap-2">
          <span>Order #{order.id}</span>
          <StatusPill value={order.status} />
        </div>
      }
      subtitle={order.customer ? `Customer: ${order.customer}` : undefined}
    >
      <div className="mb-3 flex items-baseline gap-3">
        <span
          className="text-[11px] uppercase tracking-wide"
          style={{ color: "var(--fg-muted)" }}
        >
          Total
        </span>
        <span className="text-xl font-semibold">
          {money(order.total, order.currency)}
        </span>
      </div>

      {order.items && order.items.length > 0 && (
        <div className="mb-3">
          <div
            className="mb-1 text-[11px] uppercase tracking-wide"
            style={{ color: "var(--fg-muted)" }}
          >
            Items
          </div>
          <ul className="text-sm" style={{ color: "var(--fg)" }}>
            {order.items.map((it, i) => (
              <li key={i} className="flex justify-between gap-3 py-0.5">
                <span>
                  {it.name}{" "}
                  <span style={{ color: "var(--fg-muted)" }}>×{it.qty}</span>
                </span>
                <span style={{ color: "var(--fg-muted)" }}>
                  {money(it.price, order.currency)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {order.shippingAddress && (
        <div>
          <div
            className="mb-0.5 text-[11px] uppercase tracking-wide"
            style={{ color: "var(--fg-muted)" }}
          >
            Ship to
          </div>
          <div className="text-sm leading-snug">
            {[
              order.shippingAddress.line1,
              [
                order.shippingAddress.city,
                order.shippingAddress.region,
                order.shippingAddress.postalCode,
              ]
                .filter(Boolean)
                .join(", "),
              order.shippingAddress.country,
            ]
              .filter(Boolean)
              .map((line, i) => (
                <div key={i}>{line}</div>
              ))}
          </div>
        </div>
      )}
    </Card>
  );
}

function initials(name?: string) {
  if (!name) return "?";
  return name
    .split(/\s+/)
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function CustomerCard({ customer }: { customer: Customer }) {
  return (
    <Card
      title={
        <div className="flex items-center gap-3">
          <span
            className="grid size-7 place-items-center rounded-full text-[11px] font-semibold"
            style={{ background: "var(--accent)", color: "var(--accent-fg)" }}
          >
            {initials(customer.name)}
          </span>
          <span>{customer.name ?? customer.id}</span>
          <StatusPill value={customer.tier} />
        </div>
      }
      subtitle={`ID: ${customer.id}${customer.email ? ` · ${customer.email}` : ""}`}
    >
      <div className="grid grid-cols-2 gap-3 text-sm">
        {typeof customer.lifetimeValue === "number" && (
          <div>
            <div
              className="text-[11px] uppercase tracking-wide"
              style={{ color: "var(--fg-muted)" }}
            >
              Lifetime value
            </div>
            <div className="text-lg font-semibold">
              {money(customer.lifetimeValue, customer.currency)}
            </div>
          </div>
        )}
        {customer.phone && (
          <div>
            <div
              className="text-[11px] uppercase tracking-wide"
              style={{ color: "var(--fg-muted)" }}
            >
              Phone
            </div>
            <div>{customer.phone}</div>
          </div>
        )}
      </div>
    </Card>
  );
}

function OrderListCard({ data }: { data: CustomerOrders }) {
  return (
    <Card
      title={`Orders for ${data.customerId}`}
      subtitle={`${data.orders.length} order${data.orders.length === 1 ? "" : "s"}`}
    >
      <div className="flex flex-wrap gap-2">
        {data.orders.map((id) => (
          <span
            key={id}
            className="rounded-md border px-2 py-1 text-xs font-mono"
            style={{
              background: "var(--bg-elev)",
              borderColor: "var(--border)",
            }}
          >
            #{id}
          </span>
        ))}
      </div>
    </Card>
  );
}

function CustomerListCard({ data }: { data: CustomerList }) {
  return (
    <Card
      title="Customers"
      subtitle={
        typeof data.total === "number"
          ? `${data.items.length} of ${data.total}`
          : `${data.items.length} result${data.items.length === 1 ? "" : "s"}`
      }
    >
      <div className="flex flex-col gap-2">
        {data.items.map((c) => (
          <div
            key={c.id}
            className="flex items-center justify-between gap-3 rounded-md border px-3 py-2"
            style={{
              background: "var(--bg-elev)",
              borderColor: "var(--border)",
            }}
          >
            <div className="flex items-center gap-3">
              <span
                className="grid size-7 place-items-center rounded-full text-[11px] font-semibold"
                style={{
                  background: "var(--accent)",
                  color: "var(--accent-fg)",
                }}
              >
                {initials(c.name)}
              </span>
              <div>
                <div className="text-sm font-medium">{c.name ?? c.id}</div>
                <div
                  className="text-[11px]"
                  style={{ color: "var(--fg-muted)" }}
                >
                  {c.id}
                  {c.email ? ` · ${c.email}` : ""}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <StatusPill value={c.tier} />
              <div className="text-sm font-semibold">
                {money(c.lifetimeValue, c.currency)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
