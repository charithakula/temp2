// Test-connection endpoint: probes an MCP endpoint (URL + auth header/value)
// without saving anything. Used by /settings before the user clicks Save.

import { experimental_createMCPClient } from "ai";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

type TestBody = {
  url: string;
  authHeader?: string;
  authValue?: string;
  authEnv?: string;
};

export async function POST(req: Request) {
  const body = (await req.json()) as TestBody;
  if (!body?.url) {
    return Response.json({ ok: false, error: "url is required" }, { status: 400 });
  }
  let parsed: URL;
  try {
    parsed = new URL(body.url);
  } catch {
    return Response.json({ ok: false, error: "url is invalid" }, { status: 400 });
  }

  const headers: Record<string, string> = {};
  if (body.authHeader) {
    const value = body.authValue ?? (body.authEnv ? process.env[body.authEnv] : undefined);
    if (value) headers[body.authHeader] = value;
  }

  const startedAt = Date.now();
  try {
    const transport = new StreamableHTTPClientTransport(parsed, {
      requestInit: { headers },
    });
    const client = await experimental_createMCPClient({ transport });
    const tools = await client.tools();
    const toolNames = Object.keys(tools);
    await client.close();
    return Response.json({
      ok: true,
      latencyMs: Date.now() - startedAt,
      tools: toolNames,
    });
  } catch (err) {
    return Response.json(
      {
        ok: false,
        latencyMs: Date.now() - startedAt,
        error: err instanceof Error ? err.message : String(err),
      },
      { status: 200 },
    );
  }
}
