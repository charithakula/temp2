import { deleteServer, getServers, updateServer, type McpServer } from "@/lib/mcp-store";

type Ctx = { params: Promise<{ name: string }> };

export async function PUT(req: Request, ctx: Ctx) {
  const { name } = await ctx.params;
  const body = (await req.json()) as Partial<McpServer>;
  const result = await updateServer(name, body);
  if (!result.ok) {
    return Response.json({ error: result.error }, { status: 400 });
  }
  const servers = await getServers();
  return Response.json({ servers });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const { name } = await ctx.params;
  const result = await deleteServer(name);
  if (!result.ok) {
    return Response.json({ error: result.error }, { status: 404 });
  }
  const servers = await getServers();
  return Response.json({ servers });
}
