import { addServer, getServers, type McpServer } from "@/lib/mcp-store";

export async function GET() {
  const servers = await getServers();
  return Response.json({ servers });
}

export async function POST(req: Request) {
  const body = (await req.json()) as McpServer;
  const result = await addServer(body);
  if (!result.ok) {
    return Response.json({ error: result.error }, { status: 400 });
  }
  const servers = await getServers();
  return Response.json({ servers });
}
