import { createAzure } from "@ai-sdk/azure";
import {
  convertToModelMessages,
  jsonSchema,
  stepCountIs,
  streamText,
  tool,
  type ToolSet,
  type UIMessage,
} from "ai";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

export const maxDuration = 60;

// ─────────────────────────────────────────────────────────────────────────────
// Azure OpenAI
// ─────────────────────────────────────────────────────────────────────────────
const endpoint = (process.env.AZURE_OPENAI_ENDPOINT ?? "").replace(/\/+$/, "");
// @ai-sdk/azure@3 changed URL construction: by default it now hits the v1
// Responses API. We use the older Chat Completions API instead because the
// gpt-5.2-chat deployment is configured for it. With useDeploymentBasedUrls:
//   `${baseURL}/deployments/{deploymentName}/chat/completions?api-version=...`
// So baseURL must end at `/openai`, not `/openai/deployments`.
const azure = createAzure({
  apiKey: process.env.AZURE_OPENAI_API_KEY,
  apiVersion: process.env.AZURE_OPENAI_API_VERSION,
  baseURL: `${endpoint}/openai`,
  useDeploymentBasedUrls: true,
});

// ─────────────────────────────────────────────────────────────────────────────
// MCP server configuration
// ─────────────────────────────────────────────────────────────────────────────
// Read from data/mcp-servers.json (managed via /settings). Falls back to env
// vars on first boot when the file is empty.
import { buildHeaders, getServers, type McpServer } from "@/lib/mcp-store";

function loadLegacyEnvServers(): McpServer[] {
  const raw = process.env.MCP_SERVERS_JSON?.trim();
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as McpServer[];
      if (Array.isArray(parsed)) return parsed.filter((s) => s && s.name && s.url);
    } catch {
      /* ignore */
    }
  }
  const url = process.env.MCP_SERVER_URL;
  if (!url) return [];
  return [
    {
      name: "default",
      url,
      authHeader: "Ocp-Apim-Subscription-Key",
      authEnv: "APIM_SUBSCRIPTION_KEY",
    },
  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Connect to an MCP server and convert its tools into AI SDK tool definitions.
// In AI SDK v6 the `experimental_createMCPClient` helper was removed — we use
// the official @modelcontextprotocol/sdk client directly and convert each tool
// into one created with the AI SDK's `tool()` helper.
// ─────────────────────────────────────────────────────────────────────────────

type McpTool = {
  name: string;
  description?: string;
  inputSchema: Record<string, unknown>;
};

// Azure OpenAI's strict function-calling mode requires every property in a
// tool's input schema to appear in `required` and `additionalProperties:false`
// on every object node. Some APIM-generated MCP tool schemas don't comply.
function sanitizeSchemaForAzureStrict(schema: unknown): unknown {
  if (schema === null || typeof schema !== "object") return schema;
  if (Array.isArray(schema)) return schema.map(sanitizeSchemaForAzureStrict);
  const out: Record<string, unknown> = { ...(schema as Record<string, unknown>) };
  const type = out.type;
  const props = out.properties;
  if (type === "object" && props && typeof props === "object") {
    out.properties = Object.fromEntries(
      Object.entries(props as Record<string, unknown>).map(([k, v]) => [
        k,
        sanitizeSchemaForAzureStrict(v),
      ]),
    );
    out.required = Object.keys(out.properties as Record<string, unknown>);
    out.additionalProperties = false;
  }
  if (out.items) out.items = sanitizeSchemaForAzureStrict(out.items);
  return out;
}

async function connectAndBuildTools(s: McpServer) {
  const transport = new StreamableHTTPClientTransport(new URL(s.url), {
    requestInit: { headers: buildHeaders(s) },
  });
  const client = new Client(
    { name: "apim-chat-ui", version: "0.1.0" },
    { capabilities: {} },
  );
  await client.connect(transport);
  const listed = await client.listTools();
  const tools: ToolSet = {};

  for (const t of listed.tools as unknown as McpTool[]) {
    const namespaced = `${s.name}.${t.name}`;
    const sanitized = sanitizeSchemaForAzureStrict(t.inputSchema);
    tools[namespaced] = tool({
      description: t.description ?? "",
      inputSchema: jsonSchema(sanitized as Parameters<typeof jsonSchema>[0]),
      execute: async (args: unknown) => {
        const startedAt = Date.now();
        try {
          const result = await client.callTool({
            name: t.name,
            arguments: (args as Record<string, unknown>) ?? {},
          });
          const ms = Date.now() - startedAt;
          console.log(
            `[tool] server=${s.name} tool=${t.name} status=ok durationMs=${ms}`,
          );
          // Return the MCP content directly; the AI SDK serializes it.
          return result.content;
        } catch (err) {
          const ms = Date.now() - startedAt;
          console.error(
            `[tool] server=${s.name} tool=${t.name} status=error durationMs=${ms} err=${
              err instanceof Error ? err.message : String(err)
            }`,
          );
          throw err;
        }
      },
    });
  }

  return { server: s, client, tools };
}

// ─────────────────────────────────────────────────────────────────────────────
// Route
// ─────────────────────────────────────────────────────────────────────────────

export async function POST(req: Request) {
  const { messages } = (await req.json()) as { messages: UIMessage[] };
  const turnStartedAt = Date.now();

  let mcpServers: McpServer[] = (await getServers()).filter((s) => !s.disabled);
  if (mcpServers.length === 0) {
    mcpServers = loadLegacyEnvServers();
  }

  const clients = await Promise.all(
    mcpServers.map(async (s) => {
      try {
        return await connectAndBuildTools(s);
      } catch (err) {
        console.error(
          `[mcp] failed to connect server=${s.name} url=${s.url}: ${
            err instanceof Error ? err.message : String(err)
          }`,
        );
        return null;
      }
    }),
  );
  type LiveClient = Awaited<ReturnType<typeof connectAndBuildTools>>;
  const live = clients.filter((c): c is LiveClient => c !== null);

  const tools: ToolSet = live.reduce<ToolSet>(
    (acc, c) => ({ ...acc, ...c.tools }),
    {},
  );

  console.log(
    `[chat] turn start servers=${live.length}/${mcpServers.length} tools=${
      Object.keys(tools).length
    }`,
  );

  const result = streamText({
    // azure.chat() = Chat Completions API. azure() (or azure.responses()) =
    // newer Responses API, which this deployment isn't configured for.
    model: azure.chat(process.env.AZURE_OPENAI_DEPLOYMENT ?? "gpt-5.2-chat"),
    system:
      "You are an enterprise assistant that answers questions by calling the " +
      "available tools. Tools are namespaced as `<server>.<tool>` — pick the " +
      "one whose name and description fit the user's request. Summarize results clearly.",
    messages: await convertToModelMessages(messages),
    tools,
    stopWhen: stepCountIs(5),
    onFinish: async () => {
      const ms = Date.now() - turnStartedAt;
      console.log(`[chat] turn done durationMs=${ms}`);
      await Promise.all(
        live.map((c) =>
          c.client.close().catch((err: unknown) =>
            console.error(`[mcp] close error server=${c.server.name}: ${err}`),
          ),
        ),
      );
    },
  });

  return result.toUIMessageStreamResponse({
    onError: (error: unknown) => {
      console.error("streamText error:", error);
      return error instanceof Error ? error.message : String(error);
    },
  });
}
