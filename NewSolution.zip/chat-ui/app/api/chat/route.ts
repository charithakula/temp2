import { createAzure } from "@ai-sdk/azure";
import { experimental_createMCPClient, jsonSchema, streamText } from "ai";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

export const maxDuration = 60;

// The AI SDK's MCP `tools()` returns a dictionary whose value type embeds
// generics we don't need to constrain here. Treat each entry as opaque so we
// can spread + override `execute` without fighting the SDK's internal types.
type AnyTool = Record<string, unknown> & {
  execute?: (args: unknown, options: unknown) => Promise<unknown>;
};
type ToolDict = Record<string, AnyTool>;

// ─────────────────────────────────────────────────────────────────────────────
// Azure OpenAI
// ─────────────────────────────────────────────────────────────────────────────
const endpoint = (process.env.AZURE_OPENAI_ENDPOINT ?? "").replace(/\/+$/, "");
const azure = createAzure({
  apiKey: process.env.AZURE_OPENAI_API_KEY,
  apiVersion: process.env.AZURE_OPENAI_API_VERSION,
  baseURL: `${endpoint}/openai/deployments`,
});

// ─────────────────────────────────────────────────────────────────────────────
// MCP server configuration
// ─────────────────────────────────────────────────────────────────────────────
// The MCP server list lives in chat-ui/data/mcp-servers.json and is managed
// via the /settings page (and /api/mcp-servers endpoints).
// Changes take effect on the NEXT chat turn — no restart needed.
//
// As a safety net for first boot, if the file is empty we fall back to
// MCP_SERVERS_JSON / MCP_SERVER_URL env vars (legacy single-MCP shape).
import { buildHeaders, getServers, type McpServer } from "@/lib/mcp-store";

function loadLegacyEnvServers(): McpServer[] {
  const raw = process.env.MCP_SERVERS_JSON?.trim();
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as McpServer[];
      if (Array.isArray(parsed)) return parsed.filter((s) => s && s.name && s.url);
    } catch {
      /* ignore */
    }
  }
  const url = process.env.MCP_SERVER_URL;
  if (!url) return [];
  return [
    {
      name: "default",
      url,
      authHeader: "Ocp-Apim-Subscription-Key",
      authEnv: "APIM_SUBSCRIPTION_KEY",
    },
  ];
}

async function connectMcp(s: McpServer) {
  const transport = new StreamableHTTPClientTransport(new URL(s.url), {
    requestInit: { headers: buildHeaders(s) },
  });
  return experimental_createMCPClient({ transport });
}

// Azure OpenAI's strict function-calling mode requires every property in a
// tool's input schema to appear in `required`, with `additionalProperties:false`
// on every object. Some MCP tools (e.g. APIM-generated tools with optional
// query params) ship `required: []`, which Azure rejects with a 400 — and
// that single bad schema kills the WHOLE chat-completions call.
//
// We sanitize the JSON Schema before handing tools to streamText:
//   • promote every property into `required`
//   • force `additionalProperties: false` on every object node
function sanitizeSchemaForAzureStrict(schema: unknown): unknown {
  if (schema === null || typeof schema !== "object") return schema;
  if (Array.isArray(schema)) return schema.map(sanitizeSchemaForAzureStrict);

  const out: Record<string, unknown> = { ...(schema as Record<string, unknown>) };
  const type = out.type;
  const props = out.properties;
  if (type === "object" && props && typeof props === "object") {
    out.properties = Object.fromEntries(
      Object.entries(props as Record<string, unknown>).map(([k, v]) => [
        k,
        sanitizeSchemaForAzureStrict(v),
      ]),
    );
    out.required = Object.keys(out.properties as Record<string, unknown>);
    out.additionalProperties = false;
  }
  if (out.items) out.items = sanitizeSchemaForAzureStrict(out.items);
  return out;
}

// Best-effort extraction of the original JSON Schema from an MCP tool object.
// The AI SDK stores it under a few possible keys depending on version.
function extractRawSchema(t: AnyTool): unknown {
  const candidates = ["inputSchema", "parameters", "schema"] as const;
  for (const k of candidates) {
    const v = (t as Record<string, unknown>)[k];
    if (v && typeof v === "object") {
      // If it looks like a Zod schema (no `type` field), skip.
      const obj = v as Record<string, unknown>;
      if (typeof obj.jsonSchema === "object") return obj.jsonSchema;
      if (typeof obj.type === "string") return obj;
    }
  }
  return null;
}

// For each MCP tool: prefix its name with the server name, sanitize the
// input schema for Azure strict mode, then wrap `execute` with timing + logging.
function namespaceAndInstrumentTools(serverName: string, rawTools: ToolDict): ToolDict {
  const out: ToolDict = {};
  for (const [toolName, original] of Object.entries(rawTools)) {
    const namespaced = `${serverName}.${toolName}`;
    const originalExecute = original.execute?.bind(original);

    // Replace `parameters` with a fresh, Azure-strict-compliant JSON Schema
    // wrapped in jsonSchema() so the AI SDK uses it as-is.
    const raw = extractRawSchema(original);
    const sanitizedParameters = raw
      ? jsonSchema(sanitizeSchemaForAzureStrict(raw) as Parameters<typeof jsonSchema>[0])
      : (original as Record<string, unknown>).parameters;

    out[namespaced] = {
      ...original,
      parameters: sanitizedParameters,
      ...(originalExecute && {
        execute: async (args: unknown, options: unknown) => {
          const startedAt = Date.now();
          try {
            const result = await originalExecute(args, options);
            const ms = Date.now() - startedAt;
            console.log(
              `[tool] server=${serverName} tool=${toolName} status=ok durationMs=${ms}`,
            );
            return result;
          } catch (err) {
            const ms = Date.now() - startedAt;
            console.error(
              `[tool] server=${serverName} tool=${toolName} status=error durationMs=${ms} err=${
                err instanceof Error ? err.message : String(err)
              }`,
            );
            throw err;
          }
        },
      }),
    };
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Route
// ─────────────────────────────────────────────────────────────────────────────

export async function POST(req: Request) {
  const { messages } = await req.json();
  const turnStartedAt = Date.now();

  // Read the MCP list at the start of every turn so changes made via the
  // /settings UI take effect immediately, without a server restart. If the
  // store is empty (first boot), fall back to env-var configuration.
  let mcpServers: McpServer[] = (await getServers()).filter((s) => !s.disabled);
  if (mcpServers.length === 0) {
    mcpServers = loadLegacyEnvServers();
  }

  // Connect to every MCP in parallel, pull each one's tool list, namespace +
  // instrument them, then merge into a single dictionary the LLM sees.
  const clients = await Promise.all(
    mcpServers.map(async (s: McpServer) => {
      try {
        const client = await connectMcp(s);
        const rawTools = (await client.tools()) as unknown as ToolDict;
        return { server: s, client, tools: namespaceAndInstrumentTools(s.name, rawTools) };
      } catch (err) {
        console.error(
          `[mcp] failed to connect server=${s.name} url=${s.url}: ${
            err instanceof Error ? err.message : String(err)
          }`,
        );
        return null;
      }
    }),
  );
  type LiveClient = {
    server: McpServer;
    client: Awaited<ReturnType<typeof connectMcp>>;
    tools: ToolDict;
  };
  const live = clients.filter((c): c is LiveClient => c !== null);

  const tools = live.reduce<ToolDict>(
    (acc: ToolDict, c: LiveClient) => ({ ...acc, ...c.tools }),
    {},
  );

  console.log(
    `[chat] turn start servers=${live.length}/${mcpServers.length} tools=${
      Object.keys(tools).length
    }`,
  );

  const result = streamText({
    model: azure(process.env.AZURE_OPENAI_DEPLOYMENT ?? "gpt-5.2-chat"),
    system:
      "You are an enterprise assistant that answers questions by calling the " +
      "available tools. Tools are namespaced as `<server>.<tool>` — pick the " +
      "one whose name and description fit the user's request. Summarize results clearly.",
    messages,
    // Cast to the AI SDK's expected shape; we deliberately keep tools opaque
    // above so we don't have to mirror the SDK's internal generics.
    tools: tools as unknown as Parameters<typeof streamText>[0]["tools"],
    maxSteps: 5,
    onFinish: async () => {
      const ms = Date.now() - turnStartedAt;
      console.log(`[chat] turn done durationMs=${ms}`);
      await Promise.all(
        live.map((c: LiveClient) =>
          c.client.close().catch((err: unknown) =>
            console.error(`[mcp] close error server=${c.server.name}: ${err}`),
          ),
        ),
      );
    },
  });

  return result.toDataStreamResponse({
    getErrorMessage: (error) => {
      console.error("streamText error:", error);
      return error instanceof Error ? error.message : String(error);
    },
  });
}
