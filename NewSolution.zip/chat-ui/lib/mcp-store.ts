// Server-only file-backed store for the list of MCP servers.
// The /settings UI reads/writes via /api/mcp-servers; /api/chat reads via getServers().
//
// Storage choice: a single JSON file under chat-ui/data/. For dev/demo this is
// the simplest persistent option (survives restarts, works without infra).
// For production swap the read/write internals for Cosmos DB / Key Vault.

import { promises as fs } from "node:fs";
import path from "node:path";

const DATA_DIR = path.join(process.cwd(), "data");
const FILE_PATH = path.join(DATA_DIR, "mcp-servers.json");

export type McpServer = {
  name: string;          // tool-name prefix, must be unique
  url: string;           // Streamable-HTTP MCP endpoint
  authHeader?: string;   // e.g. "Ocp-Apim-Subscription-Key"
  authValue?: string;    // raw key value (dev mode)
  authEnv?: string;      // legacy: env-var name holding the key value
  disabled?: boolean;    // skip without removing from the list
};

type StoreShape = { servers: McpServer[] };

let writeLock: Promise<void> = Promise.resolve();

async function ensureFile(): Promise<void> {
  try {
    await fs.access(FILE_PATH);
  } catch {
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.writeFile(FILE_PATH, JSON.stringify({ servers: [] }, null, 2), "utf8");
  }
}

async function readRaw(): Promise<StoreShape> {
  await ensureFile();
  const text = await fs.readFile(FILE_PATH, "utf8");
  try {
    const parsed = JSON.parse(text) as StoreShape;
    if (!parsed || !Array.isArray(parsed.servers)) return { servers: [] };
    return parsed;
  } catch {
    return { servers: [] };
  }
}

async function writeRaw(data: StoreShape): Promise<void> {
  // Serialize writes so two concurrent saves can't interleave.
  writeLock = writeLock.then(async () => {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const tmp = FILE_PATH + ".tmp";
    await fs.writeFile(tmp, JSON.stringify(data, null, 2), "utf8");
    await fs.rename(tmp, FILE_PATH);
  });
  await writeLock;
}

function validate(s: Partial<McpServer>): string | null {
  if (!s.name || !/^[a-z0-9_-]+$/i.test(s.name))
    return "name must be alphanumeric (letters, digits, _ or -)";
  if (!s.url) return "url is required";
  try {
    new URL(s.url);
  } catch {
    return "url is not a valid URL";
  }
  return null;
}

export async function getServers(): Promise<McpServer[]> {
  const data = await readRaw();
  return data.servers;
}

export async function addServer(s: McpServer): Promise<{ ok: true } | { ok: false; error: string }> {
  const err = validate(s);
  if (err) return { ok: false, error: err };
  const data = await readRaw();
  if (data.servers.some((x) => x.name === s.name))
    return { ok: false, error: `a server named "${s.name}" already exists` };
  data.servers.push(s);
  await writeRaw(data);
  return { ok: true };
}

export async function updateServer(
  name: string,
  patch: Partial<McpServer>,
): Promise<{ ok: true } | { ok: false; error: string }> {
  const data = await readRaw();
  const i = data.servers.findIndex((x) => x.name === name);
  if (i === -1) return { ok: false, error: `server "${name}" not found` };
  const merged = { ...data.servers[i], ...patch };
  // If they renamed, validate the new name doesn't collide.
  if (patch.name && patch.name !== name) {
    if (data.servers.some((x, j) => j !== i && x.name === patch.name))
      return { ok: false, error: `a server named "${patch.name}" already exists` };
  }
  const err = validate(merged);
  if (err) return { ok: false, error: err };
  data.servers[i] = merged;
  await writeRaw(data);
  return { ok: true };
}

export async function deleteServer(name: string): Promise<{ ok: true } | { ok: false; error: string }> {
  const data = await readRaw();
  const before = data.servers.length;
  data.servers = data.servers.filter((x) => x.name !== name);
  if (data.servers.length === before) return { ok: false, error: `server "${name}" not found` };
  await writeRaw(data);
  return { ok: true };
}

// Helper used by /api/chat: convert each server into the (url, headers) pair.
export function buildHeaders(s: McpServer): Record<string, string> {
  if (!s.authHeader) return {};
  const value = s.authValue ?? (s.authEnv ? process.env[s.authEnv] : undefined);
  return value ? { [s.authHeader]: value } : {};
}
