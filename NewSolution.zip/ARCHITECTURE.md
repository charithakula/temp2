# Architecture

This document explains how the pieces fit together — what runs where, why,
and how a single chat message flows through the system.

---

## Component map

```
┌────────────────────────────────────────────────────────────────────┐
│  Browser                                                            │
│  • Next.js client UI (React)                                        │
│  • Vercel AI SDK useChat() — streams tokens, renders tool cards     │
└──────────────────────────────┬─────────────────────────────────────┘
                               │  POST /api/chat        (event-stream)
                               ▼
┌────────────────────────────────────────────────────────────────────┐
│  Next.js API route  (Backend-For-Frontend)                          │
│  app/api/chat/route.ts                                              │
│  • Holds the Azure OpenAI key (server-only, never sent to browser)  │
│  • Builds the MCP client                                            │
│  • Runs the tool-calling loop via streamText({ tools, maxSteps })   │
└────┬───────────────────────────────────────────┬───────────────────┘
     │                                           │
     │  HTTPS (api-key)                          │  MCP Streamable-HTTP
     │                                           │  POST .../ordersmcp/mcp
     │                                           │  header: Ocp-Apim-Subscription-Key
     ▼                                           ▼
┌─────────────────────────────┐    ┌──────────────────────────────────┐
│  Azure OpenAI               │    │  Azure APIM — MCP server          │
│  gpt-5.2-chat deployment    │    │  (native preview feature)         │
│  .cognitiveservices.azure   │    │                                   │
│  .com/openai/deployments/…  │    │  Translates MCP JSON-RPC →        │
│                             │    │  internal HTTP call to operation  │
└─────────────────────────────┘    └────────────────┬─────────────────┘
                                                    │
                                                    │  (internal, same APIM)
                                                    ▼
                                    ┌──────────────────────────────────┐
                                    │  Orders API · GET /orders/{id}   │
                                    │  Imported from OpenAPI YAML      │
                                    │  Inbound policy: return-response │
                                    │  → mock JSON, no backend         │
                                    └──────────────────────────────────┘
```

> **APIM is in the path twice** — once as the MCP server entry point, and a
> second internal hop as the regular API gateway. This is by design: every
> existing APIM policy (auth, throttling, logging, masking) applies to MCP
> tool calls automatically. No extra work.

---

## Components — what and why

### 1. Browser UI ([chat-ui/app/page.tsx](chat-ui/app/page.tsx))

- **Tech**: React 19, Next.js 15, Vercel AI SDK (`@ai-sdk/react`).
- **Job**: Render the conversation. Stream assistant tokens. Display
  tool-call cards as they happen.
- **What it does NOT do**: never holds secrets. Never calls Azure OpenAI or
  APIM directly. Everything goes through `/api/chat`.

### 2. Next.js API route ([chat-ui/app/api/chat/route.ts](chat-ui/app/api/chat/route.ts))

This is the **Backend-For-Frontend** (BFF). The only server-side code we
write. It does three things on every chat turn:

1. **Connect to the MCP server.** Uses the official
   `@modelcontextprotocol/sdk` Streamable-HTTP transport (required because
   APIM exposes the modern MCP transport, not the older SSE one). Sends the
   APIM subscription key as a header on every MCP request.
2. **Pull the tool list** from APIM via MCP `tools/list`. The AI SDK
   converts each MCP tool definition into an LLM-callable tool.
3. **Run the streamed chat loop.** `streamText({ model, tools, maxSteps })`
   lets the model call tools, get results, and continue — all streamed to
   the browser.

Why a route handler and not a separate FastAPI service? Because there is
**nothing application-specific** here. The route is a 50-line glue layer —
adding a Python service in front would just be another hop.

### 3. Azure OpenAI — `gpt-5.2-chat`

- Receives the message history + the tool list pulled from APIM.
- Decides whether to call a tool (returns a `tool_calls` block) or reply.
- Tool schemas use JSON Schema **strict** mode (`additionalProperties: false`,
  every property in `required`). APIM-generated MCP tool schemas already
  satisfy this — that's why the native MCP path "just works", whereas our
  earlier hand-written Python tools needed schema tweaks.

### 4. Azure APIM — the API Gateway

Standard v2 instance. Hosts:

- **The Orders API** — imported from
  [sample-orders-api.openapi.yaml](sample-orders-api.openapi.yaml). One
  operation: `GET /orders/{id}`. No real backend; the inbound policy
  returns a deterministic JSON body using
  [apim-policy-return-response.xml](apim-policy-return-response.xml).
- **The MCP server** — the native "Expose API as MCP server" preview
  feature. Re-exposes the Orders API as MCP tools at
  `https://ai-apim-1234.azure-api.net/ordersmcp/mcp`. Tool metadata is
  auto-generated from the OpenAPI definition; APIM derives:
  - tool name from `operationId` (`getOrder` → `getAnOrderById` per APIM's slug)
  - description from `summary` / `description`
  - input schema from `parameters` (+ request body if present)

---

## Request flow — what happens when you send "Get order 42"

```
1. Browser  → POST /api/chat                                        (Next.js)
   { messages: [{role:"user", content:"Get order 42"}] }

2. Next.js  → MCP initialize + tools/list                           (APIM-MCP)
   POST https://ai-apim-1234.azure-api.net/ordersmcp/mcp
   header: Ocp-Apim-Subscription-Key
   → returns 1 tool: getAnOrderById(id: string)

3. Next.js  → Azure OpenAI chat/completions (streaming)             (AOAI)
   messages + tools=[getAnOrderById]
   ← model decides: call getAnOrderById({id:"42"})

4. Next.js  → MCP tools/call                                        (APIM-MCP)
   POST ordersmcp/mcp  {method:"tools/call", name:"getAnOrderById", args:{id:"42"}}
   APIM internally calls Orders API → GET /orders/42
   → return-response policy fires → JSON body
   ← MCP wraps in { content:[{ type:"text", text:"{...}" }] }

5. Next.js  → Azure OpenAI chat/completions (streaming)             (AOAI)
   messages + previous tool_call + tool result
   ← model streams text: "Here are the details for order 42..."

6. Next.js  → Browser                                               (stream)
   Server-Sent Event stream of text + tool-call metadata.
   useChat() renders tokens + tool-card live.
```

Steps 3 and 5 can repeat (up to `maxSteps: 5`) if the model wants to call
more tools (e.g. "compare orders 7 and 100" → two `tools/call` rounds).

---

## Why this architecture (instead of FastAPI/FastMCP in the middle)

Briefly — see longer treatment in conversation notes:

| Concern | This architecture (direct APIM-MCP) | If we added FastAPI/FastMCP |
|---|---|---|
| Auth, rate limit, logging | Centralized in APIM | Duplicated in two layers |
| Add a new tool | Import an API operation; **zero code** | Code change + redeploy |
| Schema drift | Impossible (single source: OpenAPI) | Two definitions to keep in sync |
| Failure surface | 1 service we own (Next.js) | 2 services we own |
| Cost | Just APIM + AOAI | APIM + AOAI + App Service / container |

We add a FastMCP server **only** when we need tools that can't be expressed
as a single APIM operation — for example a tool that joins 3 APIs into one,
or that queries a database the LLM can't reach through APIM. In that case
FastMCP runs *beside* APIM-MCP, not in front of it; the AI SDK merges the
tool lists from both servers.

We add a FastAPI service **only** when we need application logic that isn't
the LLM loop — auth/session, our own database, RAG retrieval, webhooks.
It would sit between the browser and the Next.js BFF (or replace it).

---

## Repository layout

```
NewSolution/
├── AZURE_SETUP.md                       # Step-by-step Azure portal recipe
├── ARCHITECTURE.md                      # ← you are here
├── README.md                            # Quick-start
├── sample-orders-api.openapi.yaml       # First sample API — Orders (1 op)
├── apim-policy-return-response.xml      # Inbound mock policy (Orders)
├── sample-customers-api.openapi.yaml    # Second sample API — Customers (3 ops)
├── apim-policy-customers.xml            # Inbound mock policies (Customers)
│
├── chat-ui/                             # ← the live system (Next.js)
│   ├── app/
│   │   ├── api/
│   │   │   ├── chat/route.ts            # BFF: MCP client + Azure OpenAI + streamText
│   │   │   └── mcp-servers/             # REST API for the MCP config (used by /settings)
│   │   │       ├── route.ts             #   GET / POST
│   │   │       ├── [name]/route.ts      #   PUT / DELETE
│   │   │       └── test/route.ts        #   POST  (probe initialize + tools/list)
│   │   ├── page.tsx                     # Chat UI
│   │   ├── settings/page.tsx            # MCP-server management UI
│   │   ├── layout.tsx
│   │   └── globals.css                  # Tailwind v4 + theme tokens
│   ├── lib/
│   │   └── mcp-store.ts                 # File-backed CRUD + auth-header builder
│   ├── data/
│   │   └── mcp-servers.json             # Persistent MCP config (git-ignored)
│   ├── .env.local                       # AZURE_OPENAI_*, optional legacy MCP_* fallbacks
│   ├── postcss.config.mjs
│   ├── next.config.ts
│   └── package.json                     # ai, @ai-sdk/azure, @modelcontextprotocol/sdk, react-markdown
│
└── apim-mcp-server/                     # Reference / dormant (not in the request path)
    ├── server.py                        # FastMCP demo: get_order, call_apim_operation
    ├── apim_client.py
    ├── requirements.txt
    └── .env                             # Kept for reference; not used at runtime
```

`apim-mcp-server/` is preserved as a working **pattern A+C** reference — if you
ever need to add composite/custom tools that APIM can't generate, this is the
starting point. It is not running and is not part of the live request flow.

---

## Scaling to multiple MCP servers

The BFF in [chat-ui/app/api/chat/route.ts](chat-ui/app/api/chat/route.ts)
already supports **N MCP servers** configured via one env var. Adding a new
MCP is a config change — no code change.

### Configuration shape

The MCP server list lives in a JSON file the app reads on every chat turn:

**`chat-ui/data/mcp-servers.json`** (created on first save, git-ignored):

```json
{
  "servers": [
    {
      "name": "orders",
      "url": "https://ai-apim-1234.azure-api.net/ordersmcp/mcp",
      "authHeader": "Ocp-Apim-Subscription-Key",
      "authValue": "<sub key>"
    },
    {
      "name": "customers",
      "url": "https://ai-apim-1234.azure-api.net/customersmcp/mcp",
      "authHeader": "Ocp-Apim-Subscription-Key",
      "authValue": "<sub key>"
    }
  ]
}
```

Each entry: `name` (becomes the **tool prefix** — see below), `url`
(Streamable-HTTP MCP endpoint), `authHeader` + `authValue` (header name and
raw key value). For environments where you prefer env-var indirection, use
`authEnv` instead of `authValue` and the BFF resolves it at request time.

### Two ways to manage the list

| Mechanism | When to use |
|---|---|
| **`/settings` UI** (recommended) | Day-to-day. Browse to `http://localhost:3000/settings` → list, add, edit, delete, test connection, save. Changes take effect on the next chat turn — no restart. |
| **Edit `data/mcp-servers.json` directly** | Bootstrapping, CI, scripted setup, or restoring a known-good config. |

The Settings page calls these REST endpoints (also useful from CLI / Bicep
/ Postman):

| Method + path | What it does |
|---|---|
| `GET /api/mcp-servers` | List all configured MCP servers |
| `POST /api/mcp-servers` | Add a new server (body: full server object) |
| `PUT /api/mcp-servers/{name}` | Update by name (body: partial patch) |
| `DELETE /api/mcp-servers/{name}` | Remove by name |
| `POST /api/mcp-servers/test` | Probe a URL + auth (no save) — returns tool list or error |

### Fallback to env vars

If `data/mcp-servers.json` is empty or missing on first boot, the BFF falls
back to the legacy env-var configuration (`MCP_SERVERS_JSON` array, then
`MCP_SERVER_URL` + `APIM_SUBSCRIPTION_KEY` single-server). Add at least one
server through the UI to switch to file-backed storage permanently.

### Production storage (target)

Local-file storage is appropriate for dev / demo / single-instance deploys.
For multi-instance production, swap the read/write internals of
[chat-ui/lib/mcp-store.ts](chat-ui/lib/mcp-store.ts) for:

- **Azure Cosmos DB** (or Azure Table Storage) for the config rows, and
- **Azure Key Vault** for `authValue` — store only a Key Vault reference
  (`@Microsoft.KeyVault(SecretUri=...)`) in the config row, resolve at
  request time via Managed Identity.

The REST API surface (`/api/mcp-servers/*`) stays the same; only the storage
adapter changes. The chat code (`/api/chat`) is unaffected.

### Tool namespacing

When the BFF pulls tools from each MCP server, **every tool name is prefixed
with the server name**: a tool `getAnOrderById` from server `orders` becomes
`orders.getAnOrderById` in the LLM-visible tool list.

Why:

- **Collision-proof** — two MCPs that each have a `getStatus` no longer
  conflict.
- **Self-documenting for the model** — the prefix is part of the tool name
  the LLM sees, so it picks the right one by domain.
- **Observability** — log lines carry the server name (see below) so you can
  attribute calls per MCP.

### Per-tool logging

Every tool invocation is wrapped to emit a structured log line:

```
[chat] turn start servers=2/2 tools=7
[tool] server=orders    tool=getAnOrderById   status=ok    durationMs=341
[tool] server=customers tool=findCustomer     status=error durationMs=812 err=Unauthorized
[chat] turn done durationMs=4120
```

Fields are stable enough to grep, parse into structured logs, or forward to
App Insights. When you're ready, swap `console.log` for your logger of choice
in [route.ts](chat-ui/app/api/chat/route.ts) — the wrapping logic stays the
same.

### Failure isolation

If one MCP server is down (or returns an error during `tools/list`), the BFF
**logs the failure and continues with the remaining servers**. The chat turn
still works — the LLM just doesn't see that server's tools for the turn.
This is intentional: a dead MCP shouldn't take down the whole assistant.

### Enterprise scaling roadmap

| Stage | Recommended pattern | Why |
|---|---|---|
| 1–4 MCPs | This setup — `MCP_SERVERS_JSON` + namespacing + per-tool logs | Simple, transparent, zero infra beyond APIM |
| 5–10 MCPs | Same, plus per-product subscription keys (one key per MCP, scoped in APIM Products) | Limit blast radius, easier rotation |
| 10–50 MCPs | Replace `MCP_SERVERS_JSON` with a **registry call at startup** (lists active MCPs the user is entitled to); add **Entra ID / OAuth user identity** instead of static keys | Per-user filtering, dynamic onboarding, real auth |
| Very large | One **APIM-aggregator MCP** that fans out internally to many APIs — chat app sees one URL | Single trust + governance boundary |

All four stages keep the same BFF shape (`/api/chat`) and the same Next.js
client. You replace **what the BFF connects to**, not the BFF itself.

### Cross-cutting concerns to plan for

- **Auth**: today, a static APIM subscription key per MCP. For multi-user
  deployments switch to Entra ID; have APIM's `validate-jwt` policy enforce
  identity at the gateway, so the BFF holds no long-lived secrets.
- **Tool budgeting**: as the number of tools grows, every chat turn's prompt
  carries every tool schema. Past ~10–15 tools, filter tools per turn (by
  user role, by an LLM classifier on the first message, or by tool category)
  rather than exposing all of them at once.
- **Rate limits & quotas**: set in APIM (`rate-limit-by-key`,
  `quota-by-key`). Per-API and per-user quotas prevent a single runaway
  tool or user from exhausting the system.
- **Environments**: separate APIM instances per dev/staging/prod, each with
  its own MCP servers and subscription keys. The BFF reads one base value
  per environment — don't mix scopes in a single config.
- **Distributed tracing**: propagate `traceparent` (W3C) from the browser
  through the BFF and into APIM so tool calls stitch end-to-end in App
  Insights / OpenTelemetry.

---

## Operational notes

- **Secrets**: All sensitive values live in `chat-ui/.env.local` (git-ignored).
  Server-only — never sent to the browser.
- **Observability**: APIM's **Analytics** and **Metrics** blades show every
  call, including MCP-driven calls (they appear as regular requests on the
  underlying API operation).
- **Versioning**: APIM API versioning works as usual — bump the OpenAPI, import
  as a new version, re-attach the MCP server to whichever version you want
  the model to see.
- **Production checklist**:
  - Move Azure OpenAI behind APIM too (with a key/JWT policy) so the BFF only
    holds an APIM subscription key, not a raw OpenAI key.
  - Add APIM `validate-jwt` policy + per-user identity flow if the chat needs
    per-user data.
  - Put the Next.js app behind Front Door / App Service with managed identity
    to APIM.
  - Lock APIM to private endpoint if backend services are on a VNet.
