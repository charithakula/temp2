# Azure Setup — Step by Step

This document reproduces, from a blank Azure subscription, the exact Azure
resources we provisioned and configured for the APIM + MCP + Azure OpenAI
chat. Every section is portal navigation. The end-state matches what the
Next.js chat in this repo expects.

---

## What you'll end up with

- An **Azure OpenAI** resource with a `gpt-5.2-chat` deployment.
- An **Azure API Management** instance (`ai-apim-1234`) on **Standard v2**.
- An **Orders API** imported from [sample-orders-api.openapi.yaml](sample-orders-api.openapi.yaml).
- A **return-response mock policy** on `GET /orders/{id}` so the API works
  with no backend ([apim-policy-return-response.xml](apim-policy-return-response.xml)).
- An **MCP server** in APIM (native preview feature) exposing the Orders API
  as MCP tools.
- One **subscription key** with access to both products / APIs.

---

## Part 1 — Azure OpenAI

### 1.1 Create the resource

1. Azure Portal → **Create a resource** → search **Azure OpenAI** → **Create**.
2. Fill in:
   - **Subscription**: your subscription
   - **Resource group**: `ai-rg` (create new if needed)
   - **Region**: `East US` (must support `gpt-5.2-chat`)
   - **Name**: e.g. `ai-charithakula2902ai...` (this becomes the endpoint host)
   - **Pricing tier**: `Standard S0`
3. **Next → Review + create → Create**. Wait for provisioning to finish.

### 1.2 Deploy the chat model

1. Open the new Azure OpenAI resource → **Go to Azure OpenAI Studio**
   (or click **Model deployments** → **Manage Deployments** → opens Studio).
2. Studio → **Deployments** → **+ Create new deployment**.
3. Fill in:
   - **Model**: `gpt-5.2-chat`
   - **Deployment name**: `gpt-5.2-chat` (keep it identical for clarity)
   - **Deployment type**: `Standard` (or `GlobalStandard` if available)
4. **Create**. Wait for **Succeeded** status.

### 1.3 (Optional) Deploy an embeddings model

If you want embeddings later (RAG etc.):

1. Studio → **Deployments** → **+ Create new deployment**.
2. **Model**: `text-embedding-3-small` · **Deployment name**: `text-embedding-3-small`.

### 1.4 Grab the credentials

Portal → your Azure OpenAI resource → **Keys and Endpoint**:

- `AZURE_OPENAI_ENDPOINT` ← the "Endpoint" URL (ends with `.cognitiveservices.azure.com/`)
- `AZURE_OPENAI_API_KEY` ← either KEY 1 or KEY 2
- `AZURE_OPENAI_API_VERSION` ← `2024-12-01-preview` (or the version Studio shows)
- `AZURE_OPENAI_DEPLOYMENT` ← the deployment name from step 1.2 (`gpt-5.2-chat`)

Paste these into [chat-ui/.env.local](chat-ui/.env.local).

> **Note on endpoint shape:** The newer Azure OpenAI resources use a
> `*.cognitiveservices.azure.com` endpoint instead of the older
> `*.openai.azure.com`. The Next.js route handles this by setting an explicit
> `baseURL` in `createAzure(...)` — no change required by you.

---

## Part 2 — Azure API Management

### 2.1 Create the APIM instance

1. Azure Portal → **Create a resource** → **API Management** → **Create**.
2. Fill in:
   - **Resource group**: `ai-rg`
   - **Region**: `East US`
   - **Resource name**: `ai-apim-1234` (must be globally unique — pick your own)
   - **Organization name**: anything
   - **Administrator email**: yours
   - **Pricing tier**: **Standard v2** (required for the MCP preview feature; the
     Consumption tier currently does **not** support MCP servers)
3. **Review + create → Create**. Provisioning Standard v2 typically takes
   **15–45 minutes**.

### 2.2 Confirm essentials

When provisioning finishes, open APIM → **Overview**. Verify:

- **Status**: Online
- **Gateway URL**: `https://ai-apim-1234.azure-api.net`
- **Tier**: Standard v2
- **APIs**: 0 (we'll fix this next)

---

## Part 3 — Import the Orders API

### 3.1 Import the OpenAPI spec

1. APIM → left menu → **APIs** → **+ Add API**.
2. Choose **OpenAPI**.
3. Click **Select a file** → pick [sample-orders-api.openapi.yaml](sample-orders-api.openapi.yaml).
4. Settings:
   - **Display name**: `Orders API`
   - **Name**: `orders-api`
   - **API URL suffix**: leave **blank** (so the path is `/orders/{id}`, not `/orders-api/orders/{id}`)
     - If you set a suffix here, update the MCP/test URLs accordingly.
   - **Products**: attach to `Unlimited` (so the built-in all-access subscription can call it)
5. **Create**.

### 3.2 Add the mock policy on GET /orders/{id}

By default APIM has no backend wired up, so calls 404. We make the operation
self-serving with a `return-response` policy:

1. APIM → **APIs** → **Orders API** → **Design** tab.
2. In the operation list select **GET /orders/{id}**.
3. **Inbound processing** pane → click the **`</>`** icon (policy code editor).
4. Replace the entire content with the body of [apim-policy-return-response.xml](apim-policy-return-response.xml).
5. **Save**.

### 3.3 Verify

In APIM → APIs → Orders API → **Design** → **Test** tab → pick **GET /orders/{id}**
→ set `id = 42` → **Send**. You should see:

```
HTTP/1.1 200 OK
Content-Type: application/json
{"id":"42","customer":"Charith Akula", ...}
```

Or from a terminal:

```bash
curl -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
     https://ai-apim-1234.azure-api.net/orders/42
```

### 3.4 Grab the subscription key

APIM → left menu → **Subscriptions** → click **Built-in all-access subscription**
(or whichever subscription is scoped to "All APIs" / the Orders API product) →
**Show/hide keys** → copy **Primary key**.

This is `APIM_SUBSCRIPTION_KEY` in `chat-ui/.env.local`.

---

## Part 4 — Expose the Orders API as an MCP server

This is APIM's native MCP feature (preview at the time of writing — requires
Standard v2 or higher).

### 4.1 Create the MCP server

1. APIM → left menu → **APIs** section → **MCP Servers**
   (sometimes labeled **APIs as MCP servers**, may have a "Preview" banner).
2. **+ Create MCP server**.
3. Fill in:
   - **Source API**: `Orders API`
   - **Display name**: `Orders MCP`
   - **Name**: `orders-mcp` (URL slug becomes `ordersmcp` — case may vary)
   - **API URL suffix**: APIM defaults to `ordersmcp/mcp` for the endpoint
   - **Operations to expose**: tick **GET /orders/{id}** (and any others
     you've added)
   - **Products**: attach to the same product the subscription key has access to (`Unlimited`)
4. **Create**.

### 4.2 Note the MCP endpoint URL

Open the new MCP server → look for **Endpoint URL** (or it appears in the URL
column of the MCP Servers list). Ours is:

```
https://ai-apim-1234.azure-api.net/ordersmcp/mcp
```

This is `MCP_SERVER_URL` in `chat-ui/.env.local`.

### 4.3 Verify the MCP server

From any machine with `curl`:

```bash
# Initialize handshake
curl -s -X POST "https://ai-apim-1234.azure-api.net/ordersmcp/mcp" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"probe","version":"1"}}}'

# Discover tools
curl -s -X POST "https://ai-apim-1234.azure-api.net/ordersmcp/mcp" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'

# Invoke
curl -s -X POST "https://ai-apim-1234.azure-api.net/ordersmcp/mcp" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"getAnOrderById","arguments":{"id":"42"}}}'
```

You should see:

- `initialize` → server identifies itself as `Azure API Management`
- `tools/list` → returns one tool, `getAnOrderById`, with input schema `{id: string}`
- `tools/call` → returns the order JSON inside an MCP `content` envelope

---

## Part 5 — Wire credentials into the Next.js app

Edit [chat-ui/.env.local](chat-ui/.env.local) and set:

```
AZURE_OPENAI_API_KEY=<from Part 1.4>
AZURE_OPENAI_ENDPOINT=https://<your-aoai-name>.cognitiveservices.azure.com/
AZURE_OPENAI_API_VERSION=2024-12-01-preview
AZURE_OPENAI_DEPLOYMENT=gpt-5.2-chat

MCP_SERVER_URL=https://ai-apim-1234.azure-api.net/ordersmcp/mcp
APIM_SUBSCRIPTION_KEY=<from Part 3.4>
```

Then:

```powershell
cd chat-ui
npm install
npm run dev   # http://localhost:3000
```

Send the prompt:
> Get order 42 and tell me the customer, status, and total.

You should see the assistant invoke the **`getAnOrderById`** tool and reply with
the mocked order details.

---

## Part 6 — Add a second API + second MCP (Customers)

This part shows the **multi-MCP pattern in action**. We import a second API
(Customers) into the same APIM, expose it as a separate MCP server, and
register both in the chat app. The chat then sees `orders.*` AND `customers.*`
tools merged into one toolset.

### 6.1 Import the Customers API

1. APIM → **APIs** → **+ Add API** → **OpenAPI**.
2. Select [sample-customers-api.openapi.yaml](sample-customers-api.openapi.yaml).
3. Settings:
   - **Display name**: `Customers API`
   - **Name**: `customers-api`
   - **API URL suffix**: **leave blank** (same convention as Orders)
   - **Products**: attach to `Unlimited`
4. **Create**. You should see three operations imported:
   - `GET /customers/{id}`
   - `GET /customers`
   - `GET /customers/{id}/orders`

### 6.2 Add mock policies for all three operations

[apim-policy-customers.xml](apim-policy-customers.xml) contains three
`<policies>` blocks — one per operation, clearly commented. For each operation:

1. APIs → **Customers API** → **Design** → select the operation.
2. **Inbound processing** → `</>` code editor.
3. Copy the matching block from the policy file → paste into the editor →
   **Save**.

Repeat for all three operations.

### 6.3 Verify the operations directly

```bash
curl -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
     https://ai-apim-1234.azure-api.net/customers/c-1001
curl -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
     https://ai-apim-1234.azure-api.net/customers?tier=Gold
curl -H "Ocp-Apim-Subscription-Key: <your-sub-key>" \
     https://ai-apim-1234.azure-api.net/customers/c-1001/orders
```

Each should return 200 with the mock JSON.

### 6.4 Expose Customers API as a 2nd MCP server

1. APIM → **MCP Servers** → **+ Create MCP server**.
2. Fill in:
   - **Source API**: `Customers API`
   - **Display name**: `Customers MCP`
   - **Name**: `customers-mcp` (URL slug becomes `customersmcp`)
   - **Operations to expose**: tick all three
   - **Products**: `Unlimited`
3. **Create**.
4. Note the **Endpoint URL** — typically
   `https://ai-apim-1234.azure-api.net/customersmcp/mcp`.

### 6.5 Update `chat-ui/.env.local` to list both MCPs

Replace the single-server `MCP_SERVERS_JSON` value with both servers:

```
MCP_SERVERS_JSON=[
  {"name":"orders",    "url":"https://ai-apim-1234.azure-api.net/ordersmcp/mcp",    "authHeader":"Ocp-Apim-Subscription-Key","authEnv":"APIM_ORDERS_KEY"},
  {"name":"customers", "url":"https://ai-apim-1234.azure-api.net/customersmcp/mcp", "authHeader":"Ocp-Apim-Subscription-Key","authEnv":"APIM_CUSTOMERS_KEY"}
]

APIM_ORDERS_KEY=<sub key with access to Orders>
APIM_CUSTOMERS_KEY=<sub key with access to Customers>
```

Restart Next.js (env changes don't hot-reload):

```powershell
# Ctrl+C the running `npm run dev`, then:
cd chat-ui
npm run dev
```

### 6.6 Test the multi-MCP integration in the chat

Each prompt below should produce a specific tool-call card name — that's how
you confirm both MCPs are wired:

| Prompt | Expected tool card(s) |
|---|---|
| *Get customer c-1001* | `customers.getCustomerById` |
| *List the Gold-tier customers* | `customers.listCustomers` with `args:{"tier":"Gold"}` |
| *What orders does customer c-1001 have?* | `customers.getCustomerOrders` |
| *Give me everything about customer c-1001 and their orders* | **Multiple cards from BOTH MCPs** — first `customers.getCustomerOrders`, then several `orders.getAnOrderById` (one per returned order ID). This is the proof-of-concept for multi-MCP composition. |
| *Get order 42* | `orders.getAnOrderById` (still works as before) |

In the Next.js terminal you should now see structured logs like:

```
[chat] turn start servers=2/2 tools=4
[tool] server=customers tool=getCustomerOrders status=ok durationMs=312
[tool] server=orders    tool=getAnOrderById     status=ok durationMs=345
[chat] turn done durationMs=5840
```

---

## Adding more operations later

To add a new operation (say `GET /orders` to list orders):

1. APIM → Orders API → **Design** → **+ Add operation**, define it.
2. Add a similar `return-response` policy if no backend exists.
3. APIM → MCP Servers → **Orders MCP** → **Edit** → tick the new operation → **Save**.

That's it. **No code change in the Next.js app.** Refresh the chat and the
model immediately sees the new tool — that's the headline advantage of the
APIM-native MCP pattern.

---

## Cleanup / cost notes

- **APIM Standard v2** has a baseline monthly cost (~hundreds USD/month).
  For a dev sandbox, delete the APIM instance when done — it can be recreated
  from this doc in ~30 minutes.
- **Azure OpenAI** is per-token; idle costs nothing.
- Both resources can be removed by deleting the **`ai-rg`** resource group.

## Key rotation

When you're finished testing:

- Azure OpenAI → **Keys and Endpoint** → **Regenerate Key 1** (or 2)
- APIM → **Subscriptions** → your subscription → **Regenerate primary**

Then update `chat-ui/.env.local` with the new values.
