# APIM MCP Chat

A working **AI chat over an Azure APIM API**, using APIM's native
**"Expose API as MCP server"** feature. No middle-tier needed — the Next.js
app talks directly to APIM's MCP endpoint, with **Azure OpenAI** as the LLM.

```
Browser ── /api/chat ──► Next.js (BFF) ──► Azure OpenAI (gpt-5.2-chat)
                              │  MCP Streamable-HTTP + APIM sub-key
                              ▼
                       Azure APIM — MCP server
                              │  (internal hop, same APIM)
                              ▼
                       Orders API · GET /orders/{id}
                              │  return-response policy (mock body)
                              ▼
                          JSON order data
```

The Python `apim-mcp-server/` folder is preserved as a **reference** for the
"composite/custom tool" pattern but is **not** in the live request path.

---

## Documentation

| File | What's in it |
|---|---|
| [AZURE_SETUP.md](AZURE_SETUP.md) | Step-by-step Azure portal recipe — recreate everything from scratch (Parts 1–5 single-MCP; Part 6 adds a second API + MCP) |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Component map, request flow, multi-MCP scaling, why this shape over FastAPI/FastMCP |
| [sample-orders-api.openapi.yaml](sample-orders-api.openapi.yaml) | First sample API — Orders (single operation `GET /orders/{id}`) |
| [apim-policy-return-response.xml](apim-policy-return-response.xml) | Inbound mock policy for the Orders API |
| [sample-customers-api.openapi.yaml](sample-customers-api.openapi.yaml) | Second sample API — Customers (3 operations) — used to demo multi-MCP |
| [apim-policy-customers.xml](apim-policy-customers.xml) | Three inbound mock policies for the Customers API (one per operation) |

---

## Quick start (once Azure is set up — see [AZURE_SETUP.md](AZURE_SETUP.md))

```powershell
cd chat-ui
npm install
# Edit .env.local with your Azure OpenAI values
npm run dev   # http://localhost:3000
```

Then either:
- Open **http://localhost:3000/settings** and add an MCP server (URL +
  key, click **Test connection**, then **Save**), or
- Bootstrap by editing `chat-ui/data/mcp-servers.json` directly.

Then chat:
> *Get order 42 and tell me the customer, status, and total.*

The assistant renders a `getAnOrderById` tool-call card and streams the
order details.

---

## Adding more MCP servers / tools later

Two paths, both with **zero code changes**:

1. **Add the API to APIM** → expose as a new MCP server → open
   **/settings** → **+ Add MCP server** → paste URL + key → **Test
   connection** → **Save**. The chat picks up the new tools on the next
   turn (no restart).
2. **Add an operation to an existing API** in APIM → re-attach the MCP
   server to include it → refresh the chat. The model sees the new tool
   immediately.
