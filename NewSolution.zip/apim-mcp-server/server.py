"""FastMCP server that exposes Azure APIM APIs as MCP tools.

Run locally (streamable-HTTP transport, the form the Next.js AI SDK consumes):

    python server.py

The server listens on http://MCP_HOST:MCP_PORT/mcp .

Two kinds of tools are provided:
  1. `call_apim_operation` — a generic escape hatch to call any APIM path.
  2. Curated, typed tools (see `get_order` below) — add one per real API
     operation so the LLM gets clear names, descriptions, and arguments.
     Curated tools give far better tool-selection accuracy than the generic
     one, so prefer adding them for the operations you actually use.
"""

from __future__ import annotations

import json
import os
from typing import Any

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

load_dotenv()

# Import after load_dotenv so apim_client reads the populated environment.
from apim_client import call_apim  # noqa: E402

mcp = FastMCP("apim-mcp-server")


@mcp.tool()
async def call_apim_operation(
    method: str,
    path: str,
    query_json: str,
    body_json: str,
) -> dict[str, Any]:
    """Call any operation on the configured Azure APIM instance.

    Use this generic tool when no curated tool matches the request.

    Args:
        method: HTTP verb such as "GET", "POST", "PUT", "PATCH", "DELETE".
        path: Operation path relative to the APIM base URL, e.g. "/orders/42".
        query_json: Query-string params as a JSON object string,
            e.g. '{"page": 1, "size": 20}'. Pass "" for none.
        body_json: JSON request body as a string for write operations,
            e.g. '{"name": "Acme"}'. Pass "" for none.
    """
    # Use plain `str` params (not open dicts) so the generated JSON schema is
    # compatible with Azure OpenAI's strict function-calling validation, which
    # requires additionalProperties:false on every object.
    query = json.loads(query_json) if query_json.strip() else None
    body = json.loads(body_json) if body_json.strip() else None
    return await call_apim(method, path, query=query, json_body=body)


# ---------------------------------------------------------------------------
# Curated tools — replace / extend these with YOUR real APIM operations.
# Each becomes a first-class tool the LLM can pick by name + description.
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_order(order_id: str) -> dict[str, Any]:
    """Fetch a single order by its ID from the Orders API.

    (Sample tool — adjust the path to match your real APIM operation.)

    Args:
        order_id: The unique identifier of the order to retrieve.
    """
    return await call_apim("GET", f"/orders/{order_id}")


if __name__ == "__main__":
    # SSE transport exposes the server at http://host:port/sse , which the
    # Vercel AI SDK's MCP client (type: "sse") connects to directly.
    mcp.settings.host = os.environ.get("MCP_HOST", "127.0.0.1")
    mcp.settings.port = int(os.environ.get("MCP_PORT", "8000"))
    mcp.run(transport="sse")
