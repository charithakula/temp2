"""Thin async HTTP client for calling Azure API Management (APIM) APIs.

Centralizes base URL, auth headers, and error handling so the MCP tools in
server.py stay declarative. Auth supports an APIM subscription key and/or a
bearer token (OAuth/JWT) — set whichever your APIM instance requires.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

APIM_BASE_URL = os.environ.get("APIM_BASE_URL", "").rstrip("/")
APIM_SUBSCRIPTION_KEY = os.environ.get("APIM_SUBSCRIPTION_KEY", "")
APIM_BEARER_TOKEN = os.environ.get("APIM_BEARER_TOKEN", "")


def _auth_headers() -> dict[str, str]:
    headers: dict[str, str] = {"Accept": "application/json"}
    if APIM_SUBSCRIPTION_KEY:
        headers["Ocp-Apim-Subscription-Key"] = APIM_SUBSCRIPTION_KEY
    if APIM_BEARER_TOKEN:
        headers["Authorization"] = f"Bearer {APIM_BEARER_TOKEN}"
    return headers


async def call_apim(
    method: str,
    path: str,
    *,
    query: dict[str, Any] | None = None,
    json_body: Any | None = None,
    extra_headers: dict[str, str] | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """Call an APIM operation and return a normalized result dict.

    Args:
        method: HTTP verb, e.g. "GET", "POST".
        path: Operation path relative to APIM_BASE_URL, e.g. "/orders/123".
        query: Optional query-string parameters.
        json_body: Optional JSON request body (for POST/PUT/PATCH).
        extra_headers: Optional headers merged over the auth headers.

    Returns:
        {"status": int, "ok": bool, "data": <parsed json or text>}
        On transport failure: {"status": 0, "ok": False, "error": str}
    """
    if not APIM_BASE_URL:
        return {"status": 0, "ok": False, "error": "APIM_BASE_URL is not set"}

    url = f"{APIM_BASE_URL}/{path.lstrip('/')}"
    headers = _auth_headers()
    if extra_headers:
        headers.update(extra_headers)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.request(
                method.upper(), url, params=query, json=json_body, headers=headers
            )
    except httpx.HTTPError as exc:
        return {"status": 0, "ok": False, "error": f"request failed: {exc}"}

    content_type = resp.headers.get("content-type", "")
    data: Any
    if "application/json" in content_type:
        try:
            data = resp.json()
        except ValueError:
            data = resp.text
    else:
        data = resp.text

    return {"status": resp.status_code, "ok": resp.is_success, "data": data}
