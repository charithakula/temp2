import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # App
    APP_NAME = "AI API Migration Accelerator"
    DEBUG = os.getenv("DEBUG", "True").lower() == "true"
    
    # Database
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "postgresql://user:password@localhost:5432/migration_db"
    )
    
    # API
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", "8000"))
    
    # Frontend
    FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")

settings = Settings()
