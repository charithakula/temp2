import React, { useEffect, useState } from 'react';

function App() {
  const [status, setStatus] = useState<string>('Loading...');

  useEffect(() => {
    fetch('/health')
      .then(res => res.json())
      .then(data => setStatus(data.status))
      .catch(err => setStatus('Error: Backend unreachable'));
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>AI API Migration Accelerator</h1>
      <p>Backend Status: <strong>{status}</strong></p>
      <p>Application is running successfully!</p>
    </div>
  );
}

export default App;
